-- All In One WP Security & Firewall 4.3.8.3
-- MySQL dump
-- 2019-01-28 10:24:38

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `yucqn_aiowps_events`;

CREATE TABLE `yucqn_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '1970-01-01 05:05:05',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `yucqn_aiowps_failed_logins`;

CREATE TABLE `yucqn_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '1970-01-01 05:05:05',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=476 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `yucqn_aiowps_failed_logins` VALUES("1","0","admin","2018-03-08 23:31:03","83.38.230.92");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("2","0","distant-shores","2018-03-09 02:46:26","2605:6001:e103:b600:907d:33e5:d740:bbc4");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("3","0","distant-shores","2018-03-09 05:27:56","78.95.158.19");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("4","0","distant-shores","2018-03-09 07:58:38","181.92.222.30");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("5","0","test","2018-03-09 08:00:42","41.136.46.142");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("6","1","jbandre","2018-04-27 14:48:21","77.202.59.163");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("7","0","admin","2019-01-27 01:47:06","64.71.74.144");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("8","0","Admin","2019-01-27 01:49:23","192.227.88.124");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("9","0","admin","2019-01-27 01:50:54","64.71.75.56");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("10","0","Admin","2019-01-27 01:52:03","64.71.75.254");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("11","0","admin","2019-01-27 01:54:08","125.164.139.252");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("12","0","Admin","2019-01-27 01:55:43","192.227.116.76");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("13","0","admin","2019-01-27 01:57:11","192.227.65.199");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("14","0","Admin","2019-01-27 01:58:09","192.227.80.69");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("15","0","admin","2019-01-27 02:00:00","72.11.155.171");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("16","0","Admin","2019-01-27 02:01:44","104.167.9.254");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("17","0","admin","2019-01-27 02:03:17","192.227.108.77");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("18","0","Admin","2019-01-27 02:04:55","192.227.65.186");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("19","0","admin","2019-01-27 02:05:58","8.38.89.146");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("20","0","Admin","2019-01-27 02:07:55","192.227.110.56");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("21","0","admin","2019-01-27 02:09:29","192.227.66.101");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("22","0","Admin","2019-01-27 02:10:43","192.227.112.135");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("23","0","admin","2019-01-27 02:13:36","124.117.150.169");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("24","0","Admin","2019-01-27 02:14:52","104.167.2.25");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("25","0","admin","2019-01-27 02:16:51","41.230.52.222");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("26","0","Admin","2019-01-27 02:17:31","192.227.117.68");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("27","0","Admin","2019-01-27 02:20:48","192.227.116.58");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("28","0","admin","2019-01-27 02:21:19","2a02:27b0:4b02:d3d0:6542:1e6f:8974:d4e1");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("29","0","admin","2019-01-27 02:23:46","41.230.52.222");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("30","0","Admin","2019-01-27 02:25:42","171.242.100.137");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("31","0","Admin","2019-01-27 02:27:54","192.227.109.201");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("32","0","admin","2019-01-27 02:29:37","192.227.109.201");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("33","0","Admin","2019-01-27 02:32:35","2804:7f4:f880:8bc6:8478:a08c:a7d9:4233");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("34","0","admin","2019-01-27 02:34:07","192.227.66.101");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("35","0","Admin","2019-01-27 02:35:55","64.71.78.5");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("36","0","admin","2019-01-27 02:36:35","187.84.212.10");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("37","0","Admin","2019-01-27 02:39:16","192.227.66.101");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("38","0","admin","2019-01-27 02:40:58","192.227.91.54");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("39","0","Admin","2019-01-27 02:42:09","64.71.74.144");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("40","0","admin","2019-01-27 02:43:59","192.227.117.68");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("41","0","Admin","2019-01-27 02:45:44","38.130.208.196");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("42","0","admin","2019-01-27 02:48:30","192.227.102.196");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("43","0","Admin","2019-01-27 02:49:25","104.167.4.67");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("44","0","admin","2019-01-27 02:51:16","104.167.0.4");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("45","0","Admin","2019-01-27 02:53:41","64.71.78.76");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("46","0","admin","2019-01-27 02:54:54","104.167.0.4");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("47","0","Admin","2019-01-27 02:56:38","192.227.113.76");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("48","0","admin","2019-01-27 02:58:16","104.167.2.42");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("49","0","Admin","2019-01-27 03:00:12","172.81.185.71");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("50","0","admin","2019-01-27 03:02:00","8.30.124.149");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("51","0","Admin","2019-01-27 03:03:34","192.227.116.58");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("52","0","admin","2019-01-27 03:05:29","64.71.74.145");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("53","0","Admin","2019-01-27 03:07:17","138.128.144.74");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("54","0","admin","2019-01-27 03:09:06","104.167.1.72");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("55","0","Admin","2019-01-27 03:11:45","64.71.75.56");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("56","0","admin","2019-01-27 03:12:44","192.227.69.80");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("57","0","Admin","2019-01-27 03:14:31","192.227.117.68");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("58","0","admin","2019-01-27 03:16:16","172.81.185.70");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("59","0","Admin","2019-01-27 03:18:02","138.128.144.74");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("60","0","admin","2019-01-27 03:20:01","192.227.69.106");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("61","0","Admin","2019-01-27 03:23:06","140.213.17.41");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("62","0","Admin","2019-01-27 03:25:48","8.30.124.215");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("63","0","admin","2019-01-27 03:27:08","192.227.67.58");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("64","0","Admin","2019-01-27 03:29:24","192.227.112.135");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("65","0","Admin","2019-01-27 03:33:48","119.92.23.228");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("66","0","admin","2019-01-27 03:34:42","104.167.12.96");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("67","0","Admin","2019-01-27 03:36:35","104.167.12.96");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("68","0","Admin","2019-01-27 03:40:03","64.71.74.144");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("69","0","admin","2019-01-27 03:40:29","137.59.87.139");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("70","0","admin","2019-01-27 03:42:00","64.71.72.33");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("71","0","Admin","2019-01-27 03:44:37","192.227.110.57");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("72","0","admin","2019-01-27 03:46:30","93.114.183.181");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("73","0","admin","2019-01-27 03:49:08","172.81.185.72");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("74","0","Admin","2019-01-27 03:50:49","192.227.105.219");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("75","0","Admin","2019-01-27 03:55:26","192.227.66.107");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("76","0","Admin","2019-01-27 03:59:13","31.131.251.113");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("77","0","admin","2019-01-27 04:01:05","192.227.88.122");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("78","0","Admin","2019-01-27 04:03:20","212.154.58.125");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("79","0","admin","2019-01-27 04:04:39","104.167.2.6");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("80","0","admin","2019-01-27 04:07:24","104.167.4.67");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("81","0","Admin","2019-01-27 04:09:32","8.30.124.215");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("82","0","admin","2019-01-27 04:12:03","104.167.2.6");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("83","0","Admin","2019-01-27 04:12:44","192.227.116.58");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("84","0","admin","2019-01-27 04:15:38","192.227.69.58");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("85","0","Admin","2019-01-27 04:16:19","64.71.72.243");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("86","0","admin","2019-01-27 04:18:06","192.227.75.66");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("87","0","Admin","2019-01-27 04:19:18","104.167.6.69");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("88","0","admin","2019-01-27 04:19:38","8.30.124.214");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("89","0","Admin","2019-01-27 04:20:46","138.128.144.74");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("90","0","Admin","2019-01-27 04:22:39","192.227.67.202");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("91","0","admin","2019-01-27 04:22:56","122.129.79.199");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("92","0","admin","2019-01-27 04:23:44","192.227.105.219");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("93","0","Admin","2019-01-27 04:25:04","104.167.8.145");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("94","0","admin","2019-01-27 04:26:29","38.130.230.66");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("95","0","Admin","2019-01-27 04:27:46","192.227.114.132");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("96","0","admin","2019-01-27 04:28:06","64.71.72.116");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("97","0","Admin","2019-01-27 04:30:24","104.167.3.187");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("98","0","Admin","2019-01-27 04:31:30","64.71.74.144");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("99","0","admin","2019-01-27 04:32:46","64.71.78.13");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("100","0","admin","2019-01-27 04:33:02","124.122.28.202");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("101","0","Admin","2019-01-27 04:33:32","192.227.109.201");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("102","0","admin","2019-01-27 04:35:01","192.227.69.80");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("103","0","Admin","2019-01-27 04:35:47","192.227.76.93");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("104","0","admin","2019-01-27 04:38:24","88.231.239.80");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("105","0","Admin","2019-01-27 04:40:11","41.35.232.149");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("106","0","admin","2019-01-27 04:40:13","104.167.3.187");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("107","0","Admin","2019-01-27 04:40:13","64.71.74.145");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("108","0","admin","2019-01-27 04:41:39","192.227.67.58");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("109","0","admin","2019-01-27 04:43:36","8.38.88.24");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("110","0","Admin","2019-01-27 04:45:01","64.71.78.13");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("111","0","Admin","2019-01-27 04:45:03","223.3.227.122");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("112","0","admin","2019-01-27 04:46:50","192.227.67.192");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("113","0","Admin","2019-01-27 04:47:58","64.71.75.132");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("114","0","admin","2019-01-27 04:48:21","192.227.67.55");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("115","0","Admin","2019-01-27 04:49:20","192.227.109.201");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("116","0","Admin","2019-01-27 04:51:18","192.227.67.55");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("117","0","Admin","2019-01-27 04:53:44","172.81.185.232");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("118","0","admin","2019-01-27 04:53:49","88.229.0.109");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("119","0","Admin","2019-01-27 04:55:55","138.128.144.74");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("120","0","admin","2019-01-27 04:56:06","197.211.216.244");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("121","0","admin","2019-01-27 04:57:46","192.227.67.192");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("122","0","admin","2019-01-27 04:58:50","192.227.105.219");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("123","0","Admin","2019-01-27 05:00:00","192.227.113.76");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("124","0","Admin","2019-01-27 05:00:05","2001:e68:4417:2a5f:2d8a:2d75:f351:7acf");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("125","0","Admin","2019-01-27 05:02:30","104.167.2.39");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("126","0","admin","2019-01-27 05:04:20","147.234.38.46");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("127","0","admin","2019-01-27 05:04:38","196.188.127.104");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("128","0","Admin","2019-01-27 05:04:42","64.71.78.243");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("129","0","admin","2019-01-27 05:05:50","138.128.144.76");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("130","0","Admin","2019-01-27 05:06:33","8.30.124.215");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("131","0","admin","2019-01-27 05:08:22","2a05:480:0:f4f1::2");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("132","0","Admin","2019-01-27 05:09:15","64.71.74.224");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("133","0","admin","2019-01-27 05:10:38","52.35.124.126");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("134","0","Admin","2019-01-27 05:12:05","192.227.88.124");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("135","0","admin","2019-01-27 05:13:11","64.71.75.132");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("136","0","Admin","2019-01-27 05:14:34","38.130.225.145");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("137","0","admin","2019-01-27 05:14:44","138.128.144.76");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("138","0","Admin","2019-01-27 05:15:42","64.71.78.230");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("139","0","admin","2019-01-27 05:17:34","104.167.9.254");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("140","0","Admin","2019-01-27 05:18:58","192.227.110.56");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("141","0","admin","2019-01-27 05:19:59","192.227.96.8");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("142","0","Admin","2019-01-27 05:20:12","104.167.9.191");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("143","0","admin","2019-01-27 05:21:54","115.146.127.55");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("144","0","Admin","2019-01-27 05:23:18","192.227.88.113");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("145","0","admin","2019-01-27 05:23:25","64.71.74.145");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("146","0","Admin","2019-01-27 05:24:36","192.227.69.106");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("147","0","admin","2019-01-27 05:25:41","104.167.2.39");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("148","0","Admin","2019-01-27 05:27:14","192.227.114.132");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("149","0","admin","2019-01-27 05:28:36","64.71.79.132");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("150","0","Admin","2019-01-27 05:28:54","8.30.124.149");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("151","0","admin","2019-01-27 05:30:00","8.30.124.218");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("152","0","Admin","2019-01-27 05:31:16","104.167.9.232");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("153","0","Admin","2019-01-27 05:33:14","38.130.227.207");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("154","0","admin","2019-01-27 05:33:29","110.137.22.170");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("155","0","admin","2019-01-27 05:36:24","2001:e68:4417:2a5f:2d8a:2d75:f351:7acf");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("156","0","Admin","2019-01-27 05:36:25","38.130.200.133");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("157","0","admin","2019-01-27 05:37:01","2a02:c207:2021:8570::1");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("158","0","Admin","2019-01-27 05:37:23","64.71.74.175");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("159","0","admin","2019-01-27 05:39:38","192.227.75.66");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("160","0","Admin","2019-01-27 05:39:49","8.38.88.24");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("161","0","admin","2019-01-27 05:40:45","192.227.114.197");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("162","0","Admin","2019-01-27 05:42:11","64.71.78.13");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("163","0","admin","2019-01-27 05:44:27","104.167.3.187");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("164","0","Admin","2019-01-27 05:45:21","192.227.67.193");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("165","0","admin","2019-01-27 05:45:37","104.167.12.146");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("166","0","Admin","2019-01-27 05:46:21","192.227.76.92");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("167","0","admin","2019-01-27 05:47:33","192.227.67.55");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("168","0","Admin","2019-01-27 05:48:35","38.130.230.66");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("169","0","admin","2019-01-27 05:50:44","192.227.66.107");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("170","0","Admin","2019-01-27 05:50:57","104.167.9.232");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("171","0","admin","2019-01-27 05:52:10","64.71.74.224");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("172","0","Admin","2019-01-27 05:54:03","192.227.117.162");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("173","0","admin","2019-01-27 05:54:29","104.167.12.96");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("174","0","Admin","2019-01-27 05:55:58","2607:5300:60:6c07::");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("175","0","admin","2019-01-27 05:56:17","64.71.79.6");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("176","0","Admin","2019-01-27 05:57:46","138.128.144.76");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("177","0","admin","2019-01-27 05:58:35","180.71.92.11");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("178","0","Admin","2019-01-27 05:59:33","192.227.105.219");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("179","0","Admin","2019-01-27 06:02:22","64.71.73.142");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("180","0","admin","2019-01-27 06:02:32","192.227.105.196");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("181","0","admin","2019-01-27 06:03:50","192.227.66.107");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("182","0","Admin","2019-01-27 06:04:45","183.90.237.48");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("183","0","Admin","2019-01-27 06:06:23","104.167.4.61");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("184","0","admin","2019-01-27 06:06:26","125.160.206.27");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("185","0","admin","2019-01-27 06:07:17","192.227.67.56");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("186","0","Admin","2019-01-27 06:08:35","64.71.79.16");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("187","0","admin","2019-01-27 06:10:55","125.160.206.27");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("188","0","Admin","2019-01-27 06:10:57","104.167.4.67");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("189","0","admin","2019-01-27 06:12:46","192.227.88.113");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("190","0","Admin","2019-01-27 06:13:14","64.71.78.243");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("191","0","admin","2019-01-27 06:14:18","192.227.113.76");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("192","0","Admin","2019-01-27 06:15:30","104.167.12.146");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("193","0","admin","2019-01-27 06:16:11","192.227.116.58");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("194","0","Admin","2019-01-27 06:18:46","171.97.48.254");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("195","0","admin","2019-01-27 06:19:14","192.227.91.54");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("196","0","Admin","2019-01-27 06:20:35","192.227.108.71");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("197","0","admin","2019-01-27 06:21:15","104.167.2.15");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("198","0","Admin","2019-01-27 06:21:51","64.71.74.224");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("199","0","admin","2019-01-27 06:23:08","104.167.12.146");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("200","0","admin","2019-01-27 06:24:59","104.167.9.191");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("201","0","Admin","2019-01-27 06:24:59","104.167.3.67");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("202","0","Admin","2019-01-27 06:27:13","104.167.6.69");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("203","0","admin","2019-01-27 06:27:34","192.227.118.67");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("204","0","Admin","2019-01-27 06:29:18","192.227.96.8");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("205","0","admin","2019-01-27 06:29:50","192.227.69.106");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("206","0","admin","2019-01-27 06:31:40","8.38.88.24");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("207","0","Admin","2019-01-27 06:31:46","122.129.79.199");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("208","0","Admin","2019-01-27 06:33:41","192.227.88.113");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("209","0","Admin","2019-01-27 06:35:13","172.81.185.71");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("210","0","admin","2019-01-27 06:35:56","192.227.109.201");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("211","0","Admin","2019-01-27 06:37:03","64.71.72.55");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("212","0","admin","2019-01-27 06:38:27","192.227.67.55");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("213","0","Admin","2019-01-27 06:39:46","104.167.2.39");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("214","0","admin","2019-01-27 06:40:36","64.71.72.116");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("215","0","Admin","2019-01-27 06:41:58","192.227.76.92");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("216","0","admin","2019-01-27 06:43:40","104.167.6.69");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("217","0","Admin","2019-01-27 06:44:11","64.71.72.116");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("218","0","admin","2019-01-27 06:44:51","104.167.2.42");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("219","0","Admin","2019-01-27 06:47:00","192.227.66.182");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("220","0","admin","2019-01-27 06:48:07","192.227.88.124");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("221","0","Admin","2019-01-27 06:48:40","64.71.75.254");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("222","0","admin","2019-01-27 06:49:23","8.30.124.215");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("223","0","Admin","2019-01-27 06:50:27","8.30.124.218");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("224","0","admin","2019-01-27 06:51:53","172.81.185.232");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("225","0","Admin","2019-01-27 06:53:53","64.71.79.132");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("226","0","admin","2019-01-27 06:53:58","64.71.74.145");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("227","0","Admin","2019-01-27 06:55:13","172.81.185.232");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("228","0","admin","2019-01-27 06:56:01","104.167.9.232");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("229","0","Admin","2019-01-27 06:57:18","104.167.4.61");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("230","0","admin","2019-01-27 06:58:12","192.227.116.58");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("231","0","Admin","2019-01-27 06:59:23","192.227.67.202");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("232","0","admin","2019-01-27 07:01:31","192.227.110.59");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("233","0","Admin","2019-01-27 07:01:33","192.227.67.202");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("234","0","admin","2019-01-27 07:04:04","39.42.156.101");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("235","0","Admin","2019-01-27 07:04:11","104.167.12.146");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("236","0","admin","2019-01-27 07:04:55","8.30.124.218");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("237","0","Admin","2019-01-27 07:06:23","8.30.124.149");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("238","0","admin","2019-01-27 07:07:32","8.30.124.149");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("239","0","Admin","2019-01-27 07:08:48","64.71.74.224");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("240","0","admin","2019-01-27 07:10:42","2400:6180:0:d1::496:7001");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("241","0","Admin","2019-01-27 07:10:56","64.71.74.224");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("242","0","admin","2019-01-27 07:12:36","183.90.237.48");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("243","0","Admin","2019-01-27 07:12:59","192.227.105.219");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("244","0","admin","2019-01-27 07:14:20","64.71.73.254");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("245","0","Admin","2019-01-27 07:15:22","172.81.185.70");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("246","0","admin","2019-01-27 07:16:25","64.71.74.175");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("247","0","Admin","2019-01-27 07:17:46","192.227.108.107");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("248","0","admin","2019-01-27 07:18:40","38.130.208.196");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("249","0","Admin","2019-01-27 07:19:52","104.167.0.4");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("250","0","Admin","2019-01-27 07:21:49","8.30.124.218");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("251","0","admin","2019-01-27 07:22:23","171.97.48.254");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("252","0","admin","2019-01-27 07:22:59","192.227.67.58");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("253","0","Admin","2019-01-27 07:23:46","192.227.116.58");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("254","0","admin","2019-01-27 07:25:08","138.128.144.74");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("255","0","Admin","2019-01-27 07:26:55","104.167.2.132");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("256","0","admin","2019-01-27 07:28:05","64.71.75.132");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("257","0","Admin","2019-01-27 07:28:26","192.227.117.68");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("258","0","admin","2019-01-27 07:30:00","72.11.155.171");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("259","0","Admin","2019-01-27 07:30:29","104.167.1.72");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("260","0","admin","2019-01-27 07:31:22","64.71.79.16");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("261","0","Admin","2019-01-27 07:33:28","192.227.110.58");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("262","0","admin","2019-01-27 07:33:49","64.71.73.254");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("263","0","Admin","2019-01-27 07:34:49","104.167.1.72");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("264","0","admin","2019-01-27 07:36:27","52.35.124.126");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("265","0","Admin","2019-01-27 07:37:01","8.38.89.146");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("266","0","admin","2019-01-27 07:38:44","64.71.74.43");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("267","0","Admin","2019-01-27 07:40:05","192.227.69.105");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("268","0","admin","2019-01-27 07:40:58","64.71.79.132");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("269","0","Admin","2019-01-27 07:41:11","192.227.67.57");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("270","0","admin","2019-01-27 07:42:28","64.71.73.254");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("271","0","Admin","2019-01-27 07:43:08","64.71.79.16");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("272","0","admin","2019-01-27 07:45:28","38.130.213.70");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("273","0","Admin","2019-01-27 07:45:52","38.130.230.66");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("274","0","admin","2019-01-27 07:46:51","192.227.113.76");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("275","0","Admin","2019-01-27 07:48:41","192.227.110.57");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("276","0","admin","2019-01-27 07:48:48","64.71.74.144");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("277","0","admin","2019-01-27 07:51:47","104.167.3.67");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("278","0","Admin","2019-01-27 07:51:51","192.227.105.219");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("279","0","Admin","2019-01-27 07:52:29","217.55.220.89");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("280","0","admin","2019-01-27 07:54:17","118.219.19.234");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("281","0","Admin","2019-01-27 07:54:24","104.167.12.96");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("282","0","admin","2019-01-27 07:56:27","192.227.108.77");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("283","0","Admin","2019-01-27 07:56:33","172.81.185.71");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("284","0","admin","2019-01-27 07:57:44","64.71.72.55");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("285","0","Admin","2019-01-27 07:58:33","192.227.85.211");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("286","0","admin","2019-01-27 07:59:48","64.71.72.55");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("287","0","Admin","2019-01-27 08:00:58","8.38.89.8");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("288","0","Admin","2019-01-27 08:02:43","192.227.67.202");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("289","0","admin","2019-01-27 08:02:48","192.227.116.76");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("290","0","admin","2019-01-27 08:03:46","104.167.1.72");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("291","0","Admin","2019-01-27 08:05:10","138.128.144.75");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("292","0","admin","2019-01-27 08:06:17","192.227.80.69");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("293","0","Admin","2019-01-27 08:07:19","192.227.76.93");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("294","0","admin","2019-01-27 08:08:24","64.71.78.13");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("295","0","Admin","2019-01-27 08:11:24","192.227.109.201");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("296","0","Admin","2019-01-27 08:11:50","223.3.227.122");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("297","0","admin","2019-01-27 08:12:28","104.167.9.191");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("298","0","admin","2019-01-27 08:12:30","39.41.219.101");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("299","0","Admin","2019-01-27 08:13:53","104.167.8.145");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("300","0","admin","2019-01-27 08:14:51","104.167.2.40");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("301","0","Admin","2019-01-27 08:16:52","104.167.2.25");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("302","0","admin","2019-01-27 08:17:36","192.227.91.54");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("303","0","Admin","2019-01-27 08:17:59","192.227.105.219");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("304","0","admin","2019-01-27 08:19:07","104.167.4.67");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("305","0","Admin","2019-01-27 08:21:09","192.227.110.59");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("306","0","admin","2019-01-27 08:21:20","64.71.74.175");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("307","0","admin","2019-01-27 08:23:15","8.38.88.24");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("308","0","Admin","2019-01-27 08:23:32","197.211.34.55");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("309","0","Admin","2019-01-27 08:24:58","2a02:c207:2021:8570::1");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("310","0","admin","2019-01-27 08:25:35","192.227.109.201");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("311","0","Admin","2019-01-27 08:30:38","64.71.79.216");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("312","0","Admin","2019-01-27 08:32:13","172.81.185.71");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("313","0","admin","2019-01-27 08:32:41","91.191.7.106");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("314","0","admin","2019-01-27 08:33:18","104.167.4.67");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("315","0","Admin","2019-01-27 08:34:32","192.227.112.135");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("316","0","admin","2019-01-27 08:36:01","115.146.127.55");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("317","0","Admin","2019-01-27 08:36:26","104.167.4.67");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("318","0","Admin","2019-01-27 08:38:30","192.227.76.93");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("319","0","admin","2019-01-27 08:39:36","8.38.89.146");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("320","0","Admin","2019-01-27 08:40:46","198.101.15.90");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("321","0","admin","2019-01-27 08:41:31","64.71.79.16");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("322","0","Admin","2019-01-27 08:43:46","192.227.76.82");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("323","0","admin","2019-01-27 08:43:52","104.167.2.39");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("324","0","Admin","2019-01-27 08:45:33","104.167.3.67");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("325","0","admin","2019-01-27 08:45:33","192.227.109.201");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("326","0","Admin","2019-01-27 08:46:55","172.81.185.70");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("327","0","admin","2019-01-27 08:47:43","192.227.105.219");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("328","0","Admin","2019-01-27 08:49:22","2a02:c207:2021:8570::1");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("329","0","Admin","2019-01-27 08:50:59","192.227.118.67");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("330","0","admin","2019-01-27 08:51:54","8.30.124.149");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("331","0","admin","2019-01-27 08:52:03","109.175.97.85");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("332","0","Admin","2019-01-27 08:53:47","104.167.3.187");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("333","0","admin","2019-01-27 08:54:40","183.90.237.48");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("334","0","Admin","2019-01-27 08:55:00","192.227.109.201");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("335","0","admin","2019-01-27 08:56:13","64.71.75.254");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("336","0","Admin","2019-01-27 08:57:03","192.227.67.57");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("337","0","admin","2019-01-27 08:58:14","64.71.72.116");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("338","0","Admin","2019-01-27 08:58:49","8.38.89.8");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("339","0","admin","2019-01-27 09:01:10","116.103.211.13");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("340","0","Admin","2019-01-27 09:02:24","192.227.76.82");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("341","0","Admin","2019-01-27 09:06:05","197.211.34.55");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("342","0","admin","2019-01-27 09:07:23","192.227.91.54");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("343","0","Admin","2019-01-27 09:09:19","8.38.89.8");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("344","0","admin","2019-01-27 09:11:49","2a02:c207:2021:8570::1");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("345","0","admin","2019-01-27 09:15:01","64.71.79.41");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("346","0","Admin","2019-01-27 09:15:36","5.13.202.8");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("347","0","Admin","2019-01-27 09:17:23","192.227.67.57");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("348","0","admin","2019-01-27 09:19:39","64.71.74.224");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("349","0","Admin","2019-01-27 09:22:42","93.114.183.181");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("350","0","admin","2019-01-27 09:23:28","64.71.74.175");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("351","0","Admin","2019-01-27 09:27:38","171.61.72.130");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("352","0","admin","2019-01-27 09:28:00","192.227.67.56");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("353","0","Admin","2019-01-27 09:30:12","64.71.74.144");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("354","0","admin","2019-01-27 09:33:16","31.131.251.113");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("355","0","Admin","2019-01-27 09:35:04","104.167.2.40");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("356","0","admin","2019-01-27 09:36:59","64.71.79.6");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("357","0","Admin","2019-01-27 09:39:19","192.227.114.197");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("358","0","admin","2019-01-27 09:42:19","90.191.241.130");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("359","0","Admin","2019-01-27 09:43:51","104.167.11.8");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("360","0","admin","2019-01-27 09:46:58","192.227.110.57");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("361","0","Admin","2019-01-27 09:48:44","192.227.113.76");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("362","0","admin","2019-01-27 09:51:30","49.207.62.49");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("363","0","Admin","2019-01-27 09:53:14","64.71.74.175");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("364","0","admin","2019-01-27 09:56:22","64.71.78.76");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("365","0","Admin","2019-01-27 09:59:41","39.41.219.101");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("366","0","admin","2019-01-27 10:00:14","64.71.74.145");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("367","0","Admin","2019-01-27 10:02:47","64.71.72.243");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("368","0","admin","2019-01-27 10:06:51","192.227.105.196");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("369","0","Admin","2019-01-27 10:08:32","38.130.213.70");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("370","0","admin","2019-01-27 10:10:20","64.71.75.254");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("371","0","Admin","2019-01-27 10:12:43","38.130.227.207");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("372","0","admin","2019-01-27 10:15:48","192.227.65.59");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("373","0","Admin","2019-01-27 10:19:36","223.3.227.122");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("374","0","admin","2019-01-27 10:20:48","176.223.41.44");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("375","0","Admin","2019-01-27 10:22:32","138.128.144.74");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("376","0","admin","2019-01-27 10:24:43","138.128.144.75");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("377","0","admin","2019-01-27 10:29:45","192.227.112.135");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("378","0","Admin","2019-01-27 10:31:54","64.71.79.6");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("379","0","admin","2019-01-27 10:35:16","116.124.52.95");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("380","0","Admin","2019-01-27 10:36:44","8.38.89.146");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("381","0","admin","2019-01-27 10:39:02","38.130.208.196");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("382","0","Admin","2019-01-27 10:41:38","8.38.89.146");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("383","0","admin","2019-01-27 10:44:43","82.59.98.172");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("384","0","Admin","2019-01-27 10:46:31","192.227.67.56");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("385","0","admin","2019-01-27 10:49:54","86.59.205.182");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("386","0","Admin","2019-01-27 10:52:07","217.197.178.117");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("387","0","admin","2019-01-27 10:55:21","86.125.127.220");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("388","0","Admin","2019-01-27 10:56:19","172.81.185.71");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("389","0","admin","2019-01-27 11:00:03","31.5.205.20");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("390","0","Admin","2019-01-27 11:01:51","139.59.16.10");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("391","0","admin","2019-01-27 11:05:38","2001:4c4e:2402:c100:f9eb:d8ab:fbd4:4571");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("392","0","Admin","2019-01-27 11:07:59","119.81.178.105");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("393","0","admin","2019-01-27 11:10:07","36.81.245.171");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("394","0","Admin","2019-01-27 11:12:33","128.90.169.162");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("395","0","admin","2019-01-27 11:13:47","104.167.1.72");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("396","0","Admin","2019-01-27 11:16:17","192.227.67.58");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("397","0","admin","2019-01-27 11:18:57","104.167.2.40");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("398","0","Admin","2019-01-27 11:22:06","192.227.65.59");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("399","0","admin","2019-01-27 11:23:37","138.128.144.76");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("400","0","Admin","2019-01-27 11:25:44","192.227.85.211");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("401","0","admin","2019-01-27 11:29:20","125.160.206.27");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("402","0","Admin","2019-01-27 11:30:42","172.81.185.70");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("403","0","admin","2019-01-27 11:33:34","2607:5300:60:6c07::");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("404","0","Admin","2019-01-27 11:35:46","104.167.6.90");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("405","0","admin","2019-01-27 11:38:14","104.167.12.146");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("406","0","Admin","2019-01-27 11:40:34","8.30.124.149");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("407","0","admin","2019-01-27 11:43:06","64.71.73.254");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("408","0","Admin","2019-01-27 11:45:35","64.71.75.254");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("409","0","admin","2019-01-27 11:47:59","38.130.230.66");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("410","0","Admin","2019-01-27 11:50:33","192.227.67.55");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("411","0","admin","2019-01-27 11:53:10","192.227.105.219");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("412","0","admin","2019-01-27 11:58:17","8.30.124.215");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("413","0","Admin","2019-01-27 11:58:37","103.209.192.124");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("414","0","Admin","2019-01-27 12:01:52","38.130.225.178");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("415","0","admin","2019-01-27 12:03:14","192.227.113.76");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("416","0","Admin","2019-01-27 12:06:18","139.59.16.10");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("417","0","admin","2019-01-27 12:09:43","182.18.179.132");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("418","0","Admin","2019-01-27 12:11:04","192.227.114.197");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("419","0","admin","2019-01-27 12:13:38","104.167.9.232");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("420","0","Admin","2019-01-27 12:16:07","192.227.116.58");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("421","0","admin","2019-01-27 12:23:38","104.167.8.145");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("422","0","Admin","2019-01-27 12:26:36","2a02:c207:2021:8570::1");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("423","0","admin","2019-01-27 12:28:41","192.227.114.197");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("424","0","Admin","2019-01-27 12:34:44","64.71.72.33");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("425","0","admin","2019-01-27 12:36:57","104.167.2.39");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("426","0","Admin","2019-01-27 12:39:23","64.71.75.254");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("427","0","admin","2019-01-27 12:41:52","192.227.69.80");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("428","0","Admin","2019-01-27 12:49:42","93.114.183.181");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("429","0","admin","2019-01-27 12:51:25","172.81.185.70");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("430","0","Admin","2019-01-27 12:53:48","104.167.12.96");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("431","0","admin","2019-01-27 12:57:01","83.238.48.22");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("432","0","Admin","2019-01-27 13:00:59","31.7.61.124");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("433","0","admin","2019-01-27 13:00:59","192.227.86.113");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("434","0","Admin","2019-01-27 13:03:19","38.130.208.196");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("435","0","admin","2019-01-27 13:05:32","104.167.12.96");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("436","0","Admin","2019-01-27 13:08:30","91.225.156.203");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("437","0","admin","2019-01-27 13:10:25","104.167.12.96");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("438","0","Admin","2019-01-27 13:12:55","2409:4063:208b:6264:b89b:1190:6c54:9f00");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("439","0","Admin","2019-01-27 13:17:10","31.131.251.113");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("440","0","admin","2019-01-27 13:18:13","180.71.92.11");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("441","0","admin","2019-01-27 13:19:49","192.227.67.202");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("442","0","Admin","2019-01-27 13:23:05","88.251.12.245");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("443","0","admin","2019-01-27 13:24:41","138.128.144.76");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("444","0","Admin","2019-01-27 13:27:52","88.251.12.245");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("445","0","admin","2019-01-27 13:29:56","192.227.113.76");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("446","0","Admin","2019-01-27 13:32:19","172.81.185.70");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("447","0","admin","2019-01-27 13:35:17","36.84.229.253");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("448","0","Admin","2019-01-27 13:37:50","165.16.77.71");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("449","0","admin","2019-01-27 13:40:05","88.234.218.176");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("450","0","Admin","2019-01-27 13:42:23","95.0.74.153");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("451","0","admin","2019-01-27 13:43:41","64.71.79.6");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("452","0","Admin","2019-01-27 13:45:28","192.227.114.132");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("453","0","Admin","2019-01-27 13:51:41","45.220.22.191");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("454","0","admin","2019-01-27 13:52:55","198.101.15.90");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("455","0","Admin","2019-01-27 13:55:20","103.84.186.172");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("456","0","admin","2019-01-27 13:57:52","64.71.74.175");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("457","0","Admin","2019-01-27 14:00:11","192.227.118.67");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("458","0","admin","2019-01-27 14:02:47","104.167.2.15");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("459","0","Admin","2019-01-27 14:05:07","192.227.114.197");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("460","0","Admin","2019-01-27 14:10:39","104.167.2.15");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("461","0","admin","2019-01-27 14:12:44","8.38.88.24");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("462","0","Admin","2019-01-27 14:15:55","192.227.108.71");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("463","0","admin","2019-01-27 14:17:56","8.30.124.214");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("464","0","Admin","2019-01-27 14:22:10","218.111.12.146");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("465","0","admin","2019-01-27 14:23:09","104.167.2.42");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("466","0","Admin","2019-01-27 14:26:48","83.166.50.217");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("467","0","admin","2019-01-27 14:29:15","88.234.218.176");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("468","0","Admin","2019-01-27 14:31:15","192.227.114.197");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("469","0","admin","2019-01-27 14:33:44","64.71.79.41");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("470","0","Admin","2019-01-27 14:36:37","192.227.76.93");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("471","0","admin","2019-01-27 14:39:15","104.167.3.187");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("472","0","Admin","2019-01-27 14:42:00","192.227.69.106");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("473","0","admin","2019-01-27 14:44:38","37.190.178.143");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("474","0","Admin","2019-01-27 14:48:01","64.71.78.76");
INSERT INTO `yucqn_aiowps_failed_logins` VALUES("475","0","admin","2019-01-27 14:50:44","197.211.34.55");


DROP TABLE IF EXISTS `yucqn_aiowps_global_meta`;

CREATE TABLE `yucqn_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '1970-01-01 05:05:05',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `yucqn_aiowps_login_activity`;

CREATE TABLE `yucqn_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '1970-01-01 05:05:05',
  `logout_date` datetime NOT NULL DEFAULT '1970-01-01 05:05:05',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `yucqn_aiowps_login_activity` VALUES("1","1","jbandre","2018-02-22 20:06:50","2018-02-22 20:13:48","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("2","1","jbandre","2018-02-22 20:12:56","2018-02-22 20:13:48","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("3","1","jbandre","2018-02-22 20:15:31","2018-06-24 10:01:35","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("4","1","jbandre","2018-02-23 16:29:20","1970-01-01 05:05:05","37.171.75.222","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("5","1","jbandre","2018-02-25 18:35:14","2018-06-24 10:01:35","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("6","1","jbandre","2018-02-28 12:39:37","2018-06-24 10:01:35","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("7","1","jbandre","2018-03-06 18:22:30","2018-06-24 10:01:35","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("8","1","jbandre","2018-03-08 15:54:45","1970-01-01 05:05:05","37.169.115.116","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("9","1","jbandre","2018-03-08 18:10:24","2018-06-24 10:01:35","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("10","1","jbandre","2018-03-10 16:32:41","1970-01-01 05:05:05","37.173.116.41","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("11","1","jbandre","2018-03-10 21:48:32","2018-06-24 10:01:35","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("12","1","jbandre","2018-03-16 22:56:46","1970-01-01 05:05:05","37.173.232.238","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("13","1","jbandre","2018-03-26 10:38:06","2018-06-24 10:01:35","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("14","1","jbandre","2018-03-28 15:32:47","2018-06-24 10:01:35","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("15","1","jbandre","2018-03-28 17:01:12","2018-06-24 10:01:35","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("16","1","jbandre","2018-04-23 08:42:32","2018-06-24 10:01:35","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("17","1","jbandre","2018-04-27 14:48:30","1970-01-01 05:05:05","77.202.59.163","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("18","1","jbandre","2018-05-07 09:32:02","2018-06-24 10:01:35","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("19","1","jbandre","2018-05-08 19:09:28","2018-06-24 10:01:35","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("20","1","jbandre","2018-05-23 09:33:11","2018-06-24 10:01:35","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("21","1","jbandre","2018-06-03 09:06:19","2018-06-24 10:01:35","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("22","1","jbandre","2018-06-03 09:07:02","2018-06-24 10:01:35","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("23","1","jbandre","2018-06-24 09:34:46","2018-06-24 10:01:35","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("24","1","jbandre","2018-06-24 09:58:55","2018-06-24 10:01:35","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("25","1","jbandre","2018-06-24 10:03:45","2018-06-24 10:04:27","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("26","1","jbandre","2018-06-24 10:04:39","1970-01-01 05:05:05","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("27","1","jbandre","2018-06-24 18:20:03","1970-01-01 05:05:05","37.173.156.161","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("28","1","jbandre","2018-10-27 11:04:50","1970-01-01 05:05:05","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("29","1","jbandre","2018-11-18 12:14:25","1970-01-01 05:05:05","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("30","1","jbandre","2019-01-26 20:36:00","1970-01-01 05:05:05","82.235.21.22","","");
INSERT INTO `yucqn_aiowps_login_activity` VALUES("31","1","jbandre","2019-01-28 09:59:04","1970-01-01 05:05:05","127.0.0.1","","");


DROP TABLE IF EXISTS `yucqn_aiowps_login_lockdown`;

CREATE TABLE `yucqn_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '1970-01-01 05:05:05',
  `release_date` datetime NOT NULL DEFAULT '1970-01-01 05:05:05',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `yucqn_aiowps_permanent_block`;

CREATE TABLE `yucqn_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '1970-01-01 05:05:05',
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `yucqn_commentmeta`;

CREATE TABLE `yucqn_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `yucqn_comments`;

CREATE TABLE `yucqn_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `yucqn_links`;

CREATE TABLE `yucqn_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `yucqn_options`;

CREATE TABLE `yucqn_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=15847 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `yucqn_options` VALUES("1","siteurl","http://dswp.local","yes");
INSERT INTO `yucqn_options` VALUES("2","home","http://dswp.local","yes");
INSERT INTO `yucqn_options` VALUES("3","blogname","Distant Shores","yes");
INSERT INTO `yucqn_options` VALUES("4","blogdescription","by Jean Diorama","yes");
INSERT INTO `yucqn_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `yucqn_options` VALUES("6","admin_email","jbadiorama@gmail.com","yes");
INSERT INTO `yucqn_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `yucqn_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `yucqn_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `yucqn_options` VALUES("10","require_name_email","","yes");
INSERT INTO `yucqn_options` VALUES("11","comments_notify","","yes");
INSERT INTO `yucqn_options` VALUES("12","posts_per_rss","200","yes");
INSERT INTO `yucqn_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `yucqn_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `yucqn_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `yucqn_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `yucqn_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `yucqn_options` VALUES("18","default_category","1","yes");
INSERT INTO `yucqn_options` VALUES("19","default_comment_status","closed","yes");
INSERT INTO `yucqn_options` VALUES("20","default_ping_status","closed","yes");
INSERT INTO `yucqn_options` VALUES("21","default_pingback_flag","","yes");
INSERT INTO `yucqn_options` VALUES("22","posts_per_page","40","yes");
INSERT INTO `yucqn_options` VALUES("23","date_format","j F Y","yes");
INSERT INTO `yucqn_options` VALUES("24","time_format","G \\h i \\m\\i\\n","yes");
INSERT INTO `yucqn_options` VALUES("25","links_updated_date_format","j F Y G \\h i \\m\\i\\n","yes");
INSERT INTO `yucqn_options` VALUES("26","comment_moderation","","yes");
INSERT INTO `yucqn_options` VALUES("27","moderation_notify","","yes");
INSERT INTO `yucqn_options` VALUES("28","permalink_structure","/%post_id%/%postname%/","yes");
INSERT INTO `yucqn_options` VALUES("30","hack_file","0","yes");
INSERT INTO `yucqn_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `yucqn_options` VALUES("32","moderation_keys","","no");
INSERT INTO `yucqn_options` VALUES("33","active_plugins","a:12:{i:1;s:43:\"acf-to-rest-api-recursive-master/plugin.php\";i:2;s:41:\"acf-to-rest-api/class-acf-to-rest-api.php\";i:3;s:34:\"advanced-custom-fields-pro/acf.php\";i:5;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:6;s:67:\"better-rest-api-featured-images/better-rest-api-featured-images.php\";i:7;s:54:\"check-and-enable-gzip-compression/richards-toolbox.php\";i:8;s:33:\"color-my-posts/color-my-posts.php\";i:9;s:36:\"google-sitemap-generator/sitemap.php\";i:10;s:75:\"pinterest-pin-it-button-on-image-hover-and-post/pinterest-pin-It-button.php\";i:11;s:23:\"rest-api-tags/index.php\";i:12;s:41:\"wp-rest-api-cache/class-wp-rest-cache.php\";i:13;s:39:\"wp-rest-api-menus/wp-rest-api-menus.php\";}","yes");
INSERT INTO `yucqn_options` VALUES("34","category_base","","yes");
INSERT INTO `yucqn_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `yucqn_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `yucqn_options` VALUES("37","gmt_offset","","yes");
INSERT INTO `yucqn_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `yucqn_options` VALUES("39","recently_edited","","no");
INSERT INTO `yucqn_options` VALUES("40","template","blank","yes");
INSERT INTO `yucqn_options` VALUES("41","stylesheet","blank","yes");
INSERT INTO `yucqn_options` VALUES("42","comment_whitelist","","yes");
INSERT INTO `yucqn_options` VALUES("43","blacklist_keys","","no");
INSERT INTO `yucqn_options` VALUES("44","comment_registration","","yes");
INSERT INTO `yucqn_options` VALUES("45","html_type","text/html","yes");
INSERT INTO `yucqn_options` VALUES("46","use_trackback","0","yes");
INSERT INTO `yucqn_options` VALUES("47","default_role","subscriber","yes");
INSERT INTO `yucqn_options` VALUES("48","db_version","43764","yes");
INSERT INTO `yucqn_options` VALUES("49","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `yucqn_options` VALUES("50","upload_path","","yes");
INSERT INTO `yucqn_options` VALUES("51","blog_public","1","yes");
INSERT INTO `yucqn_options` VALUES("52","default_link_category","2","yes");
INSERT INTO `yucqn_options` VALUES("53","show_on_front","page","yes");
INSERT INTO `yucqn_options` VALUES("54","tag_base","","yes");
INSERT INTO `yucqn_options` VALUES("55","show_avatars","1","yes");
INSERT INTO `yucqn_options` VALUES("56","avatar_rating","G","yes");
INSERT INTO `yucqn_options` VALUES("57","upload_url_path","","yes");
INSERT INTO `yucqn_options` VALUES("58","thumbnail_size_w","150","yes");
INSERT INTO `yucqn_options` VALUES("59","thumbnail_size_h","150","yes");
INSERT INTO `yucqn_options` VALUES("60","thumbnail_crop","1","yes");
INSERT INTO `yucqn_options` VALUES("61","medium_size_w","300","yes");
INSERT INTO `yucqn_options` VALUES("62","medium_size_h","300","yes");
INSERT INTO `yucqn_options` VALUES("63","avatar_default","mystery","yes");
INSERT INTO `yucqn_options` VALUES("64","large_size_w","1024","yes");
INSERT INTO `yucqn_options` VALUES("65","large_size_h","1024","yes");
INSERT INTO `yucqn_options` VALUES("66","image_default_link_type","none","yes");
INSERT INTO `yucqn_options` VALUES("67","image_default_size","","yes");
INSERT INTO `yucqn_options` VALUES("68","image_default_align","","yes");
INSERT INTO `yucqn_options` VALUES("69","close_comments_for_old_posts","","yes");
INSERT INTO `yucqn_options` VALUES("70","close_comments_days_old","14","yes");
INSERT INTO `yucqn_options` VALUES("71","thread_comments","","yes");
INSERT INTO `yucqn_options` VALUES("72","thread_comments_depth","5","yes");
INSERT INTO `yucqn_options` VALUES("73","page_comments","","yes");
INSERT INTO `yucqn_options` VALUES("74","comments_per_page","50","yes");
INSERT INTO `yucqn_options` VALUES("75","default_comments_page","newest","yes");
INSERT INTO `yucqn_options` VALUES("76","comment_order","asc","yes");
INSERT INTO `yucqn_options` VALUES("77","sticky_posts","a:0:{}","yes");
INSERT INTO `yucqn_options` VALUES("78","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `yucqn_options` VALUES("79","widget_text","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `yucqn_options` VALUES("80","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `yucqn_options` VALUES("81","uninstall_plugins","a:3:{s:27:\"autoptimize/autoptimize.php\";s:21:\"autoptimize_uninstall\";s:27:\"wp-super-cache/wp-cache.php\";s:22:\"wpsupercache_uninstall\";s:41:\"wp-rest-api-cache/class-wp-rest-cache.php\";a:2:{i:0;s:13:\"WP_REST_Cache\";i:1;s:11:\"empty_cache\";}}","no");
INSERT INTO `yucqn_options` VALUES("82","timezone_string","Europe/Paris","yes");
INSERT INTO `yucqn_options` VALUES("83","page_for_posts","0","yes");
INSERT INTO `yucqn_options` VALUES("84","page_on_front","34","yes");
INSERT INTO `yucqn_options` VALUES("85","default_post_format","0","yes");
INSERT INTO `yucqn_options` VALUES("86","link_manager_enabled","0","yes");
INSERT INTO `yucqn_options` VALUES("87","finished_splitting_shared_terms","1","yes");
INSERT INTO `yucqn_options` VALUES("88","site_icon","0","yes");
INSERT INTO `yucqn_options` VALUES("89","medium_large_size_w","768","yes");
INSERT INTO `yucqn_options` VALUES("90","medium_large_size_h","0","yes");
INSERT INTO `yucqn_options` VALUES("91","initial_db_version","38590","yes");
INSERT INTO `yucqn_options` VALUES("92","yucqn_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","yes");
INSERT INTO `yucqn_options` VALUES("93","fresh_site","0","yes");
INSERT INTO `yucqn_options` VALUES("94","WPLANG","fr_FR","yes");
INSERT INTO `yucqn_options` VALUES("95","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `yucqn_options` VALUES("96","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `yucqn_options` VALUES("97","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `yucqn_options` VALUES("98","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `yucqn_options` VALUES("99","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `yucqn_options` VALUES("100","sidebars_widgets","a:2:{s:19:\"wp_inactive_widgets\";a:5:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `yucqn_options` VALUES("101","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `yucqn_options` VALUES("102","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `yucqn_options` VALUES("103","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `yucqn_options` VALUES("104","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `yucqn_options` VALUES("105","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `yucqn_options` VALUES("106","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `yucqn_options` VALUES("107","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `yucqn_options` VALUES("108","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `yucqn_options` VALUES("109","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `yucqn_options` VALUES("110","cron","a:10:{i:1548670831;a:1:{s:13:\"sm_ping_daily\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1548671680;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1548673743;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1548674691;a:1:{s:15:\"ao_cachechecker\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1548677526;a:1:{s:19:\"wpseo-reindex-links\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1548688487;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1548688513;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1548690002;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1548749343;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `yucqn_options` VALUES("111","theme_mods_twentyseventeen","a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1519139741;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}","yes");
INSERT INTO `yucqn_options` VALUES("139","recently_activated","a:0:{}","yes");
INSERT INTO `yucqn_options` VALUES("143","current_theme","","yes");
INSERT INTO `yucqn_options` VALUES("144","theme_mods_seadiorama","a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:2:{s:15:\"seadiorama-menu\";i:5;s:15:\"seadiorama_menu\";i:5;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1528009859;s:4:\"data\";a:1:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}","yes");
INSERT INTO `yucqn_options` VALUES("145","theme_switched","","yes");
INSERT INTO `yucqn_options` VALUES("146","acf_version","5.7.7","yes");
INSERT INTO `yucqn_options` VALUES("161","facebook_url","https://www.facebook.com/jbadiorama","yes");
INSERT INTO `yucqn_options` VALUES("162","instagram_url","https://www.instagram.com/jean_diorama/","yes");
INSERT INTO `yucqn_options` VALUES("167","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `yucqn_options` VALUES("221","category_children","a:0:{}","yes");
INSERT INTO `yucqn_options` VALUES("235","aiowpsec_db_version","1.9","yes");
INSERT INTO `yucqn_options` VALUES("236","aio_wp_security_configs","a:94:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:1:\"1\";s:25:\"aiowps_prevent_hotlinking\";s:0:\"\";s:28:\"aiowps_enable_login_lockdown\";s:0:\"\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";s:1:\"3\";s:24:\"aiowps_retry_time_period\";s:1:\"5\";s:26:\"aiowps_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:20:\"jbadiorama@gmail.com\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"5nob2eoeq0nd5q1h1bxo\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_woo_register_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"fsq3ept6rp1ja81w4xcf\";s:42:\"aiowps_enable_manual_registration_approval\";s:1:\"1\";s:39:\"aiowps_enable_registration_page_captcha\";s:1:\"1\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:1:\"1\";s:26:\"aiowps_db_backup_frequency\";i:1;s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";i:10;s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:20:\"jbadiorama@gmail.com\";s:27:\"aiowps_disable_file_editing\";s:1:\"1\";s:37:\"aiowps_prevent_default_wp_file_access\";s:0:\"\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:0:\"\";s:31:\"aiowps_enable_pingback_firewall\";s:0:\"\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:0:\"\";s:34:\"aiowps_block_debug_log_file_access\";s:0:\"\";s:26:\"aiowps_disable_index_views\";s:0:\"\";s:30:\"aiowps_disable_trace_and_track\";s:0:\"\";s:28:\"aiowps_forbid_proxy_comments\";s:0:\"\";s:29:\"aiowps_deny_bad_query_strings\";s:0:\"\";s:34:\"aiowps_advanced_char_string_filter\";s:0:\"\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:0:\"\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:1:\"1\";s:25:\"aiowps_fcd_scan_frequency\";i:2;s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:13:\"jpg
png
bmp\";s:24:\"aiowps_fcd_exclude_files\";s:19:\"wp-content/uploads/\";s:26:\"aiowps_send_fcd_scan_email\";s:1:\"1\";s:29:\"aiowps_fcd_scan_email_address\";s:20:\"jbadiorama@gmail.com\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:0:\"\";s:32:\"aiowps_prevent_users_enumeration\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";s:28:\"aiowps_block_fake_googlebots\";s:1:\"1\";s:22:\"aiowps_login_page_slug\";s:7:\"distant\";s:23:\"aiowps_last_backup_time\";s:19:\"2019-01-21 11:07:43\";s:25:\"aiowps_last_fcd_scan_time\";s:19:\"2019-01-20 19:35:08\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_recaptcha_site_key\";s:0:\"\";s:27:\"aiowps_recaptcha_secret_key\";s:0:\"\";s:24:\"aiowps_default_recaptcha\";s:0:\"\";}","yes");
INSERT INTO `yucqn_options` VALUES("242","new_admin_email","jbadiorama@gmail.com","yes");
INSERT INTO `yucqn_options` VALUES("251","bwp_minify_general","a:24:{s:12:\"input_minurl\";s:0:\"\";s:13:\"input_minpath\";s:0:\"\";s:15:\"input_cache_dir\";s:0:\"\";s:14:\"input_doc_root\";s:0:\"\";s:14:\"input_maxfiles\";s:2:\"10\";s:12:\"input_maxage\";s:1:\"1\";s:12:\"input_ignore\";s:38:\"admin-bar
jquery-core
jquery-migrate\";s:12:\"input_header\";s:0:\"\";s:12:\"input_direct\";s:0:\"\";s:12:\"input_footer\";s:0:\"\";s:14:\"input_oblivion\";s:0:\"\";s:18:\"input_style_ignore\";s:20:\"admin-bar
dashicons\";s:18:\"input_style_direct\";s:0:\"\";s:20:\"input_style_oblivion\";s:0:\"\";s:19:\"input_custom_buster\";s:0:\"\";s:13:\"enable_min_js\";s:0:\"\";s:14:\"enable_min_css\";s:0:\"\";s:15:\"enable_bloginfo\";s:0:\"\";s:22:\"enable_external_origin\";s:0:\"\";s:17:\"enable_css_bubble\";s:0:\"\";s:22:\"enable_cache_file_lock\";s:0:\"\";s:12:\"enable_debug\";s:0:\"\";s:18:\"select_buster_type\";s:4:\"none\";s:16:\"select_time_type\";s:5:\"86400\";}","yes");
INSERT INTO `yucqn_options` VALUES("252","bwp_minify_detector_log","a:3:{s:7:\"scripts\";a:0:{}s:6:\"styles\";a:0:{}s:6:\"groups\";a:0:{}}","yes");
INSERT INTO `yucqn_options` VALUES("253","bwp_minify_version","1.3.3","yes");
INSERT INTO `yucqn_options` VALUES("311","wpseo","a:19:{s:15:\"ms_defaults_set\";b:0;s:7:\"version\";s:5:\"9.0.2\";s:20:\"disableadvanced_meta\";b:1;s:19:\"onpage_indexability\";b:1;s:11:\"baiduverify\";s:0:\"\";s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:4:\"blog\";s:20:\"has_multiple_authors\";b:0;s:16:\"environment_type\";s:10:\"production\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:26:\"enable_cornerstone_content\";b:1;s:18:\"enable_xml_sitemap\";b:1;s:24:\"enable_text_link_counter\";b:1;s:22:\"show_onboarding_notice\";b:0;s:18:\"first_activated_on\";i:1519387925;}","yes");
INSERT INTO `yucqn_options` VALUES("313","wpseo_titles","a:65:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:0;s:9:\"separator\";s:7:\"sc-dash\";s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:42:\"%%name%%, auteur sur %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:65:\"Vous avez cherché %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:38:\"Page non trouvée %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:64:\"L’article %%POSTLINK%% est apparu en premier sur %%BLOGLINK%%.\";s:20:\"noindex-author-wpseo\";b:0;s:28:\"noindex-author-noposts-wpseo\";b:1;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:1;s:12:\"disable-date\";b:0;s:19:\"disable-post_format\";b:0;s:18:\"disable-attachment\";b:0;s:23:\"is-media-purge-relevant\";b:1;s:20:\"breadcrumbs-404crumb\";s:30:\"Erreur 404 : Page introuvable\";s:29:\"breadcrumbs-display-blog-page\";b:1;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:13:\"Archives pour\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:7:\"Accueil\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:18:\"Vous avez cherché\";s:15:\"breadcrumbs-sep\";s:7:\"&raquo;\";s:12:\"website_name\";s:0:\"\";s:11:\"person_name\";s:12:\"Jean Diorama\";s:22:\"alternate_website_name\";s:0:\"\";s:12:\"company_logo\";s:0:\"\";s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:6:\"person\";s:17:\"stripcategorybase\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:13:\"showdate-post\";b:0;s:23:\"display-metabox-pt-post\";b:1;s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:13:\"showdate-page\";b:0;s:23:\"display-metabox-pt-page\";b:1;s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:29:\"display-metabox-pt-attachment\";b:1;s:18:\"title-tax-category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:28:\"display-metabox-tax-category\";b:1;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:28:\"display-metabox-tax-post_tag\";b:1;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:31:\"display-metabox-tax-post_format\";b:1;s:23:\"noindex-tax-post_format\";b:1;s:23:\"post_types-post-maintax\";i:0;}","yes");
INSERT INTO `yucqn_options` VALUES("314","wpseo_social","a:17:{s:13:\"facebook_site\";s:35:\"https://www.facebook.com/jbadiorama\";s:13:\"instagram_url\";s:39:\"https://www.instagram.com/jean_diorama/\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:62:\"http://dswp.local/wp-content/uploads/2018/02/2.png\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:14:\"plus-publisher\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:19:\"summary_large_image\";s:11:\"youtube_url\";s:0:\"\";s:15:\"google_plus_url\";s:0:\"\";}","yes");
INSERT INTO `yucqn_options` VALUES("318","wpseo_flush_rewrite","1","yes");
INSERT INTO `yucqn_options` VALUES("319","_transient_timeout_wpseo_link_table_inaccessible","1550923926","no");
INSERT INTO `yucqn_options` VALUES("320","_transient_wpseo_link_table_inaccessible","0","no");
INSERT INTO `yucqn_options` VALUES("321","_transient_timeout_wpseo_meta_table_inaccessible","1550923926","no");
INSERT INTO `yucqn_options` VALUES("322","_transient_wpseo_meta_table_inaccessible","0","no");
INSERT INTO `yucqn_options` VALUES("433","ossdl_off_cdn_url","http://www.distant-shores.com","yes");
INSERT INTO `yucqn_options` VALUES("434","ossdl_off_blog_url","http://www.distant-shores.com","yes");
INSERT INTO `yucqn_options` VALUES("435","ossdl_off_include_dirs","wp-content,wp-includes","yes");
INSERT INTO `yucqn_options` VALUES("436","ossdl_off_exclude",".php","yes");
INSERT INTO `yucqn_options` VALUES("437","ossdl_cname","","yes");
INSERT INTO `yucqn_options` VALUES("439","wpsupercache_start","1519404455","yes");
INSERT INTO `yucqn_options` VALUES("440","wpsupercache_count","0","yes");
INSERT INTO `yucqn_options` VALUES("442","wpsupercache_gc_time","1535161584","yes");
INSERT INTO `yucqn_options` VALUES("443","wpsc_feed_list","a:0:{}","yes");
INSERT INTO `yucqn_options` VALUES("929","supercache_stats","a:3:{s:9:\"generated\";i:1525800278;s:10:\"supercache\";a:5:{s:7:\"expired\";i:0;s:6:\"cached\";i:0;s:5:\"fsize\";i:0;s:11:\"cached_list\";a:0:{}s:12:\"expired_list\";a:0:{}}s:7:\"wpcache\";a:5:{s:7:\"expired\";i:0;s:6:\"cached\";i:0;s:5:\"fsize\";i:0;s:11:\"cached_list\";a:0:{}s:12:\"expired_list\";a:0:{}}}","yes");
INSERT INTO `yucqn_options` VALUES("1028","WL_Enable_Pinit_Post","0","yes");
INSERT INTO `yucqn_options` VALUES("1029","WL_Enable_Pinit_Page","0","yes");
INSERT INTO `yucqn_options` VALUES("1030","WL_Pinit_Btn_On_Hover","true","yes");
INSERT INTO `yucqn_options` VALUES("1031","WL_Mobile_Status","1","yes");
INSERT INTO `yucqn_options` VALUES("1032","WL_Pinit_Btn_Color","white","yes");
INSERT INTO `yucqn_options` VALUES("1033","WL_Pinit_Btn_Design","","yes");
INSERT INTO `yucqn_options` VALUES("1034","WL_Pinit_Btn_Size","small","yes");
INSERT INTO `yucqn_options` VALUES("2013","autoptimize_version","2.3.0","yes");
INSERT INTO `yucqn_options` VALUES("2029","autoptimize_html","on","yes");
INSERT INTO `yucqn_options` VALUES("2030","autoptimize_html_keepcomments","","yes");
INSERT INTO `yucqn_options` VALUES("2031","autoptimize_js","on","yes");
INSERT INTO `yucqn_options` VALUES("2032","autoptimize_js_exclude","seal.js, js/jquery/jquery.js","yes");
INSERT INTO `yucqn_options` VALUES("2033","autoptimize_js_trycatch","","yes");
INSERT INTO `yucqn_options` VALUES("2034","autoptimize_js_justhead","","yes");
INSERT INTO `yucqn_options` VALUES("2035","autoptimize_js_forcehead","","yes");
INSERT INTO `yucqn_options` VALUES("2036","autoptimize_js_include_inline","","yes");
INSERT INTO `yucqn_options` VALUES("2037","autoptimize_css","","yes");
INSERT INTO `yucqn_options` VALUES("2038","autoptimize_css_exclude","admin-bar.min.css, dashicons.min.css","yes");
INSERT INTO `yucqn_options` VALUES("2039","autoptimize_css_justhead","","yes");
INSERT INTO `yucqn_options` VALUES("2040","autoptimize_css_datauris","","yes");
INSERT INTO `yucqn_options` VALUES("2041","autoptimize_css_defer","","yes");
INSERT INTO `yucqn_options` VALUES("2042","autoptimize_css_defer_inline","","yes");
INSERT INTO `yucqn_options` VALUES("2043","autoptimize_css_inline","","yes");
INSERT INTO `yucqn_options` VALUES("2044","autoptimize_css_include_inline","on","yes");
INSERT INTO `yucqn_options` VALUES("2045","autoptimize_cdn_url","","yes");
INSERT INTO `yucqn_options` VALUES("2046","autoptimize_cache_clean","0","yes");
INSERT INTO `yucqn_options` VALUES("2047","autoptimize_cache_nogzip","on","yes");
INSERT INTO `yucqn_options` VALUES("2048","autoptimize_show_adv","0","yes");
INSERT INTO `yucqn_options` VALUES("2049","autoptimize_optimize_logged","on","yes");
INSERT INTO `yucqn_options` VALUES("2050","autoptimize_optimize_checkout","","yes");
INSERT INTO `yucqn_options` VALUES("2053","autoptimize_extra_settings","a:5:{s:34:\"autoptimize_extra_checkbox_field_1\";s:1:\"1\";s:34:\"autoptimize_extra_checkbox_field_0\";s:1:\"1\";s:31:\"autoptimize_extra_radio_field_4\";s:1:\"1\";s:30:\"autoptimize_extra_text_field_2\";s:0:\"\";s:30:\"autoptimize_extra_text_field_3\";s:0:\"\";}","yes");
INSERT INTO `yucqn_options` VALUES("2450","wpseo-gsc-refresh_token","1/p_-wZzzmbHNoLvE2fYHw7oDisgBIUSD8vN2o0Tyu0oQ","yes");
INSERT INTO `yucqn_options` VALUES("2451","wpseo-gsc-access_token","a:5:{s:13:\"refresh_token\";s:45:\"1/p_-wZzzmbHNoLvE2fYHw7oDisgBIUSD8vN2o0Tyu0oQ\";s:12:\"access_token\";s:131:\"ya29.GlyMBTmZ33GeQz_775bWqqsaYsiujdmCc3CpOgmx15R4z6CNjgZa11eYJ_2IvrqLNBsq1yu5DFSyMNZwWNia2xt4OmEgMOdC3TwaUwcD8J_sZoPneSZT7quC2YAcVQ\";s:7:\"expires\";d:1522255041;s:10:\"expires_in\";i:3600;s:7:\"created\";i:1522244241;}","yes");
INSERT INTO `yucqn_options` VALUES("2452","wpseo-gsc","a:1:{s:7:\"profile\";s:30:\"http://dswp.local/\";}","yes");
INSERT INTO `yucqn_options` VALUES("2455","wpseo_gsc_issues_counts","a:2:{s:3:\"web\";a:6:{s:9:\"not_found\";a:2:{s:5:\"count\";i:8;s:10:\"last_fetch\";i:1522244242;}s:12:\"not_followed\";a:2:{s:5:\"count\";s:1:\"0\";s:10:\"last_fetch\";N;}s:13:\"access_denied\";a:2:{s:5:\"count\";s:1:\"0\";s:10:\"last_fetch\";N;}s:12:\"server_error\";a:2:{s:5:\"count\";s:1:\"0\";s:10:\"last_fetch\";N;}s:8:\"soft_404\";a:2:{s:5:\"count\";s:1:\"0\";s:10:\"last_fetch\";N;}s:5:\"other\";a:2:{s:5:\"count\";s:1:\"0\";s:10:\"last_fetch\";N;}}s:15:\"smartphone_only\";a:9:{s:9:\"not_found\";a:2:{s:5:\"count\";s:1:\"0\";s:10:\"last_fetch\";N;}s:12:\"not_followed\";a:2:{s:5:\"count\";s:1:\"0\";s:10:\"last_fetch\";N;}s:13:\"access_denied\";a:2:{s:5:\"count\";s:1:\"0\";s:10:\"last_fetch\";N;}s:12:\"server_error\";a:2:{s:5:\"count\";s:1:\"0\";s:10:\"last_fetch\";N;}s:8:\"soft_404\";a:2:{s:5:\"count\";s:1:\"0\";s:10:\"last_fetch\";N;}s:7:\"roboted\";a:2:{s:5:\"count\";s:1:\"0\";s:10:\"last_fetch\";N;}s:16:\"faulty_redirects\";a:2:{s:5:\"count\";s:1:\"0\";s:10:\"last_fetch\";N;}i:0;a:2:{s:5:\"count\";s:1:\"0\";s:10:\"last_fetch\";N;}s:5:\"other\";a:2:{s:5:\"count\";s:1:\"0\";s:10:\"last_fetch\";N;}}}","yes");
INSERT INTO `yucqn_options` VALUES("2461","sm_rewrite_done","$Id: sitemap-loader.php 937300 2014-06-23 18:04:11Z arnee $","yes");
INSERT INTO `yucqn_options` VALUES("2463","sm_options","a:52:{s:18:\"sm_b_prio_provider\";s:41:\"GoogleSitemapGeneratorPrioByCountProvider\";s:9:\"sm_b_ping\";b:1;s:10:\"sm_b_stats\";b:0;s:12:\"sm_b_pingmsn\";b:1;s:12:\"sm_b_autozip\";b:1;s:11:\"sm_b_memory\";s:0:\"\";s:9:\"sm_b_time\";i:-1;s:18:\"sm_b_style_default\";b:1;s:10:\"sm_b_style\";s:0:\"\";s:12:\"sm_b_baseurl\";s:0:\"\";s:11:\"sm_b_robots\";b:1;s:9:\"sm_b_html\";b:1;s:12:\"sm_b_exclude\";a:0:{}s:17:\"sm_b_exclude_cats\";a:0:{}s:10:\"sm_in_home\";b:1;s:11:\"sm_in_posts\";b:1;s:15:\"sm_in_posts_sub\";b:0;s:11:\"sm_in_pages\";b:1;s:10:\"sm_in_cats\";b:0;s:10:\"sm_in_arch\";b:0;s:10:\"sm_in_auth\";b:0;s:10:\"sm_in_tags\";b:0;s:9:\"sm_in_tax\";a:0:{}s:17:\"sm_in_customtypes\";a:0:{}s:13:\"sm_in_lastmod\";b:1;s:10:\"sm_cf_home\";s:5:\"daily\";s:11:\"sm_cf_posts\";s:6:\"weekly\";s:11:\"sm_cf_pages\";s:7:\"monthly\";s:10:\"sm_cf_cats\";s:6:\"weekly\";s:10:\"sm_cf_auth\";s:6:\"weekly\";s:15:\"sm_cf_arch_curr\";s:5:\"daily\";s:14:\"sm_cf_arch_old\";s:6:\"weekly\";s:10:\"sm_cf_tags\";s:6:\"weekly\";s:10:\"sm_pr_home\";d:1;s:11:\"sm_pr_posts\";d:0.6;s:15:\"sm_pr_posts_min\";d:0.2;s:11:\"sm_pr_pages\";d:0.6;s:10:\"sm_pr_cats\";d:0.3;s:10:\"sm_pr_arch\";d:0.3;s:10:\"sm_pr_auth\";d:0.3;s:10:\"sm_pr_tags\";d:0.3;s:12:\"sm_i_donated\";b:0;s:17:\"sm_i_hide_donated\";b:0;s:17:\"sm_i_install_date\";i:1520932867;s:16:\"sm_i_hide_survey\";b:1;s:14:\"sm_i_hide_note\";b:0;s:15:\"sm_i_hide_works\";b:0;s:16:\"sm_i_hide_donors\";b:0;s:9:\"sm_i_hash\";s:20:\"fd6f51d8e79b475f6977\";s:13:\"sm_i_lastping\";i:1548666073;s:16:\"sm_i_supportfeed\";b:1;s:22:\"sm_i_supportfeed_cache\";i:1548523610;}","yes");
INSERT INTO `yucqn_options` VALUES("2895","sm_status","O:28:\"GoogleSitemapGeneratorStatus\":4:{s:39:\"\0GoogleSitemapGeneratorStatus\0startTime\";d:1548666072.891746;s:37:\"\0GoogleSitemapGeneratorStatus\0endTime\";d:1548666073.451977;s:41:\"\0GoogleSitemapGeneratorStatus\0pingResults\";a:2:{s:6:\"google\";a:5:{s:9:\"startTime\";d:1548666072.900017;s:7:\"endTime\";d:1548666072.969846;s:7:\"success\";b:1;s:3:\"url\";s:92:\"http://www.google.com/webmasters/sitemaps/ping?sitemap=http%3A%2F%2Fdswp.local%2Fsitemap.xml\";s:4:\"name\";s:6:\"Google\";}s:4:\"bing\";a:5:{s:9:\"startTime\";d:1548666072.971647;s:7:\"endTime\";d:1548666073.435746;s:7:\"success\";b:1;s:3:\"url\";s:85:\"http://www.bing.com/webmaster/ping.aspx?siteMap=http%3A%2F%2Fdswp.local%2Fsitemap.xml\";s:4:\"name\";s:4:\"Bing\";}}s:38:\"\0GoogleSitemapGeneratorStatus\0autoSave\";b:1;}","no");
INSERT INTO `yucqn_options` VALUES("3802","wpseo_gsc_last_fetch","1522244241","no");
INSERT INTO `yucqn_options` VALUES("3803","wpseo-gsc-issues-web-not_found","a:8:{i:0;a:6:{s:3:\"url\";s:45:\"/141/just-the-sea-1-1/wp-admin/admin-ajax.php\";s:14:\"first_detected\";s:12:\"13 mars 2018\";s:18:\"first_detected_raw\";s:10:\"1520915775\";s:12:\"last_crawled\";s:12:\"13 mars 2018\";s:16:\"last_crawled_raw\";s:10:\"1520915775\";s:13:\"response_code\";i:404;}i:1;a:6:{s:3:\"url\";s:42:\"/101/the-icy-river/wp-admin/admin-ajax.php\";s:14:\"first_detected\";s:12:\"13 mars 2018\";s:18:\"first_detected_raw\";s:10:\"1520907635\";s:12:\"last_crawled\";s:12:\"13 mars 2018\";s:16:\"last_crawled_raw\";s:10:\"1520907635\";s:13:\"response_code\";i:404;}i:2;a:6:{s:3:\"url\";s:40:\"/211/whale-bones/wp-admin/admin-ajax.php\";s:14:\"first_detected\";s:12:\"12 mars 2018\";s:18:\"first_detected_raw\";s:10:\"1520892472\";s:12:\"last_crawled\";s:12:\"12 mars 2018\";s:16:\"last_crawled_raw\";s:10:\"1520892472\";s:13:\"response_code\";i:404;}i:3;a:6:{s:3:\"url\";s:38:\"/95/aivazovsky/wp-admin/admin-ajax.php\";s:14:\"first_detected\";s:12:\"12 mars 2018\";s:18:\"first_detected_raw\";s:10:\"1520884386\";s:12:\"last_crawled\";s:12:\"12 mars 2018\";s:16:\"last_crawled_raw\";s:10:\"1520884386\";s:13:\"response_code\";i:404;}i:4;a:6:{s:3:\"url\";s:43:\"/72/green-sea-shore/wp-admin/admin-ajax.php\";s:14:\"first_detected\";s:12:\"13 mars 2018\";s:18:\"first_detected_raw\";s:10:\"1520914078\";s:12:\"last_crawled\";s:12:\"13 mars 2018\";s:16:\"last_crawled_raw\";s:10:\"1520914078\";s:13:\"response_code\";i:404;}i:5;a:6:{s:3:\"url\";s:41:\"/93/saint-laurent/wp-admin/admin-ajax.php\";s:14:\"first_detected\";s:12:\"12 mars 2018\";s:18:\"first_detected_raw\";s:10:\"1520898316\";s:12:\"last_crawled\";s:12:\"12 mars 2018\";s:16:\"last_crawled_raw\";s:10:\"1520898316\";s:13:\"response_code\";i:404;}i:6;a:6:{s:3:\"url\";s:38:\"/152/that-fish/wp-admin/admin-ajax.php\";s:14:\"first_detected\";s:12:\"12 mars 2018\";s:18:\"first_detected_raw\";s:10:\"1520881227\";s:12:\"last_crawled\";s:12:\"12 mars 2018\";s:16:\"last_crawled_raw\";s:10:\"1520881227\";s:13:\"response_code\";i:404;}i:7;a:6:{s:3:\"url\";s:39:\"/66/white-shore/wp-admin/admin-ajax.php\";s:14:\"first_detected\";s:12:\"12 mars 2018\";s:18:\"first_detected_raw\";s:10:\"1520891446\";s:12:\"last_crawled\";s:12:\"12 mars 2018\";s:16:\"last_crawled_raw\";s:10:\"1520891446\";s:13:\"response_code\";i:404;}}","no");
INSERT INTO `yucqn_options` VALUES("4292","auto_core_update_notified","a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:20:\"jbadiorama@gmail.com\";s:7:\"version\";s:5:\"4.9.9\";s:9:\"timestamp\";i:1544695102;}","no");
INSERT INTO `yucqn_options` VALUES("5856","jb_active","no","yes");
INSERT INTO `yucqn_options` VALUES("5857","jba_display_sur","3","yes");
INSERT INTO `yucqn_options` VALUES("5858","page_select","a:3:{i:0;s:4:\"home\";i:1;s:1:\"9\";i:2;s:2:\"34\";}","yes");
INSERT INTO `yucqn_options` VALUES("5859","popup_content","test de magnifique popup<img class=\"alignnone size-medium wp-image-268\" src=\"http://dswp.local/wp-content/uploads/2018/03/bones-300x300.jpg\" alt=\"Whale bones at Yttygran\" width=\"300\" height=\"300\" /> à publier vite","yes");
INSERT INTO `yucqn_options` VALUES("6136","preload_cache_counter","a:2:{s:1:\"c\";i:0;s:1:\"t\";i:1535126132;}","yes");
INSERT INTO `yucqn_options` VALUES("8643","theme_mods_blank","a:2:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}}","yes");
INSERT INTO `yucqn_options` VALUES("13907","rewrite_rules","a:111:{s:34:\"sitemap(-+([a-zA-Z0-9_-]+))?\\.xml$\";s:40:\"index.php?xml_sitemap=params=$matches[2]\";s:38:\"sitemap(-+([a-zA-Z0-9_-]+))?\\.xml\\.gz$\";s:49:\"index.php?xml_sitemap=params=$matches[2];zip=true\";s:35:\"sitemap(-+([a-zA-Z0-9_-]+))?\\.html$\";s:50:\"index.php?xml_sitemap=params=$matches[2];html=true\";s:38:\"sitemap(-+([a-zA-Z0-9_-]+))?\\.html.gz$\";s:59:\"index.php?xml_sitemap=params=$matches[2];html=true;zip=true\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=34&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:74:\"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:69:\"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:50:\"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:62:\"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:44:\"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:61:\"date/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:56:\"date/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:37:\"date/([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:49:\"date/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:31:\"date/([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:48:\"date/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:43:\"date/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:24:\"date/([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:36:\"date/([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:18:\"date/([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:34:\"[0-9]+/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:44:\"[0-9]+/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:64:\"[0-9]+/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"[0-9]+/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"[0-9]+/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:40:\"[0-9]+/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:25:\"([0-9]+)/([^/]+)/embed/?$\";s:51:\"index.php?p=$matches[1]&name=$matches[2]&embed=true\";s:29:\"([0-9]+)/([^/]+)/trackback/?$\";s:45:\"index.php?p=$matches[1]&name=$matches[2]&tb=1\";s:49:\"([0-9]+)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:57:\"index.php?p=$matches[1]&name=$matches[2]&feed=$matches[3]\";s:44:\"([0-9]+)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:57:\"index.php?p=$matches[1]&name=$matches[2]&feed=$matches[3]\";s:37:\"([0-9]+)/([^/]+)/page/?([0-9]{1,})/?$\";s:58:\"index.php?p=$matches[1]&name=$matches[2]&paged=$matches[3]\";s:44:\"([0-9]+)/([^/]+)/comment-page-([0-9]{1,})/?$\";s:58:\"index.php?p=$matches[1]&name=$matches[2]&cpage=$matches[3]\";s:33:\"([0-9]+)/([^/]+)(?:/([0-9]+))?/?$\";s:57:\"index.php?p=$matches[1]&name=$matches[2]&page=$matches[3]\";s:23:\"[0-9]+/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:33:\"[0-9]+/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:53:\"[0-9]+/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:48:\"[0-9]+/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:48:\"[0-9]+/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:29:\"[0-9]+/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:28:\"[0-9]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:38:\"[0-9]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:58:\"[0-9]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"[0-9]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"[0-9]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:34:\"[0-9]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:17:\"([0-9]+)/embed/?$\";s:34:\"index.php?p=$matches[1]&embed=true\";s:21:\"([0-9]+)/trackback/?$\";s:28:\"index.php?p=$matches[1]&tb=1\";s:41:\"([0-9]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?p=$matches[1]&feed=$matches[2]\";s:36:\"([0-9]+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?p=$matches[1]&feed=$matches[2]\";s:29:\"([0-9]+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?p=$matches[1]&paged=$matches[2]\";s:36:\"([0-9]+)/comment-page-([0-9]{1,})/?$\";s:41:\"index.php?p=$matches[1]&cpage=$matches[2]\";s:25:\"([0-9]+)(?:/([0-9]+))?/?$\";s:40:\"index.php?p=$matches[1]&page=$matches[2]\";s:17:\"[0-9]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:27:\"[0-9]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:47:\"[0-9]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:42:\"[0-9]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:42:\"[0-9]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:23:\"[0-9]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}","yes");
INSERT INTO `yucqn_options` VALUES("13970","rest_cache_options","a:1:{s:7:\"timeout\";a:2:{s:6:\"length\";s:1:\"1\";s:6:\"period\";s:6:\"604800\";}}","yes");
INSERT INTO `yucqn_options` VALUES("15695","_transient_timeout_feed_d21d2a68bac70d38fb7f9a7bd3d1725e","1549128410","no");
INSERT INTO `yucqn_options` VALUES("15696","_transient_feed_d21d2a68bac70d38fb7f9a7bd3d1725e","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:5:\"

	
	\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:371:\"

		
		
		
		
		
		
		

		
		
			
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

				
				

							
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"WordPress.org Forums » [Google XML Sitemaps] Support\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/support/plugin/google-sitemap-generator/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 26 Jan 2019 17:16:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"https://bbpress.org/?v=2.6-alpha-6091\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:30:{i:0;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/support/topic/my-sitemap-not-indexed-by-google/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"my sitemap not indexed by google\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/support/topic/my-sitemap-not-indexed-by-google/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 24 Jan 2019 12:05:56 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:233:\"
						
						<p>Replies: 0</p>
						<p>i submit my website (<a href=\"http://mvi9.com\" rel=\"nofollow\">http://mvi9.com</a>) site map to google but that site map not indexing or not show number of submitted url or etc</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"jbbusa11\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/support/topic/my-sitemap-dont-work-anymore/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"My Sitemap Don&amp;#8217;t work anymore\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/support/topic/my-sitemap-dont-work-anymore/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 24 Jan 2019 10:18:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:222:\"
						
						<p>Replies: 0</p>
						<p>Hello Everyone, when i enable any cache plugin my sitemap don&#8217;t work and blank please help me how can i resolve this issue, i tested around 10+ cache plugins.</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"alizahidmemon2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wordpress.org/support/topic/how-remove-limitatino-50000-url/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"how remove limitatino 50000 url\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wordpress.org/support/topic/how-remove-limitatino-50000-url/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 19 Jan 2019 08:37:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:143:\"
						
						<p>Replies: 0</p>
						<p>hi how i can remove limitaion 50000 url in sitemap because i have +50000 link thanks.</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"mansour\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"https://wordpress.org/support/topic/sitemap-occure-error-when-request-without-www/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"Sitemap occure ERROR when request without &amp;#8220;www&amp;#8221;\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"https://wordpress.org/support/topic/sitemap-occure-error-when-request-without-www/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 18 Jan 2019 21:00:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:727:\"
						
						<p>Replies: 0</p>
						<p>Hello and thankyou for your nice plugin.<br />
.<br />
My wordpress and google SEO consul set to <a href=\"http://www.mysite.com\" rel=\"nofollow\">http://www.mysite.com</a>. but google sitemap section receive sitemap filename without prefix address and looking for site map without &#8220;www&#8221; on domain.<br />
.<br />
and site map list occur ERROR when request without &#8220;www&#8221;. </p>
<p><a href=\"http://mellatyadak.com/sitemap.xml\" rel=\"nofollow\">http://mellatyadak.com/sitemap.xml</a>  &#8211;&gt; error<br />
<a href=\"http://www.mellatyadak.com/sitemap.xml\" rel=\"nofollow\">http://www.mellatyadak.com/sitemap.xml</a>  &#8211;&gt; work fine</p>
<p>thankyou</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"saeeded\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"https://wordpress.org/support/topic/trojan-script-agent-fjsfyc-in-plugin-warning/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"Trojan.Script.Agent.fjsfyc in plugin warning\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"https://wordpress.org/support/topic/trojan-script-agent-fjsfyc-in-plugin-warning/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Jan 2019 23:19:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:311:\"
						
						<p>Replies: 0</p>
						<p>SHA-256	7aef43570f8cd21d47a7ac39e654b351a1eddc53f88b94be1dcd3488f60c38b3<br />
File name	google-sitemap-generator.4.1.0.zip</p>
<p>I checked this file through virustotal service, found a virus in this plugin, it previously infected a hosted working site</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"sid645\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"https://wordpress.org/support/topic/domdocumentloadxml-input-is-not-proper-utf-8/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"DOMDocument::loadXML(): Input is not proper UTF-8\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"https://wordpress.org/support/topic/domdocumentloadxml-input-is-not-proper-utf-8/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 16 Jan 2019 12:38:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:376:\"
						
						<p>Replies: 0</p>
						<p>I am getting warnings of </p>
<p>Warning: DOMDocument::loadXML(): Input is not proper UTF-8, indicate encoding !<br />
Bytes: 0xFF 0xFF 0x42 0xF9 in Entity, line: 3155 in /var/www/vhosts/domain.com/httpdocs/wp-content/plugins/google-sitemap-generator/sitemap-core.php on line 1653</p>
<p>Any ideas please?<br />
Thanks</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"jennyhp\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"https://wordpress.org/support/topic/add-pagination-to-sitemap/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Add pagination to sitemap\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"https://wordpress.org/support/topic/add-pagination-to-sitemap/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 12 Jan 2019 06:44:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:182:\"
						
						<p>Replies: 1</p>
						<p>Hello, I want to add pagination pages to sitemap so that cache plugin can preload them properly. please help me to done this</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"babuee\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/support/topic/google-xml-sitemap-doesnt-work/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"Google XML Sitemap doesn&amp;#8217;t work\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/support/topic/google-xml-sitemap-doesnt-work/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Jan 2019 18:48:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:264:\"
						
						<p>Replies: 4</p>
						<p>Hi there,<br />
I have installed your sitemap and It was working well, however, it is not working since last 6 days and it shows error. you can check the link.<br />
please help me with that.</p>
<p>Regards</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"HMD521\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/support/topic/updated-blog-links/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"updated blog links\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/support/topic/updated-blog-links/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Jan 2019 10:36:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:415:\"
						
						<p>Replies: 1</p>
						<p>hello, I recently updated how links format on url it used to show date and year and changed that so now links only show post&#8217;s name.<br />
anyways my sitemap.xml still shows the old links of my posts:<br />
old links:</p>
<p>mysite.com/2019/01/postname</p>
<p>new links:<br />
mysite.com/postname </p>
<p>how can I update all the links on sitemap.xml?</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"silv3rline\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"https://wordpress.org/support/topic/google-xml-sitemaps-not-work-with-relative-url-plugin/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"&amp;#8220;Google XML Sitemaps&amp;#8221; not work with &amp;#8220;Relative URL&amp;#8221; plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"https://wordpress.org/support/topic/google-xml-sitemaps-not-work-with-relative-url-plugin/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Jan 2019 04:28:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:722:\"
						
						<p>Replies: 1</p>
						<p>&#8220;Google XML Sitemaps&#8221; not work with &#8220;Relative URL&#8221; plugin, and if open sitemap link on posts via /sitemap-pt-post-2017-10.xml then in PHP error log we see</p>
<pre><code>[10-Jan-2019 01:12:06 UTC] PHP Warning:  strpos(): Empty needle in /.../www/wp-content/plugins/google-sitemap-generator/sitemap-builder.php on line 203
[10-Jan-2019 01:12:06 UTC] PHP Warning:  strpos(): Empty needle in /.../www/wp-content/plugins/google-sitemap-generator/sitemap-builder.php on line 203</code></pre>
<p>same result if in wp-config we set:</p>
<pre><code>define(&#039;WP_HOME&#039;, &#039;/&#039;);
define(&#039;WP_SITEURL&#039;, &#039;/&#039;);</code></pre>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"itmag.pro\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/support/topic/error-too-many-urls/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Error Too many URLs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/support/topic/error-too-many-urls/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 09 Jan 2019 10:58:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:308:\"
						
						<p>Replies: 0</p>
						<p>Hi,</p>
<p>how can i set to limit not more then 50,000 ? in google webmaster getting error.</p>
<p>screen link here<br />
<a href=\"http://myprintscreen.com/s/zjru/74c3db4a1a\" rel=\"nofollow\">http://myprintscreen.com/s/zjru/74c3db4a1a</a></p>
<p>Thanks</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Muhammad Jahangir\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/support/topic/my-sitemap-doesnt-work-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"My siteMap Doesn&amp;#8217;t work\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/support/topic/my-sitemap-doesnt-work-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 08 Jan 2019 14:58:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:266:\"
						
						<p>Replies: 1</p>
						<p>Dear Support team,</p>
<p>I have installed your plugin a few weeks ago and it was working well, however, your plugin doesn&#8217;t work anymore and shows error.</p>
<p>could you please help me?</p>
<p>Regards</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"HMD521\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/support/topic/please-support-video-sitemap/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"Please support Video Sitemap!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/support/topic/please-support-video-sitemap/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 05 Jan 2019 00:50:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:227:\"
						
						<p>Replies: 0</p>
						<p>My video website(embeded code im my all post). But i dont like use yoast seo plugin or all one seopack plugin.<br />
im ready donate for author for that function! Thanks</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Anh Tuấn\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/support/topic/issue-with-sitemap-url/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Issue with sitemap URL\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/support/topic/issue-with-sitemap-url/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 28 Dec 2018 07:09:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:516:\"
						
						<p>Replies: 3</p>
						<p>Hi,</p>
<p>In my <a href=\"https://dheivegam.com\" rel=\"nofollow\">website</a> I&#8217;m using Google XML Sitemaps to index post. At the same time I&#8217;m using google news sitemap plugin to index my google news. The problem here is when I&#8217;m trying to access the news sitemap, the google sitemap pugin is restricting it.</p>
<p>news sitemap url : <a href=\"https://dheivegam.com/sitemap-news.xml\" rel=\"nofollow\">https://dheivegam.com/sitemap-news.xml</a></p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"satheeshraj\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://wordpress.org/support/topic/index-google-news/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Index google news\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://wordpress.org/support/topic/index-google-news/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 23 Dec 2018 19:56:54 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:145:\"
						
						<p>Replies: 0</p>
						<p>Will this plugin create a sitemap for Google news or we need a separate plugin for it.?</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"satheeshraj\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"https://wordpress.org/support/topic/multisite-please-clean-answer/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"Multisite Please clean answer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"https://wordpress.org/support/topic/multisite-please-clean-answer/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 Dec 2018 08:22:25 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:267:\"
						
						<p>Replies: 1</p>
						<p>I have a miltiste 1 = Landingpage, 2 = website, 3 = woocommerce Shop, 4 = second website with seperate Woocommerce Shop</p>
<p>Do i have to make sitemap in each site?</p>
<p>Please a clean answer</p>
<p>Thanks</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Patrick Horemans\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/support/topic/notify-bing-update-url/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Notify Bing update URL\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/support/topic/notify-bing-update-url/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 19 Dec 2018 18:56:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:721:\"
						
						<p>Replies: 1</p>
						<p>Hi Arne, </p>
<p>thanks for the recent update! Here a heads up that the Bing notify url has changed some time ago, it used to be: (currently line 1900 in sitemap-core.php)</p>
<p><code>&quot;url&quot; =&gt; &quot;http://www.bing.com/webmaster/ping.aspx?siteMap=%s&quot;,</code></p>
<p>but i think it now should be: </p>
<p><code>&quot;url&quot; =&gt; &quot;http://www.bing.com/ping?sitemap=%s&quot;,</code></p>
<p>As the old setup generates creates this error message from Bing: </p>
<p><code>We did not receive your sitemap. Please submit it using the following format: http://www.bing.com/ping?sitemap=[your sitemap web address]</code></p>
<p>Greetings, damsko.</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"damsko\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://wordpress.org/support/topic/external-xslt-adds-trailing-slash/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"External XSLT adds trailing slash\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://wordpress.org/support/topic/external-xslt-adds-trailing-slash/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 19 Dec 2018 18:56:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:201:\"
						
						<p>Replies: 1</p>
						<p>The latest version automatically adds a trailing slash to external XSL files, which makes my site 404 this URI.  The code is in sitemap-ui.php.</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"0xd34db33f\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"https://wordpress.org/support/topic/problem-with-parsing-external-sitemap-xsl/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"Problem with parsing external sitemap.xsl\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"https://wordpress.org/support/topic/problem-with-parsing-external-sitemap-xsl/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 19 Dec 2018 10:00:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:654:\"
						
						<p>Replies: 3</p>
						<p>Hi from Germany,</p>
<p>to better match the output of the sitemap.xml, I tried to assign a sitemap.xsl out of my theme folder. I inserted ../../stage/themes/sixtyseven/sitemap.xsl in the settings input and the path resolves to the proper location (tried it with an absolute url as well, just to be sure). Unfortunately I get a syntax error. After expecting that a while, I came to the solution: Seems that the mod_rewrite doesn&#8217;t like the url and throws a 404.</p>
<p>Any idea what to add to the .htaccess to ignore my external sitemap.xsl from rewriting?</p>
<p>Help is gladly appreciated!</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"sixtyseven\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"https://wordpress.org/support/topic/how-to-remove-pages-marked-as-noindex-from-sitemap/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"How to Remove Pages Marked as NOINDEX from Sitemap?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"https://wordpress.org/support/topic/how-to-remove-pages-marked-as-noindex-from-sitemap/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 18 Dec 2018 16:08:54 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:457:\"
						
						<p>Replies: 2</p>
						<p>When Google advises that a page I created is marked as NOINDEX (example: Privacy Policy), why is it showing up in my sitemap created by your plugin?</p>
<p><strong>MORE IMPORTANTLY</strong><br />
How do I exclude an area, page or post of a website from appearing in the sitemap (example of area: categories) as apparently this is what is confusing Google Search Console?</p>
<p>Thank you in advance.</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"Trible\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"https://wordpress.org/support/topic/message-from-google-saying-submitted-url-marked-noindex/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"Message from Google saying Submitted URL marked ‘noindex’\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"https://wordpress.org/support/topic/message-from-google-saying-submitted-url-marked-noindex/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 14 Dec 2018 19:50:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:934:\"
						
						<p>Replies: 19</p>
						<p>I received a notice from Google saying that a submitted URL is marked noindex.  When I click on resolve issue, it lists:<br />
<a href=\"http://www.40andholding.com/sitemap.html\" rel=\"nofollow\">http://www.40andholding.com/sitemap.html</a></p>
<p>The post they are saying is noindexed is my latest:<br />
<a href=\"http://www.40andholding.com/sitemap-pt-post-2018-12.html\" rel=\"nofollow\">http://www.40andholding.com/sitemap-pt-post-2018-12.html</a></p>
<p>Here is the notice I received:</p>
<p>Search Console has identified that your site is affected by 1 new Coverage related issue. This means that Coverage may be negatively affected in Google Search results. We encourage you to fix this issue.</p>
<p>New issue found:</p>
<p>Submitted URL marked ‘noindex’</p>
<p>Does anyone know what the problem is?  I have no idea how to resolve this.  This has never happened before!</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"40andholding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/support/topic/wpml-incompatibility-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"wpml incompatibility ?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/support/topic/wpml-incompatibility-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 13 Dec 2018 15:52:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:335:\"
						
						<p>Replies: 1</p>
						<p>Please let me know if there are any incompatibility with wpml pluging<br />
 when it is set up to use different domain per language</p>
<p>My problem its that I dont uderstand why I get a &#8220;noindex tag&#8221;  alarm from<br />
google search console&#8230;</p>
<p>thank you</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"asiletti\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/support/topic/php-7-2-compatibility-56/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"PHP 7.2 compatibility\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/support/topic/php-7-2-compatibility-56/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 12 Dec 2018 16:18:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:148:\"
						
						<p>Replies: 2</p>
						<p>Hi, please can you tell me if this plugin PHP 7.2 compatible?</p>
<p>Thanks,</p>
<p>Claire</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"abrightclearweb\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://wordpress.org/support/topic/error-on-line-1-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Error on Line 1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://wordpress.org/support/topic/error-on-line-1-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 08 Dec 2018 08:26:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:455:\"
						
						<p>Replies: 2</p>
						<p>This is the message I get</p>
<p>This page contains the following errors:<br />
error on line 2 at column 6: XML declaration allowed only at the start of the document<br />
Below is a rendering of the page up to the first error.</p>
<p>Used the debug option and looks like the XML sitemaps are getting generated. I am a business guy no tech smarts. Just like some assurance, the sitemaps are going</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"arvindra\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wordpress.org/support/topic/changing-url-from-http-to-https/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Changing url from http to https\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wordpress.org/support/topic/changing-url-from-http-to-https/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 05 Dec 2018 00:26:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:313:\"
						
						<p>Replies: 1</p>
						<p>Hi there&#8230;</p>
<p>I was going to migrate my url from http to https&#8230;</p>
<p>If im using https url, do i just need to click update from cpanel settings and new xml sitemap will automatically change to https?</p>
<p>Pls reply ASAP</p>
<p>Thank you</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"tg_kamarul\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:116:\"https://wordpress.org/support/topic/error-on-line-1-at-column-82-xml-declaration-allowed-only-at-the-start-of-the-d/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:166:\"&lt;span class=&quot;resolved&quot; aria-label=&quot;Resolved&quot; title=&quot;Topic is resolved.&quot;&gt;&lt;/span&gt;error on line 1 at column 82: XML declaration\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:116:\"https://wordpress.org/support/topic/error-on-line-1-at-column-82-xml-declaration-allowed-only-at-the-start-of-the-d/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 28 Nov 2018 22:30:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:711:\"
						
						<p>Replies: 4</p>
						<p>I&#8217;m getting the following error with my sitemap.xml file</p>
<p>error on line 1 at column 82: XML declaration allowed only at the start of the document</p>
<p>It appears that there is a bunch of extra white space being added to the start of the xml file.</p>
<p>Any ideas as to what is adding the extra white space?</p>


<ul id=\"bbp-topic-revision-log-10927858\" class=\"bbp-topic-revision-log\">

	<li id=\"bbp-topic-revision-log-10927858-item-10927860\" class=\"bbp-topic-revision-log-item\">
		This topic was modified 1 month, 4 weeks ago by <a href=\"https://wordpress.org/support/users/wasca/\" title=\"View Wasca&#039;s profile\">Wasca</a>.
	</li>

</ul>

						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"Wasca\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://wordpress.org/support/topic/increase-ping-frequency-or-get-method/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"Increase Ping Frequency or Get Method\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://wordpress.org/support/topic/increase-ping-frequency-or-get-method/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 28 Nov 2018 20:47:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:502:\"
						
						<p>Replies: 0</p>
						<p>Hi guys, I used to have the old version of Google XML Sitemap and it had ability to use a Get method so I could rebuild the sitemap using a cron job. </p>
<p>Now the new version doesnt have that. </p>
<p>My posts come in every 2 minutes and I need to send a ping to Google every 30 minutes or so. </p>
<p>How do I tweak the latest version to ping every 30 minutes? Also, is there a way to use GET method and use a cron job?</p>
<p>Any thoughts?</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/support/topic/pages-not-listed-how-to-rank/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"Pages not listed, how to rank?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/support/topic/pages-not-listed-how-to-rank/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 27 Nov 2018 18:40:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:593:\"
						
						<p>Replies: 0</p>
						<p>Hi,</p>
<p>I want to publish pages that don&#8217;t appear on the home page but still be able to turn up on Google (for example to start ranking for upcoming games). I have seen other webmasters do this without any internal links to that page from what I could tell.</p>
<p>Will Google rank a page that is not internally linked? If not, how could that other site manage to do it? Is it possible to add individual pages to the sitemap? I looked at the other sites sitemap and the pages do not appear there. Seems only posts are showing.</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"danniee\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"https://wordpress.org/support/topic/domdocumentloadxml-errors/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"DOMDocument::loadXML Errors\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"https://wordpress.org/support/topic/domdocumentloadxml-errors/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 25 Nov 2018 18:52:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:586:\"
						
						<p>Replies: 0</p>
						<p>Hi there,</p>
<p>I&#8217;m getting the following error messages:</p>
<p>[25-Nov-2018 09:09:20 UTC] PHP Warning:  DOMDocument::loadXML(): Extra content at the end of the document in Entity, line: 322 in /wp-content/plugins/google-sitemap-generator/sitemap-core.php on line 1653<br />
[25-Nov-2018 09:09:20 UTC] PHP Warning:  DOMDocument::loadXML(): xmlParseComment: invalid xmlChar value 2 in Entity, line: 322 in /wp-content/plugins/google-sitemap-generator/sitemap-core.php on line 1653</p>
<p>Any idea what&#8217;s causing it?</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Venutius\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:67:\"
					
					
					
					
					

					
					

					
					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"https://wordpress.org/support/topic/schema-12/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"Schema\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"https://wordpress.org/support/topic/schema-12/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 24 Nov 2018 15:47:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:205:\"
						
						<p>Replies: 0</p>
						<p>Hi,  I had added WP SEO Structured Data Schema to my site.  Does Google Sitemap add schema to the sitemap.xml?  Or is there a way for it to add it?</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"krazykatz911\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:67:\"https://wordpress.org/support/plugin/google-sitemap-generator/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:7:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Sat, 26 Jan 2019 17:26:50 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:6:\"x-olaf\";s:3:\"⛄\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 1\";}}s:5:\"build\";s:14:\"20180523073303\";}","no");
INSERT INTO `yucqn_options` VALUES("15697","_transient_timeout_feed_mod_d21d2a68bac70d38fb7f9a7bd3d1725e","1549128410","no");
INSERT INTO `yucqn_options` VALUES("15698","_transient_feed_mod_d21d2a68bac70d38fb7f9a7bd3d1725e","1548523610","no");
INSERT INTO `yucqn_options` VALUES("15703","_site_transient_timeout_browser_e0b7751b8040fb7c8de50ddf95d10645","1549136161","no");
INSERT INTO `yucqn_options` VALUES("15704","_site_transient_browser_e0b7751b8040fb7c8de50ddf95d10645","a:10:{s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"64.0\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:24:\"https://www.firefox.com/\";s:7:\"img_src\";s:44:\"http://s.w.org/images/browsers/firefox.png?1\";s:11:\"img_src_ssl\";s:45:\"https://s.w.org/images/browsers/firefox.png?1\";s:15:\"current_version\";s:2:\"56\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `yucqn_options` VALUES("15791","_site_transient_timeout_browser_ca51cc7f8d4430191b47700aec5e6d56","1549270744","no");
INSERT INTO `yucqn_options` VALUES("15792","_site_transient_browser_ca51cc7f8d4430191b47700aec5e6d56","a:10:{s:4:\"name\";s:8:\"Chromium\";s:7:\"version\";s:12:\"71.0.3578.98\";s:8:\"platform\";s:5:\"Linux\";s:10:\"update_url\";s:0:\"\";s:7:\"img_src\";s:0:\"\";s:11:\"img_src_ssl\";s:0:\"\";s:15:\"current_version\";s:0:\"\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `yucqn_options` VALUES("15793","_transient_timeout_feed_3ca2a73478cc83bbe37e39039b345a78","1548709150","no");
INSERT INTO `yucqn_options` VALUES("15794","_transient_feed_3ca2a73478cc83bbe37e39039b345a78","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"WPFR\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"https://wpfr.net\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Site officiel de la communauté\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 28 Jan 2019 09:37:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"fr-FR\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:39:\"
		
		
		
		
		
				
		

		
		
		
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"Think WP, le documentaire vidéo sur WordPress enfin disponible !\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"http://feedproxy.google.com/~r/WordpressFrancophone/~3/BFWuQgyALjg/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"https://wpfr.net/thinkwp-documentaire-video-wordpress/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Nov 2018 13:03:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:9:\"WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:21:\"WordPress Francophone\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"https://wpfr.net/?p=2220300\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1538:\"Découvrez WordPress en 30 minutes au travers de ce documentaire inédit d&#8217;interviews de la communauté française. Sur une idée originale de Déborah Donnier, entrepreneurs, chefs d&#8217;entreprises, freelances, agences web, développeurs, intégrateurs&#8230; de toute la France se succèdent pour nous parler de notre CMS favori WordPress. Financé uniquement par des dons et sponsors, le projet Think<div class=\"btn btn-default read-more text-uppercase\">Lire la suite <span class=\"meta-nav\"><i class=\"fa fa-caret-right\"></i></span></div><div class=\"feedflare\">
<a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=BFWuQgyALjg:KhIgVVs-X9Q:yIl2AUoC8zA\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=BFWuQgyALjg:KhIgVVs-X9Q:V_sGLiPBpWU\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=BFWuQgyALjg:KhIgVVs-X9Q:V_sGLiPBpWU\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=BFWuQgyALjg:KhIgVVs-X9Q:qj6IDK7rITs\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=BFWuQgyALjg:KhIgVVs-X9Q:gIN9vFwOqvQ\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=BFWuQgyALjg:KhIgVVs-X9Q:gIN9vFwOqvQ\" border=\"0\"></img></a>
</div><img src=\"http://feeds.feedburner.com/~r/WordpressFrancophone/~4/BFWuQgyALjg\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Benjamin Denis\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wpfr.net/thinkwp-documentaire-video-wordpress/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://wpfr.net/thinkwp-documentaire-video-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:30:\"
		
		
		
		
				
		

		
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"WP BootCamp 2018 : retours sur la deuxième édition\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"http://feedproxy.google.com/~r/WordpressFrancophone/~3/73jXJKLX5xI/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 23 Oct 2018 06:05:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:16:\"Association WPFR\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:9:\"WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"https://wpfr.net/?p=2215483\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1487:\"Soutenu par l&#8217;association WordPress Francophone, retours sur la seconde édition du WP BootCamp. Qu&#8217;est ce que le WP BootCamp ? Le WP BootCamp est un événement réunissant des passionnés de WordPress et du web en général sur un week-end de 3 jours. L&#8217;édition 2018, portée par Rémi Corson, Aurélien Denis et Benjamin Denis, se déroula<div class=\"btn btn-default read-more text-uppercase\">Lire la suite <span class=\"meta-nav\"><i class=\"fa fa-caret-right\"></i></span></div><div class=\"feedflare\">
<a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=73jXJKLX5xI:kXAjLDU4P-c:yIl2AUoC8zA\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=73jXJKLX5xI:kXAjLDU4P-c:V_sGLiPBpWU\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=73jXJKLX5xI:kXAjLDU4P-c:V_sGLiPBpWU\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=73jXJKLX5xI:kXAjLDU4P-c:qj6IDK7rITs\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=73jXJKLX5xI:kXAjLDU4P-c:gIN9vFwOqvQ\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=73jXJKLX5xI:kXAjLDU4P-c:gIN9vFwOqvQ\" border=\"0\"></img></a>
</div><img src=\"http://feeds.feedburner.com/~r/WordpressFrancophone/~4/73jXJKLX5xI\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Benjamin Denis\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"https://wpfr.net/wp-bootcamp-2018-retours-sur-la-deuxieme-edition/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		
		
		

		
		
		
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"Tout savoir sur l’arrivée de Gutenberg en quelques points essentiels\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"http://feedproxy.google.com/~r/WordpressFrancophone/~3/i6NQjnc9uiQ/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"https://wpfr.net/wordpress-gutenberg/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 23 Apr 2018 09:00:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:4:{i:0;a:5:{s:4:\"data\";s:4:\"Blog\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:9:\"WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:15:\"éditeur visuel\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:3;a:5:{s:4:\"data\";s:9:\"Gutenberg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"https://wpfr.net/?p=2117903\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1474:\"Gutenberg arrive à grand pas, alors voici un résumé de tout ce qu&#8217;il faut savoir sur le nouvel éditeur visuel de WordPress au travers de questions / réponses ! Difficile de marcher tranquillement dans le quartier WordPress sans entendre parler de ce fameux Gutenberg ! C&#8217;est un nouvel éditeur ? C&#8217;est un nouveau page builder<div class=\"btn btn-default read-more text-uppercase\">Lire la suite <span class=\"meta-nav\"><i class=\"fa fa-caret-right\"></i></span></div><div class=\"feedflare\">
<a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=i6NQjnc9uiQ:TQYicJ8IHdE:yIl2AUoC8zA\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=i6NQjnc9uiQ:TQYicJ8IHdE:V_sGLiPBpWU\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=i6NQjnc9uiQ:TQYicJ8IHdE:V_sGLiPBpWU\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=i6NQjnc9uiQ:TQYicJ8IHdE:qj6IDK7rITs\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=i6NQjnc9uiQ:TQYicJ8IHdE:gIN9vFwOqvQ\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=i6NQjnc9uiQ:TQYicJ8IHdE:gIN9vFwOqvQ\" border=\"0\"></img></a>
</div><img src=\"http://feeds.feedburner.com/~r/WordpressFrancophone/~4/i6NQjnc9uiQ\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"maximebj\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"https://wpfr.net/wordpress-gutenberg/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"13\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"https://wpfr.net/wordpress-gutenberg/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:39:\"
		
		
		
		
		
				
		

		
		
		
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"Résultats des élections du bureau 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"http://feedproxy.google.com/~r/WordpressFrancophone/~3/qvTDw6NqY5Q/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wpfr.net/resultats-elections-bureau-2018/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Mar 2018 08:00:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:16:\"Association WPFR\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:4:\"Blog\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"https://wpfr.net/?p=2107099\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1521:\"Suite à la votation électronique qui s&#8217;est déroulée du 24 février au 3 mars 2018, nous vous communiquons les résultats pour l&#8217;élection du bureau 2018. Vous avez été 40% des adhérents à participer au vote, soit 85 suffrages exprimés. C&#8217;est pratiquement autant de votants que l&#8217;an passé avec un nombre d&#8217;adhérents moins élevé, l&#8217;abstention reste<div class=\"btn btn-default read-more text-uppercase\">Lire la suite <span class=\"meta-nav\"><i class=\"fa fa-caret-right\"></i></span></div><div class=\"feedflare\">
<a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=qvTDw6NqY5Q:LD0dZBWRJa4:yIl2AUoC8zA\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=qvTDw6NqY5Q:LD0dZBWRJa4:V_sGLiPBpWU\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=qvTDw6NqY5Q:LD0dZBWRJa4:V_sGLiPBpWU\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=qvTDw6NqY5Q:LD0dZBWRJa4:qj6IDK7rITs\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=qvTDw6NqY5Q:LD0dZBWRJa4:gIN9vFwOqvQ\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=qvTDw6NqY5Q:LD0dZBWRJa4:gIN9vFwOqvQ\" border=\"0\"></img></a>
</div><img src=\"http://feeds.feedburner.com/~r/WordpressFrancophone/~4/qvTDw6NqY5Q\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Aurélien Denis\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://wpfr.net/resultats-elections-bureau-2018/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"13\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"https://wpfr.net/resultats-elections-bureau-2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:39:\"
		
		
		
		
		
				
		

		
		
		
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"Liste des candidats au bureau 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"http://feedproxy.google.com/~r/WordpressFrancophone/~3/mYCnwrPtTAY/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://wpfr.net/liste-candidats-bureau-2018/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 16 Feb 2018 11:45:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:16:\"Association WPFR\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:4:\"Blog\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"https://wpfr.net/?p=2092699\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1508:\"Les élections pour le renouvellement du bureau auront lieu du 24 février au 3 mars 2018 par voie électronique. Nous vous communiquons dès à présent la liste des candidats validée par l&#8217;actuel bureau, classés par ordre alphabétique. Les candidats Willy Bahuaud Présentation Je suis développeur full-stack. Après quelques années passées en agence à Nantes, j’ai<div class=\"btn btn-default read-more text-uppercase\">Lire la suite <span class=\"meta-nav\"><i class=\"fa fa-caret-right\"></i></span></div><div class=\"feedflare\">
<a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=mYCnwrPtTAY:g4F7i0PDxEQ:yIl2AUoC8zA\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=mYCnwrPtTAY:g4F7i0PDxEQ:V_sGLiPBpWU\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=mYCnwrPtTAY:g4F7i0PDxEQ:V_sGLiPBpWU\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=mYCnwrPtTAY:g4F7i0PDxEQ:qj6IDK7rITs\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=mYCnwrPtTAY:g4F7i0PDxEQ:gIN9vFwOqvQ\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=mYCnwrPtTAY:g4F7i0PDxEQ:gIN9vFwOqvQ\" border=\"0\"></img></a>
</div><img src=\"http://feeds.feedburner.com/~r/WordpressFrancophone/~4/mYCnwrPtTAY\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Aurélien Denis\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"https://wpfr.net/liste-candidats-bureau-2018/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"https://wpfr.net/liste-candidats-bureau-2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:39:\"
		
		
		
		
		
				
		

		
		
		
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"WPFR sponsor du WP Tech Lyon !\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"http://feedproxy.google.com/~r/WordpressFrancophone/~3/kVgok7MJrJM/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wpfr.net/wpfr-sponsor-wptech-lyon/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 12 Feb 2018 07:00:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:4:\"Blog\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:11:\"Evènements\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"https://wpfr.net/?p=2082223\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1507:\"L’association WPFR est fière de vous annoncer qu’elle sponsorise WP Tech 2018 qui aura lieu le 28 avril à Lyon. Le WP Tech est une journée de conférences et d’ateliers exclusivement consacrée aux aspects techniques de WordPress. Vous y découvrirez des outils pour améliorer vos méthodes de travail, apprendrez de nouvelles méthodes de développements d’extensions,<div class=\"btn btn-default read-more text-uppercase\">Lire la suite <span class=\"meta-nav\"><i class=\"fa fa-caret-right\"></i></span></div><div class=\"feedflare\">
<a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=kVgok7MJrJM:wfMH9NuDwps:yIl2AUoC8zA\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=kVgok7MJrJM:wfMH9NuDwps:V_sGLiPBpWU\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=kVgok7MJrJM:wfMH9NuDwps:V_sGLiPBpWU\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=kVgok7MJrJM:wfMH9NuDwps:qj6IDK7rITs\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=kVgok7MJrJM:wfMH9NuDwps:gIN9vFwOqvQ\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=kVgok7MJrJM:wfMH9NuDwps:gIN9vFwOqvQ\" border=\"0\"></img></a>
</div><img src=\"http://feeds.feedburner.com/~r/WordpressFrancophone/~4/kVgok7MJrJM\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Aurélien Denis\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"https://wpfr.net/wpfr-sponsor-wptech-lyon/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"https://wpfr.net/wpfr-sponsor-wptech-lyon/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		
		
		

		
		
		
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"Loi anti-fraude et l’e-commerce : les informations officielles\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"http://feedproxy.google.com/~r/WordpressFrancophone/~3/KBb85wMEo0g/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"https://wpfr.net/loi-anti-fraude-et-le-commerce-les-informations-officielles/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 31 Jan 2018 14:51:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:4:{i:0;a:5:{s:4:\"data\";s:10:\"Extensions\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:21:\"WordPress Francophone\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:15:\"Loi anti-fraude\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:3;a:5:{s:4:\"data\";s:11:\"WooCommerce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"https://wpfr.net/?p=2072415\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1503:\"Cette nouvelle loi a fait couler pas mal d&#8217;encre ces derniers temps et afin d&#8217;apporter des réponses concrètes et officielles, nous nous sommes penchés sur le sujet en profondeur. Voici donc ce qu&#8217;il en ressort officiellement : Les plateformes e-commerce open source sont bien concernées par la loi anti-fraude Que ce soit WooCommerce, Magento, Prestashop,<div class=\"btn btn-default read-more text-uppercase\">Lire la suite <span class=\"meta-nav\"><i class=\"fa fa-caret-right\"></i></span></div><div class=\"feedflare\">
<a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=KBb85wMEo0g:NZq1YCx1Y5E:yIl2AUoC8zA\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=KBb85wMEo0g:NZq1YCx1Y5E:V_sGLiPBpWU\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=KBb85wMEo0g:NZq1YCx1Y5E:V_sGLiPBpWU\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=KBb85wMEo0g:NZq1YCx1Y5E:qj6IDK7rITs\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=KBb85wMEo0g:NZq1YCx1Y5E:gIN9vFwOqvQ\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=KBb85wMEo0g:NZq1YCx1Y5E:gIN9vFwOqvQ\" border=\"0\"></img></a>
</div><img src=\"http://feeds.feedburner.com/~r/WordpressFrancophone/~4/KBb85wMEo0g\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"maximebj\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"https://wpfr.net/loi-anti-fraude-et-le-commerce-les-informations-officielles/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"39\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"https://wpfr.net/loi-anti-fraude-et-le-commerce-les-informations-officielles/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:39:\"
		
		
		
		
		
				
		

		
		
		
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"L’élection du bureau WPFR 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"http://feedproxy.google.com/~r/WordpressFrancophone/~3/BC2q8usn6uA/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://wpfr.net/election-bureau-wpfr-2018/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 15 Jan 2018 11:30:54 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:16:\"Association WPFR\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:4:\"Blog\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"https://wpfr.net/?p=2041252\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1530:\"Comme annoncé lors de l’assemblée générale du 12 décembre 2017, l&#8217;heure des élections a sonné. Le bureau actuellement en place voit son mandat terminé, de nouvelles élections doivent donc avoir lieu afin de le renouveler  Ces élections sont prévues pour le 26 février 2018 et nous invitons les membres l&#8217;association désireux d&#8217;occuper des responsabilités nationales à<div class=\"btn btn-default read-more text-uppercase\">Lire la suite <span class=\"meta-nav\"><i class=\"fa fa-caret-right\"></i></span></div><div class=\"feedflare\">
<a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=BC2q8usn6uA:rovaWM-7xzU:yIl2AUoC8zA\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=BC2q8usn6uA:rovaWM-7xzU:V_sGLiPBpWU\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=BC2q8usn6uA:rovaWM-7xzU:V_sGLiPBpWU\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=BC2q8usn6uA:rovaWM-7xzU:qj6IDK7rITs\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=BC2q8usn6uA:rovaWM-7xzU:gIN9vFwOqvQ\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=BC2q8usn6uA:rovaWM-7xzU:gIN9vFwOqvQ\" border=\"0\"></img></a>
</div><img src=\"http://feeds.feedburner.com/~r/WordpressFrancophone/~4/BC2q8usn6uA\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Aurélien Denis\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"https://wpfr.net/election-bureau-wpfr-2018/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"https://wpfr.net/election-bureau-wpfr-2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:30:\"
		
		
		
		
				
		

		
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"PHP Tour Montpellier 2018 : WPFR est partenaire !\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"http://feedproxy.google.com/~r/WordpressFrancophone/~3/i_ty7z2Kg6A/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 11 Jan 2018 10:12:56 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:16:\"Association WPFR\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:4:\"Blog\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"https://wpfr.net/?p=2035309\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1489:\"WPFR est fière d&#8217;être partenaire du PHP Tour Montpellier 2018 qui se tiendra les 17 et 18 mai. Cet évènement porté par l&#8217;AFUP (Association Française des Utilisateurs de PHP) rassemble une sélection d&#8217;orateurs reconnus du monde PHP. Et comme vous le savez, WordPress repose en grande partie sur le langage PHP. Si vous êtes développeurs,<div class=\"btn btn-default read-more text-uppercase\">Lire la suite <span class=\"meta-nav\"><i class=\"fa fa-caret-right\"></i></span></div><div class=\"feedflare\">
<a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=i_ty7z2Kg6A:5FE8vgrgZLs:yIl2AUoC8zA\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=i_ty7z2Kg6A:5FE8vgrgZLs:V_sGLiPBpWU\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=i_ty7z2Kg6A:5FE8vgrgZLs:V_sGLiPBpWU\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=i_ty7z2Kg6A:5FE8vgrgZLs:qj6IDK7rITs\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=i_ty7z2Kg6A:5FE8vgrgZLs:gIN9vFwOqvQ\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=i_ty7z2Kg6A:5FE8vgrgZLs:gIN9vFwOqvQ\" border=\"0\"></img></a>
</div><img src=\"http://feeds.feedburner.com/~r/WordpressFrancophone/~4/i_ty7z2Kg6A\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Aurélien Denis\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wpfr.net/php-tour-montpellier-2018-wpfr-partenaire/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:39:\"
		
		
		
		
		
				
		

		
		
		
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"Le point sur les certifications WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"http://feedproxy.google.com/~r/WordpressFrancophone/~3/SbTm014V92I/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wpfr.net/point-certifications-wordpress/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 11 Dec 2017 17:15:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:16:\"Association WPFR\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:4:\"Blog\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"https://wpfr.net/?p=2001761\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1552:\"Le sujet des certifications WordPress est de retour en cette fin d&#8217;année pour faire un point de situation. L&#8217;association s&#8217;est penchée dessus et voici les conclusions actuelles. Pour rappel, j&#8217;avais émis l&#8217;idée en 2016 de faire certifier les formations WordPress. D&#8217;autres idées ont ensuite suivi, dont notamment celle d&#8217;inscrire WordPress au Registre National des Certifications<div class=\"btn btn-default read-more text-uppercase\">Lire la suite <span class=\"meta-nav\"><i class=\"fa fa-caret-right\"></i></span></div><div class=\"feedflare\">
<a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=SbTm014V92I:Cd3SuKi-siI:yIl2AUoC8zA\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=yIl2AUoC8zA\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=SbTm014V92I:Cd3SuKi-siI:V_sGLiPBpWU\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=SbTm014V92I:Cd3SuKi-siI:V_sGLiPBpWU\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=SbTm014V92I:Cd3SuKi-siI:qj6IDK7rITs\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?d=qj6IDK7rITs\" border=\"0\"></img></a> <a href=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?a=SbTm014V92I:Cd3SuKi-siI:gIN9vFwOqvQ\"><img src=\"http://feeds.feedburner.com/~ff/WordpressFrancophone?i=SbTm014V92I:Cd3SuKi-siI:gIN9vFwOqvQ\" border=\"0\"></img></a>
</div><img src=\"http://feeds.feedburner.com/~r/WordpressFrancophone/~4/SbTm014V92I\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"maximebj\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wpfr.net/point-certifications-wordpress/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"11\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"https://wpfr.net/point-certifications-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"hourly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:2:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";s:4:\"href\";s:48:\"http://feeds.feedburner.com/WordpressFrancophone\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:2:{s:3:\"rel\";s:3:\"hub\";s:4:\"href\";s:32:\"http://pubsubhubbub.appspot.com/\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:4:{s:4:\"info\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:3:\"uri\";s:20:\"wordpressfrancophone\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:14:\"emailServiceId\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordpressFrancophone\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:18:\"feedburnerHostname\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://feedburner.google.com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"feedFlare\";a:9:{i:0;a:5:{s:4:\"data\";s:24:\"Subscribe with NewsGator\";s:7:\"attribs\";a:1:{s:0:\"\";a:2:{s:4:\"href\";s:112:\"http://www.newsgator.com/ngs/subscriber/subext.aspx?url=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone\";s:3:\"src\";s:42:\"http://www.newsgator.com/images/ngsub1.gif\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:24:\"Subscribe with Bloglines\";s:7:\"attribs\";a:1:{s:0:\"\";a:2:{s:4:\"href\";s:77:\"http://www.bloglines.com/sub/http://feeds.feedburner.com/WordpressFrancophone\";s:3:\"src\";s:48:\"http://www.bloglines.com/images/sub_modern11.gif\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:23:\"Subscribe with Netvibes\";s:7:\"attribs\";a:1:{s:0:\"\";a:2:{s:4:\"href\";s:98:\"http://www.netvibes.com/subscribe.php?url=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone\";s:3:\"src\";s:39:\"//www.netvibes.com/img/add2netvibes.gif\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:3;a:5:{s:4:\"data\";s:21:\"Subscribe with Google\";s:7:\"attribs\";a:1:{s:0:\"\";a:2:{s:4:\"href\";s:93:\"http://fusion.google.com/add?feedurl=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone\";s:3:\"src\";s:51:\"http://buttons.googlesyndication.com/fusion/add.gif\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:4;a:5:{s:4:\"data\";s:25:\"Subscribe with Pageflakes\";s:7:\"attribs\";a:1:{s:0:\"\";a:2:{s:4:\"href\";s:101:\"http://www.pageflakes.com/subscribe.aspx?url=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone\";s:3:\"src\";s:87:\"http://www.pageflakes.com/ImageFile.ashx?instanceId=Static_4&fileName=ATP_blu_91x17.gif\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:5;a:5:{s:4:\"data\";s:21:\"Subscribe with Plusmo\";s:7:\"attribs\";a:1:{s:0:\"\";a:2:{s:4:\"href\";s:86:\"http://www.plusmo.com/add?url=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone\";s:3:\"src\";s:43:\"http://plusmo.com/res/graphics/fbplusmo.gif\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:6;a:5:{s:4:\"data\";s:23:\"Subscribe with Live.com\";s:7:\"attribs\";a:1:{s:0:\"\";a:2:{s:4:\"href\";s:81:\"http://www.live.com/?add=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone\";s:3:\"src\";s:141:\"http://tkfiles.storage.msn.com/x1piYkpqHC_35nIp1gLE68-wvzLZO8iXl_JMledmJQXP-XTBOLfmQv4zhj4MhcWEJh_GtoBIiAl1Mjh-ndp9k47If7hTaFno0mxW9_i3p_5qQw\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:7;a:5:{s:4:\"data\";s:25:\"Subscribe with Mon Yahoo!\";s:7:\"attribs\";a:1:{s:0:\"\";a:2:{s:4:\"href\";s:99:\"https://add.my.yahoo.com/content?lg=fr&url=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone\";s:3:\"src\";s:60:\"http://us.i1.yimg.com/us.yimg.com/i/us/my/bn/intatm_fr_1.gif\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:8;a:5:{s:4:\"data\";s:25:\"Subscribe with Excite MIX\";s:7:\"attribs\";a:1:{s:0:\"\";a:2:{s:4:\"href\";s:89:\"http://mix.excite.eu/add?feedurl=http%3A%2F%2Ffeeds.feedburner.com%2FWordpressFrancophone\";s:3:\"src\";s:42:\"http://image.excite.co.uk/mix/addtomix.gif\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:52:\"http://backend.userland.com/creativeCommonsRssModule\";a:1:{s:7:\"license\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"http://creativecommons.org/licenses/by-nc-sa/3.0/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:11:{s:12:\"content-type\";s:23:\"text/xml; charset=UTF-8\";s:4:\"etag\";s:27:\"n8JP2F4o4Wp2vbt4+emNkljR6A8\";s:13:\"last-modified\";s:29:\"Mon, 28 Jan 2019 08:43:38 GMT\";s:16:\"content-encoding\";s:4:\"gzip\";s:4:\"date\";s:29:\"Mon, 28 Jan 2019 08:59:10 GMT\";s:7:\"expires\";s:29:\"Mon, 28 Jan 2019 08:59:10 GMT\";s:13:\"cache-control\";s:18:\"private, max-age=0\";s:22:\"x-content-type-options\";s:7:\"nosniff\";s:16:\"x-xss-protection\";s:13:\"1; mode=block\";s:6:\"server\";s:3:\"GSE\";s:7:\"alt-svc\";s:37:\"quic=\":443\"; ma=2592000; v=\"44,43,39\"\";}}s:5:\"build\";s:14:\"20190128080509\";}","no");
INSERT INTO `yucqn_options` VALUES("15795","_transient_timeout_feed_mod_3ca2a73478cc83bbe37e39039b345a78","1548709150","no");
INSERT INTO `yucqn_options` VALUES("15796","_transient_feed_mod_3ca2a73478cc83bbe37e39039b345a78","1548665950","no");
INSERT INTO `yucqn_options` VALUES("15797","_transient_timeout_feed_76f8d9281c01f21e505004d0986f50c6","1548709150","no");
INSERT INTO `yucqn_options` VALUES("15798","_transient_feed_76f8d9281c01f21e505004d0986f50c6","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:5:\"
		
	\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:79:\"
		
		
		
		
		
		
					
						
						
						
						
						
						
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"Planète WordPress Francophone\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"https://wpfr.net/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"Toute l’actualité de WordPress en français !\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"fr-FR\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:8:{i:0;a:6:{s:4:\"data\";s:84:\"
		        
		        
		        
		        
		        
		        
		        
		    \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"CoSchedule : le plugin pour centraliser votre stratégie de contenu\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"http://feedproxy.google.com/~r/wpfr/~3/TsolTQn4Zq8/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"https://wpmarmite.com/coschedule/?utm_source=rss&#038;utm_medium=rss&%23038;utm_campaign=coschedule\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 22 Jan 2019 07:00:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:365:\"
		        
Diffuser du contenu pour faire connaître votre entreprise, votre site auprès des internautes, c’est bien. Proposer des articles qualitatifs, engageants, c’est mieux. Produire du contenu de qualité, qui passionne vos...
L’article CoSchedule : le plugin pour centraliser votre stratégie de contenu est apparu en premier sur WP Marmite.		        \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"WP Marmite\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:728:\"<p><img width=\"1500\" height=\"750\" src=\"https://wpmarmite.com/wp-content/uploads/2019/01/coschedule.jpg\" class=\"attachment-full size-full wp-post-image\" alt=\"\" /></p>
<p>Diffuser du contenu pour faire connaître votre entreprise, votre site auprès des internautes, c’est bien. Proposer des articles qualitatifs, engageants, c’est mieux. Produire du contenu de qualité, qui passionne vos...</p>
<p>L’article <a rel=\"nofollow\" href=\"https://wpmarmite.com/coschedule/\">CoSchedule : le plugin pour centraliser votre stratégie de contenu</a> est apparu en premier sur <a rel=\"nofollow\" href=\"https://wpmarmite.com\">WP Marmite</a>.</p><img src=\"http://feeds.feedburner.com/~r/wpfr/~4/TsolTQn4Zq8\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"https://wpmarmite.com/coschedule/?utm_source=rss&#038;utm_medium=rss&%23038;utm_campaign=coschedule\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:84:\"
		        
		        
		        
		        
		        
		        
		        
		    \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Clean Login\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"http://feedproxy.google.com/~r/wpfr/~3/MTKpaLCGWAY/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://www.echodesplugins.li-an.fr/plugins/clean-login/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 21 Jan 2019 14:53:49 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"
		        Une alternative à Theme My Login		        \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:124:\"Une alternative à Theme My Login<img src=\"http://feeds.feedburner.com/~r/wpfr/~4/MTKpaLCGWAY\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://www.echodesplugins.li-an.fr/plugins/clean-login/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:84:\"
		        
		        
		        
		        
		        
		        
		        
		    \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"Ajouter un e-mail dans une liste MailChimp via API\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"http://feedproxy.google.com/~r/wpfr/~3/_bOxk6iL4tg/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://mosaika.fr/api-mailchimp-inscrire-utilisateur-wordpress/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 20 Jan 2019 19:24:25 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:501:\"
		        Dans ce tutoriel, nous allons analyser comment ajouter un e-mail dans une liste d&#8217;abonnés en profitant des fonctions HTTP de WordPress et en communiquant avec MailChimp via son API. De nombreuses extensions existent afin de relier un site WordPress à l&#8217;outil de gestion de newsletter MailChimp. Il est relativement facile de relier des événements WordPress [&#8230;]
Cet article Ajouter un e-mail dans une liste MailChimp via API est apparu en premier sur Mosaika.		        \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:727:\"<p>Dans ce tutoriel, nous allons analyser comment ajouter un e-mail dans une liste d&#8217;abonnés en profitant des fonctions HTTP de WordPress et en communiquant avec MailChimp via son API. De nombreuses extensions existent afin de relier un site WordPress à l&#8217;outil de gestion de newsletter MailChimp. Il est relativement facile de relier des événements WordPress [&#8230;]</p>
<p>Cet article <a rel=\"nofollow\" href=\"https://mosaika.fr/api-mailchimp-inscrire-utilisateur-wordpress/\">Ajouter un e-mail dans une liste MailChimp via API</a> est apparu en premier sur <a rel=\"nofollow\" href=\"https://mosaika.fr\">Mosaika</a>.</p><img src=\"http://feeds.feedburner.com/~r/wpfr/~4/_bOxk6iL4tg\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://mosaika.fr/api-mailchimp-inscrire-utilisateur-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:84:\"
		        
		        
		        
		        
		        
		        
		        
		    \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"La barre d’outils du bloc Paragraphe\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"http://feedproxy.google.com/~r/wpfr/~3/HVM1uzqSBEw/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"https://dfarnier.fr/outils-bloc-paragraphe/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 19 Jan 2019 14:50:33 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:385:\"
		        La barre d\'outils associée au type de bloc Paragraphe offre les options d\'édition suivantes : modifier le type de bloc, mettre en gras, souligner ou rayer tout ou partie du texte, aligner le texte à l\'intérieur du bloc Paragraphe ou attacher un lien internet.
Cet article La barre d&rsquo;outils du bloc Paragraphe est apparu en premier sur Débuter WordPress.		        \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Daniel Farnier\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:591:\"<p>La barre d\'outils associée au type de bloc Paragraphe offre les options d\'édition suivantes : modifier le type de bloc, mettre en gras, souligner ou rayer tout ou partie du texte, aligner le texte à l\'intérieur du bloc Paragraphe ou attacher un lien internet.</p>
<p>Cet article <a rel=\"nofollow\" href=\"https://dfarnier.fr/outils-bloc-paragraphe/\">La barre d&rsquo;outils du bloc Paragraphe</a> est apparu en premier sur <a rel=\"nofollow\" href=\"https://dfarnier.fr\">Débuter WordPress</a>.</p><img src=\"http://feeds.feedburner.com/~r/wpfr/~4/HVM1uzqSBEw\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"https://dfarnier.fr/outils-bloc-paragraphe/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:84:\"
		        
		        
		        
		        
		        
		        
		        
		    \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"Venir au WordCamp Bordeaux\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"http://feedproxy.google.com/~r/wpfr/~3/OwoMw40mjGI/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://2019.bordeaux.wordcamp.org/2019/01/19/venir-au-wordcamp-bordeaux/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 19 Jan 2019 14:41:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:408:\"
		        Pour commencer l’année 2019, le prochain WordCamp a lieu au Centre des Congrès Cité Mondiale de la très belle ville de Bordeaux. Ce lieu moderne et original est l’endroit idéal pour s’inspirer et s&#8217;immerger dans la communauté WordPress. Situé en plein cœur de la ville et aisément accessible, le Centre des Congrès Cité Mondiale offre plusieurs espaces [&#8230;]		        \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"WordCamp Bordeaux\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4044:\"<p>Pour commencer l’année 2019, le prochain <strong>WordCamp</strong> a lieu au <strong>Centre des Congrès Cité Mondiale</strong> de la très belle ville de <strong>Bordeaux</strong>. Ce lieu moderne et original est l’endroit idéal pour s’inspirer et s&rsquo;immerger dans la communauté WordPress.</p>
<p><img class=\"wp-image-1396 size-full aligncenter\" src=\"http://2017.bordeaux.wordcamp.org/files/2017/01/30029152321_bab89a34ef_z.jpg\" width=\"640\" height=\"426\" /><img class=\"aligncenter wp-image-1397 size-full\" src=\"http://2017.bordeaux.wordcamp.org/files/2017/01/30112901625_ac4b35508b_z.jpg\" width=\"640\" height=\"424\" /><img class=\"wp-image-1395 size-medium aligncenter\" src=\"http://2017.bordeaux.wordcamp.org/files/2017/01/29998705402_6a45ebd0f6_z.jpg\" width=\"640\" height=\"auto\" /></p>
<p>Situé en plein cœur de la ville et aisément accessible, le Centre des Congrès Cité Mondiale offre plusieurs espaces afin de profiter pleinement d’une journée riche en conférences, ateliers et échanges.</p>
<h2>ADRESSE</h2>
<p><strong>18 Parvis des Chartrons / 20 quais des Chartrons à Bordeaux</strong></p>
<div class=\"googlemaps\"></div>
<h2>POUR VOUS Y RENDRE…</h2>
<p>La Gare Saint-Jean se situe à une distance de marche d&rsquo;environ 40 minutes du centre-ville, pour les bons marcheurs. Pour les amateurs de vélo, <a href=\"https://www.infotbm.com/le-reseau-tbc/tbc-decouverte/vcub\" target=\"_blank\" rel=\"noopener\">sachez que deux stations V<sup>3</sup> sont situées en face de la Gare Saint Jean</a>, et que de nombreuses stations maillent la ville. Et sinon…</p>
<h3>TRAIN &amp; TRAM</h3>
<p>Le réseau de Transports Bordeaux Métropole dessert très bien la Gare Saint-Jean : <strong>prenez le tram C, l&rsquo;arrêt est situé juste devant la gare</strong>, le tram y passe environ toutes les cinq minutes. Vous y trouverez également de nombreux arrêts de bus.</p>
<p>&gt;&gt; <a href=\"https://www.infotbm.com\" target=\"_blank\" rel=\"noopener\">Plus d’infos sur le site TBM</a></p>
<h3>PARKINGS</h3>
<p>Relativement chers et souvent pleins le week-end, nous vous déconseillons les parkings du centre-ville. Par contre, des <a href=\"https://www.infotbm.com/les-parc-relais-tout-public\"><strong>parcs-relais</strong></a> situés non loin du centre vous permettront de vous garer sereinement et de prendre immédiatement le tram qui vous amènera au centre de Bordeaux. C&rsquo;est très facile et peu coûteux…</p>
<p>&gt;&gt; <a href=\"https://www.infotbm.com/les-parc-relais-tout-public\" target=\"_blank\" rel=\"noopener\">Plus d&rsquo;infos sur le site TBM</a></p>
<h3>AVION</h3>
<p>Bordeaux est une mégapole qui accueille un bel aéroport à Mérignac, lui aussi desservi par le réseau de transports en commun.</p>
<p>&gt;&gt; Retrouvez <a href=\"http://www.bordeaux.aeroport.fr/fr/info/bus-laeroport-bordeaux\" target=\"_blank\" rel=\"noopener\"> les informations pratiques</a> pour vous rendre au centre-ville depuis l&rsquo;aéroport.</p>
<h2>VOUS LOGER À BORDEAUX</h2>
<p>Plusieurs possibilités pour séjourner à Bordeaux : hôtels, <a href=\"https://www.airbnb.fr/\" target=\"_blank\" rel=\"noopener\">Airbnb</a>, locations… <strong>L’Office du Tourisme de Bordeaux propose <a href=\"http://www.bordeaux-tourisme.com/offre/recherche/hotels-et-residences-hotelieres/1/~~/(page)/1\" target=\"_blank\" rel=\"noopener\">une sélection assez large d’hôtels sur son site web</a></strong>, nous vous recommandons simplement d&rsquo;éviter le quartier de la Gare, assez bruyant.</p>
<p><strong>Vous n’avez toujours pas réservé votre place pour WordCamp Bordeaux 2019 ? Qu&rsquo;attendez-vous ?</strong></p>
<p><a class=\"cta\" href=\"https://2019.bordeaux.wordcamp.org/billets\"><span class=\"dashicons-before dashicons-tickets\">BILLETTERIE </span>C&rsquo;est parti ! »</a></p>
<hr />
<p><em>Crédits Photos : © Julien Fernandez / CEB &#8211; Bordeaux &#8211; Juin 2013 &#8211; Le Centre de Congrès Cité Mondiale</em></p><img src=\"http://feeds.feedburner.com/~r/wpfr/~4/OwoMw40mjGI\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://2019.bordeaux.wordcamp.org/2019/01/19/venir-au-wordcamp-bordeaux/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:84:\"
		        
		        
		        
		        
		        
		        
		        
		    \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"WordPress 5.1 : des outils pour surveiller la santé de votre site\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"http://feedproxy.google.com/~r/wpfr/~3/IZE-_msrZAA/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://www.whodunit.fr/surveiller-la-sante-de-votre-site-wordpress/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 16 Jan 2019 09:51:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:495:\"
		        WordPress va commencer à introduire des mécanismes visant à surveiller la santé de votre site. Ces outils vont être intégrés progressivement dans le cœur du CMS. Premièrement, la version 5.1 de WordPress (prévue pour le 21 février 2019) va intégrer un ensemble de systèmes permettant de vous aider à mettre à jour la version de [&#8230;]
The post WordPress 5.1 : des outils pour surveiller la santé de votre site appeared first on Agence WordPress Whodunit.		        \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:730:\"<p>WordPress va commencer à introduire des mécanismes visant à surveiller la santé de votre site. Ces outils vont être intégrés progressivement dans le cœur du CMS. Premièrement, la version 5.1 de WordPress (prévue pour le 21 février 2019) va intégrer un ensemble de systèmes permettant de vous aider à mettre à jour la version de [&#8230;]</p>
<p>The post <a rel=\"nofollow\" href=\"https://www.whodunit.fr/surveiller-la-sante-de-votre-site-wordpress/\">WordPress 5.1 : des outils pour surveiller la santé de votre site</a> appeared first on <a rel=\"nofollow\" href=\"https://www.whodunit.fr\">Agence WordPress Whodunit</a>.</p><img src=\"http://feeds.feedburner.com/~r/wpfr/~4/IZE-_msrZAA\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://www.whodunit.fr/surveiller-la-sante-de-votre-site-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:84:\"
		        
		        
		        
		        
		        
		        
		        
		    \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"Comment créer une popup WordPress efficace ?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"http://feedproxy.google.com/~r/wpfr/~3/1Fcj40cKrQM/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:109:\"https://wpmarmite.com/popup-wordpress/?utm_source=rss&#038;utm_medium=rss&%23038;utm_campaign=popup-wordpress\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 15 Jan 2019 06:10:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:321:\"
		        
Projetez-vous donc dans cette situation. Vous êtes sur un blog génial, où vous vous régalez de la lecture d’un délicieux article plein de bonnes informations. Quand soudain… Une popup sauvage...
L’article Comment créer une popup WordPress efficace ? est apparu en premier sur WP Marmite.		        \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"WP Marmite\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:694:\"<p><img width=\"1500\" height=\"750\" src=\"https://wpmarmite.com/wp-content/uploads/2019/01/popup-wordpress.jpg\" class=\"attachment-full size-full wp-post-image\" alt=\"\" /></p>
<p>Projetez-vous donc dans cette situation. Vous êtes sur un blog génial, où vous vous régalez de la lecture d’un délicieux article plein de bonnes informations. Quand soudain… Une popup sauvage...</p>
<p>L’article <a rel=\"nofollow\" href=\"https://wpmarmite.com/popup-wordpress/\">Comment créer une popup WordPress efficace ?</a> est apparu en premier sur <a rel=\"nofollow\" href=\"https://wpmarmite.com\">WP Marmite</a>.</p><img src=\"http://feeds.feedburner.com/~r/wpfr/~4/1Fcj40cKrQM\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:109:\"https://wpmarmite.com/popup-wordpress/?utm_source=rss&#038;utm_medium=rss&%23038;utm_campaign=popup-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:84:\"
		        
		        
		        
		        
		        
		        
		        
		    \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Cache cache partie\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"http://feedproxy.google.com/~r/wpfr/~3/vqoRI6usrtw/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"https://www.echodesplugins.li-an.fr/plugins/cache-cache-partie/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 13 Jan 2019 16:05:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:100:\"
		        Un comparatif rapide de plusieurs extensions de cache efficaces et prometteuses		        \";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:170:\"Un comparatif rapide de plusieurs extensions de cache efficaces et prometteuses<img src=\"http://feeds.feedburner.com/~r/wpfr/~4/vqoRI6usrtw\" height=\"1\" width=\"1\" alt=\"\"/>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:8:\"origLink\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"https://www.echodesplugins.li-an.fr/plugins/cache-cache-partie/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:52:\"http://backend.userland.com/creativeCommonsRssModule\";a:1:{s:7:\"license\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"http://creativecommons.org/licenses/by-nc-sa/3.0/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:2:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";s:4:\"href\";s:32:\"http://feeds.feedburner.com/wpfr\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:2:{s:3:\"rel\";s:3:\"hub\";s:4:\"href\";s:32:\"http://pubsubhubbub.appspot.com/\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:42:\"http://rssnamespace.org/feedburner/ext/1.0\";a:1:{s:4:\"info\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:3:\"uri\";s:4:\"wpfr\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:11:{s:12:\"content-type\";s:23:\"text/xml; charset=UTF-8\";s:4:\"etag\";s:27:\"5VwoxjPjYtEkd9wy04ney7a4kJ8\";s:13:\"last-modified\";s:29:\"Mon, 28 Jan 2019 08:56:22 GMT\";s:16:\"content-encoding\";s:4:\"gzip\";s:4:\"date\";s:29:\"Mon, 28 Jan 2019 08:59:10 GMT\";s:7:\"expires\";s:29:\"Mon, 28 Jan 2019 08:59:10 GMT\";s:13:\"cache-control\";s:18:\"private, max-age=0\";s:22:\"x-content-type-options\";s:7:\"nosniff\";s:16:\"x-xss-protection\";s:13:\"1; mode=block\";s:6:\"server\";s:3:\"GSE\";s:7:\"alt-svc\";s:37:\"quic=\":443\"; ma=2592000; v=\"44,43,39\"\";}}s:5:\"build\";s:14:\"20190128080509\";}","no");
INSERT INTO `yucqn_options` VALUES("15799","_transient_timeout_feed_mod_76f8d9281c01f21e505004d0986f50c6","1548709150","no");
INSERT INTO `yucqn_options` VALUES("15800","_transient_feed_mod_76f8d9281c01f21e505004d0986f50c6","1548665950","no");
INSERT INTO `yucqn_options` VALUES("15801","_transient_timeout_dash_v2_bd94b8f41e74bae2f4dc72e9bd8379af","1548709150","no");
INSERT INTO `yucqn_options` VALUES("15802","_transient_dash_v2_bd94b8f41e74bae2f4dc72e9bd8379af","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'http://feedproxy.google.com/~r/WordpressFrancophone/~3/BFWuQgyALjg/\'>Think WP, le documentaire vidéo sur WordPress enfin disponible !</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'http://feedproxy.google.com/~r/wpfr/~3/TsolTQn4Zq8/\'>CoSchedule : le plugin pour centraliser votre stratégie de contenu</a></li><li><a class=\'rsswidget\' href=\'http://feedproxy.google.com/~r/wpfr/~3/MTKpaLCGWAY/\'>Clean Login</a></li><li><a class=\'rsswidget\' href=\'http://feedproxy.google.com/~r/wpfr/~3/_bOxk6iL4tg/\'>Ajouter un e-mail dans une liste MailChimp via API</a></li></ul></div>","no");
INSERT INTO `yucqn_options` VALUES("15803","_site_transient_timeout_community-events-1aecf33ab8525ff212ebdffbb438372e","1548709150","no");
INSERT INTO `yucqn_options` VALUES("15804","_site_transient_community-events-1aecf33ab8525ff212ebdffbb438372e","a:2:{s:8:\"location\";a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}s:6:\"events\";a:5:{i:0;a:7:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:46:\"Évaluez la qualité de votre thème WordPress\";s:3:\"url\";s:64:\"https://www.meetup.com/wordpress-ile-de-france/events/258349903/\";s:6:\"meetup\";s:15:\"WordPress Paris\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/wordpress-ile-de-france/\";s:4:\"date\";s:19:\"2019-02-07 18:30:00\";s:8:\"location\";a:4:{s:8:\"location\";s:13:\"Paris, France\";s:7:\"country\";s:2:\"fr\";s:8:\"latitude\";d:48.87214;s:9:\"longitude\";d:2.341154;}}i:1;a:7:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:39:\"Afterwork sur la version 5 de WordPress\";s:3:\"url\";s:63:\"https://www.meetup.com/Meetup-WordPress-Melun/events/258355512/\";s:6:\"meetup\";s:22:\"Meetup WordPress Melun\";s:10:\"meetup_url\";s:46:\"https://www.meetup.com/Meetup-WordPress-Melun/\";s:4:\"date\";s:19:\"2019-02-13 18:00:00\";s:8:\"location\";a:4:{s:8:\"location\";s:19:\"La Rochette, France\";s:7:\"country\";s:2:\"fr\";s:8:\"latitude\";d:48.522823;s:9:\"longitude\";d:2.665582;}}i:2;a:7:{s:4:\"type\";s:8:\"wordcamp\";s:5:\"title\";s:15:\"WordCamp London\";s:3:\"url\";s:32:\"https://2019.london.wordcamp.org\";s:6:\"meetup\";N;s:10:\"meetup_url\";N;s:4:\"date\";s:19:\"2019-04-06 00:00:00\";s:8:\"location\";a:4:{s:8:\"location\";s:6:\"London\";s:7:\"country\";s:2:\"GB\";s:8:\"latitude\";d:51.5516174;s:9:\"longitude\";d:-0.1107146;}}i:3;a:7:{s:4:\"type\";s:8:\"wordcamp\";s:5:\"title\";s:14:\"WordCamp Paris\";s:3:\"url\";s:32:\"https://2019.paris.wordcamp.org/\";s:6:\"meetup\";N;s:10:\"meetup_url\";N;s:4:\"date\";s:19:\"2019-04-24 00:00:00\";s:8:\"location\";a:4:{s:8:\"location\";s:5:\"Paris\";s:7:\"country\";s:2:\"FR\";s:8:\"latitude\";d:48.8835818;s:9:\"longitude\";d:2.3095744;}}i:4;a:7:{s:4:\"type\";s:8:\"wordcamp\";s:5:\"title\";s:16:\"WordCamp Bristol\";s:3:\"url\";s:34:\"https://2019.bristol.wordcamp.org/\";s:6:\"meetup\";N;s:10:\"meetup_url\";N;s:4:\"date\";s:19:\"2019-05-17 00:00:00\";s:8:\"location\";a:4:{s:8:\"location\";s:7:\"Bristol\";s:7:\"country\";s:2:\"GB\";s:8:\"latitude\";d:51.4584172;s:9:\"longitude\";d:-2.6029792;}}}}","no");
INSERT INTO `yucqn_options` VALUES("15805","_transient_timeout_plugin_slugs","1548754012","no");
INSERT INTO `yucqn_options` VALUES("15806","_transient_plugin_slugs","a:12:{i:0;s:41:\"acf-to-rest-api/class-acf-to-rest-api.php\";i:1;s:43:\"acf-to-rest-api-recursive-master/plugin.php\";i:2;s:34:\"advanced-custom-fields-pro/acf.php\";i:3;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:4;s:67:\"better-rest-api-featured-images/better-rest-api-featured-images.php\";i:5;s:54:\"check-and-enable-gzip-compression/richards-toolbox.php\";i:6;s:33:\"color-my-posts/color-my-posts.php\";i:7;s:36:\"google-sitemap-generator/sitemap.php\";i:8;s:75:\"pinterest-pin-it-button-on-image-hover-and-post/pinterest-pin-It-button.php\";i:9;s:23:\"rest-api-tags/index.php\";i:10;s:39:\"wp-rest-api-menus/wp-rest-api-menus.php\";i:11;s:41:\"wp-rest-api-cache/class-wp-rest-cache.php\";}","no");
INSERT INTO `yucqn_options` VALUES("15809","_site_transient_timeout_theme_roots","1548669527","no");
INSERT INTO `yucqn_options` VALUES("15810","_site_transient_theme_roots","a:6:{s:5:\"blank\";s:7:\"/themes\";s:10:\"seadiorama\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";s:14:\"twentynineteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";}","no");
INSERT INTO `yucqn_options` VALUES("15812","_transient_timeout_acf_plugin_updates","1548752567","no");
INSERT INTO `yucqn_options` VALUES("15813","_transient_acf_plugin_updates","a:4:{s:7:\"plugins\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";a:8:{s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:6:\"plugin\";s:34:\"advanced-custom-fields-pro/acf.php\";s:11:\"new_version\";s:6:\"5.7.10\";s:3:\"url\";s:37:\"https://www.advancedcustomfields.com/\";s:6:\"tested\";s:5:\"4.9.9\";s:7:\"package\";s:0:\"\";s:5:\"icons\";a:1:{s:7:\"default\";s:63:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png\";}s:7:\"banners\";a:1:{s:7:\"default\";s:66:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg\";}}}s:10:\"expiration\";i:86400;s:6:\"status\";i:1;s:7:\"checked\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";s:5:\"5.7.7\";}}","no");
INSERT INTO `yucqn_options` VALUES("15834","wp_page_for_privacy_policy","0","yes");
INSERT INTO `yucqn_options` VALUES("15835","show_comments_cookies_opt_in","0","yes");
INSERT INTO `yucqn_options` VALUES("15836","db_upgraded","","yes");
INSERT INTO `yucqn_options` VALUES("15838","can_compress_scripts","0","no");
INSERT INTO `yucqn_options` VALUES("15840","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/fr_FR/wordpress-5.0.3.zip\";s:6:\"locale\";s:5:\"fr_FR\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/fr_FR/wordpress-5.0.3.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.0.3\";s:7:\"version\";s:5:\"5.0.3\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1548667752;s:15:\"version_checked\";s:5:\"5.0.3\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `yucqn_options` VALUES("15841","_site_transient_update_plugins","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1548667752;s:8:\"response\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";O:8:\"stdClass\":8:{s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:6:\"plugin\";s:34:\"advanced-custom-fields-pro/acf.php\";s:11:\"new_version\";s:6:\"5.7.10\";s:3:\"url\";s:37:\"https://www.advancedcustomfields.com/\";s:6:\"tested\";s:5:\"4.9.9\";s:7:\"package\";s:0:\"\";s:5:\"icons\";a:1:{s:7:\"default\";s:63:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png\";}s:7:\"banners\";a:1:{s:7:\"default\";s:66:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg\";}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:9:{s:41:\"acf-to-rest-api/class-acf-to-rest-api.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:29:\"w.org/plugins/acf-to-rest-api\";s:4:\"slug\";s:15:\"acf-to-rest-api\";s:6:\"plugin\";s:41:\"acf-to-rest-api/class-acf-to-rest-api.php\";s:11:\"new_version\";s:5:\"3.1.0\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/acf-to-rest-api/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/acf-to-rest-api.3.1.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/acf-to-rest-api/assets/icon-256x256.jpg?rev=1752896\";s:2:\"1x\";s:68:\"https://ps.w.org/acf-to-rest-api/assets/icon-128x128.jpg?rev=1752896\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:71:\"https://ps.w.org/acf-to-rest-api/assets/banner-1544x500.jpg?rev=1752896\";s:2:\"1x\";s:70:\"https://ps.w.org/acf-to-rest-api/assets/banner-772x250.jpg?rev=1752896\";}s:11:\"banners_rtl\";a:0:{}}s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:7:\"4.3.8.3\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:91:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-1544x500.png?rev=1914011\";s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1914013\";}s:11:\"banners_rtl\";a:0:{}}s:67:\"better-rest-api-featured-images/better-rest-api-featured-images.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:45:\"w.org/plugins/better-rest-api-featured-images\";s:4:\"slug\";s:31:\"better-rest-api-featured-images\";s:6:\"plugin\";s:67:\"better-rest-api-featured-images/better-rest-api-featured-images.php\";s:11:\"new_version\";s:5:\"1.2.1\";s:3:\"url\";s:62:\"https://wordpress.org/plugins/better-rest-api-featured-images/\";s:7:\"package\";s:80:\"https://downloads.wordpress.org/plugin/better-rest-api-featured-images.1.2.1.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:75:\"https://s.w.org/plugins/geopattern-icon/better-rest-api-featured-images.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:54:\"check-and-enable-gzip-compression/richards-toolbox.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:47:\"w.org/plugins/check-and-enable-gzip-compression\";s:4:\"slug\";s:33:\"check-and-enable-gzip-compression\";s:6:\"plugin\";s:54:\"check-and-enable-gzip-compression/richards-toolbox.php\";s:11:\"new_version\";s:6:\"1.1.11\";s:3:\"url\";s:64:\"https://wordpress.org/plugins/check-and-enable-gzip-compression/\";s:7:\"package\";s:76:\"https://downloads.wordpress.org/plugin/check-and-enable-gzip-compression.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:78:\"https://ps.w.org/check-and-enable-gzip-compression/assets/icon.svg?rev=1176583\";s:3:\"svg\";s:78:\"https://ps.w.org/check-and-enable-gzip-compression/assets/icon.svg?rev=1176583\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:33:\"color-my-posts/color-my-posts.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/color-my-posts\";s:4:\"slug\";s:14:\"color-my-posts\";s:6:\"plugin\";s:33:\"color-my-posts/color-my-posts.php\";s:11:\"new_version\";s:3:\"0.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/color-my-posts/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/color-my-posts.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:65:\"https://s.w.org/plugins/geopattern-icon/color-my-posts_f6f1e6.svg\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:68:\"https://ps.w.org/color-my-posts/assets/banner-772x250.png?rev=630278\";}s:11:\"banners_rtl\";a:0:{}}s:36:\"google-sitemap-generator/sitemap.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:38:\"w.org/plugins/google-sitemap-generator\";s:4:\"slug\";s:24:\"google-sitemap-generator\";s:6:\"plugin\";s:36:\"google-sitemap-generator/sitemap.php\";s:11:\"new_version\";s:5:\"4.1.0\";s:3:\"url\";s:55:\"https://wordpress.org/plugins/google-sitemap-generator/\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/plugin/google-sitemap-generator.4.1.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:77:\"https://ps.w.org/google-sitemap-generator/assets/icon-256x256.png?rev=1701944\";s:2:\"1x\";s:77:\"https://ps.w.org/google-sitemap-generator/assets/icon-128x128.png?rev=1701944\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:79:\"https://ps.w.org/google-sitemap-generator/assets/banner-772x250.png?rev=1701944\";}s:11:\"banners_rtl\";a:0:{}}s:75:\"pinterest-pin-it-button-on-image-hover-and-post/pinterest-pin-It-button.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:61:\"w.org/plugins/pinterest-pin-it-button-on-image-hover-and-post\";s:4:\"slug\";s:47:\"pinterest-pin-it-button-on-image-hover-and-post\";s:6:\"plugin\";s:75:\"pinterest-pin-it-button-on-image-hover-and-post/pinterest-pin-It-button.php\";s:11:\"new_version\";s:5:\"2.6.7\";s:3:\"url\";s:78:\"https://wordpress.org/plugins/pinterest-pin-it-button-on-image-hover-and-post/\";s:7:\"package\";s:96:\"https://downloads.wordpress.org/plugin/pinterest-pin-it-button-on-image-hover-and-post.2.6.7.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:100:\"https://ps.w.org/pinterest-pin-it-button-on-image-hover-and-post/assets/icon-256x256.png?rev=1063904\";s:2:\"1x\";s:100:\"https://ps.w.org/pinterest-pin-it-button-on-image-hover-and-post/assets/icon-128x128.png?rev=1063904\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:102:\"https://ps.w.org/pinterest-pin-it-button-on-image-hover-and-post/assets/banner-772x250.jpg?rev=1063904\";}s:11:\"banners_rtl\";a:0:{}}s:39:\"wp-rest-api-menus/wp-rest-api-menus.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:31:\"w.org/plugins/wp-rest-api-menus\";s:4:\"slug\";s:17:\"wp-rest-api-menus\";s:6:\"plugin\";s:39:\"wp-rest-api-menus/wp-rest-api-menus.php\";s:11:\"new_version\";s:3:\"1.0\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/wp-rest-api-menus/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/wp-rest-api-menus.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:70:\"https://ps.w.org/wp-rest-api-menus/assets/icon-128x128.jpg?rev=1842417\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:41:\"wp-rest-api-cache/class-wp-rest-cache.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:31:\"w.org/plugins/wp-rest-api-cache\";s:4:\"slug\";s:17:\"wp-rest-api-cache\";s:6:\"plugin\";s:41:\"wp-rest-api-cache/class-wp-rest-cache.php\";s:11:\"new_version\";s:5:\"1.2.0\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/wp-rest-api-cache/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/wp-rest-api-cache.1.2.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/wp-rest-api-cache/assets/icon-256x256.jpg?rev=1423638\";s:2:\"1x\";s:70:\"https://ps.w.org/wp-rest-api-cache/assets/icon-128x128.jpg?rev=1423638\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wp-rest-api-cache/assets/banner-1544x500.jpg?rev=1423638\";s:2:\"1x\";s:72:\"https://ps.w.org/wp-rest-api-cache/assets/banner-772x250.jpg?rev=1423638\";}s:11:\"banners_rtl\";a:0:{}}}}","no");
INSERT INTO `yucqn_options` VALUES("15842","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1548667753;s:7:\"checked\";a:6:{s:5:\"blank\";s:0:\"\";s:10:\"seadiorama\";s:0:\"\";s:13:\"twentyfifteen\";s:3:\"2.3\";s:14:\"twentynineteen\";s:3:\"1.2\";s:15:\"twentyseventeen\";s:3:\"2.0\";s:13:\"twentysixteen\";s:3:\"1.8\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `yucqn_options` VALUES("15844","_transient_timeout_users_online","1548672878","no");
INSERT INTO `yucqn_options` VALUES("15845","_transient_users_online","a:1:{i:0;a:3:{s:7:\"user_id\";i:1;s:13:\"last_activity\";d:1548674678;s:10:\"ip_address\";s:9:\"127.0.0.1\";}}","no");
INSERT INTO `yucqn_options` VALUES("15846","_transient_doing_cron","1548671078.4194009304046630859375","yes");


DROP TABLE IF EXISTS `yucqn_postmeta`;

CREATE TABLE `yucqn_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2254 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `yucqn_postmeta` VALUES("2","5","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("3","5","field_5a8c42d32b5a2","a:14:{s:3:\"key\";s:19:\"field_5a8c42d32b5a2\";s:5:\"label\";s:4:\"link\";s:4:\"name\";s:4:\"link\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:14:\"Entrer un lien\";s:8:\"required\";s:1:\"0\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:10:\"formatting\";s:4:\"html\";s:9:\"maxlength\";s:0:\"\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:3:{s:5:\"field\";s:4:\"null\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:0:\"\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:0;}");
INSERT INTO `yucqn_postmeta` VALUES("5","5","position","normal");
INSERT INTO `yucqn_postmeta` VALUES("6","5","layout","no_box");
INSERT INTO `yucqn_postmeta` VALUES("7","5","hide_on_screen","a:7:{i:0;s:7:\"excerpt\";i:1;s:10:\"discussion\";i:2;s:8:\"comments\";i:3;s:9:\"revisions\";i:4;s:6:\"author\";i:5;s:6:\"format\";i:6;s:15:\"send-trackbacks\";}");
INSERT INTO `yucqn_postmeta` VALUES("8","5","_edit_lock","1519234255:1");
INSERT INTO `yucqn_postmeta` VALUES("9","6","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("10","6","_edit_lock","1519235667:1");
INSERT INTO `yucqn_postmeta` VALUES("13","7","link","http://www.jbadiorama.com");
INSERT INTO `yucqn_postmeta` VALUES("14","7","_link","field_5a8c42d32b5a2");
INSERT INTO `yucqn_postmeta` VALUES("15","6","link","http://www.jbadiorama.com");
INSERT INTO `yucqn_postmeta` VALUES("16","6","_link","field_5a8c42d32b5a2");
INSERT INTO `yucqn_postmeta` VALUES("20","9","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("21","9","_edit_lock","1524586723:1");
INSERT INTO `yucqn_postmeta` VALUES("22","9","_wp_page_template","contact.php");
INSERT INTO `yucqn_postmeta` VALUES("23","11","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("24","11","field_5a8c46f182839","a:10:{s:3:\"key\";s:19:\"field_5a8c46f182839\";s:5:\"label\";s:7:\"galerie\";s:4:\"name\";s:7:\"galerie\";s:4:\"type\";s:7:\"gallery\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"0\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5a8c47958283a\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"1\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:0;}");
INSERT INTO `yucqn_postmeta` VALUES("25","11","field_5a8c47958283a","a:10:{s:3:\"key\";s:19:\"field_5a8c47958283a\";s:5:\"label\";s:5:\"Vendu\";s:4:\"name\";s:5:\"vendu\";s:4:\"type\";s:10:\"true_false\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"0\";s:7:\"message\";s:0:\"\";s:13:\"default_value\";s:1:\"0\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:3:{s:5:\"field\";s:4:\"null\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:0:\"\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:1;}");
INSERT INTO `yucqn_postmeta` VALUES("26","11","field_5a8c47b38283b","a:11:{s:3:\"key\";s:19:\"field_5a8c47b38283b\";s:5:\"label\";s:12:\"Completed On\";s:4:\"name\";s:12:\"completed_on\";s:4:\"type\";s:11:\"date_picker\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"0\";s:11:\"date_format\";s:6:\"yymmdd\";s:14:\"display_format\";s:8:\"mm/dd/yy\";s:9:\"first_day\";s:1:\"1\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5a8c47958283a\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"1\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:2;}");
INSERT INTO `yucqn_postmeta` VALUES("27","11","field_5a8c47da8283c","a:14:{s:3:\"key\";s:19:\"field_5a8c47da8283c\";s:5:\"label\";s:17:\"Size of the scene\";s:4:\"name\";s:17:\"size_of_the_scene\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"0\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:10:\"formatting\";s:4:\"html\";s:9:\"maxlength\";s:0:\"\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5a8c47958283a\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"1\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:3;}");
INSERT INTO `yucqn_postmeta` VALUES("28","11","field_5a8c47ee8283d","a:14:{s:3:\"key\";s:19:\"field_5a8c47ee8283d\";s:5:\"label\";s:17:\"Size of the frame\";s:4:\"name\";s:17:\"size_of_the_frame\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"0\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:10:\"formatting\";s:4:\"html\";s:9:\"maxlength\";s:0:\"\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5a8c47958283a\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"1\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:4;}");
INSERT INTO `yucqn_postmeta` VALUES("30","11","position","normal");
INSERT INTO `yucqn_postmeta` VALUES("31","11","layout","no_box");
INSERT INTO `yucqn_postmeta` VALUES("32","11","hide_on_screen","a:5:{i:0;s:10:\"discussion\";i:1;s:8:\"comments\";i:2;s:6:\"author\";i:3;s:6:\"format\";i:4;s:15:\"send-trackbacks\";}");
INSERT INTO `yucqn_postmeta` VALUES("33","11","_edit_lock","1524572683:1");
INSERT INTO `yucqn_postmeta` VALUES("34","12","_wp_attached_file","2018/02/1.png");
INSERT INTO `yucqn_postmeta` VALUES("35","12","_wp_attachment_metadata","a:5:{s:5:\"width\";i:861;s:6:\"height\";i:861;s:4:\"file\";s:13:\"2018/02/1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:13:\"1-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("36","13","_wp_attached_file","2018/02/2.png");
INSERT INTO `yucqn_postmeta` VALUES("37","13","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:13:\"2018/02/2.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:13:\"2-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("38","14","_wp_attached_file","2018/02/3.png");
INSERT INTO `yucqn_postmeta` VALUES("39","14","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:13:\"2018/02/3.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"3-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:13:\"3-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("40","15","_wp_attached_file","2018/02/1-1.png");
INSERT INTO `yucqn_postmeta` VALUES("41","15","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:987;s:4:\"file\";s:15:\"2018/02/1-1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"1-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"1-1-300x296.png\";s:5:\"width\";i:300;s:6:\"height\";i:296;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"1-1-768x758.png\";s:5:\"width\";i:768;s:6:\"height\";i:758;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("42","16","_wp_attached_file","2018/02/2-1.png");
INSERT INTO `yucqn_postmeta` VALUES("43","16","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:15:\"2018/02/2-1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"2-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"2-1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"2-1-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("44","17","_wp_attached_file","2018/02/3-1.png");
INSERT INTO `yucqn_postmeta` VALUES("45","17","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:15:\"2018/02/3-1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"3-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"3-1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"3-1-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("46","18","_wp_attached_file","2018/02/4.png");
INSERT INTO `yucqn_postmeta` VALUES("47","18","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:13:\"2018/02/4.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"4-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"4-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:13:\"4-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("56","23","_wp_attached_file","2018/02/g1.png");
INSERT INTO `yucqn_postmeta` VALUES("57","23","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:943;s:4:\"file\";s:14:\"2018/02/g1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"g1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"g1-300x283.png\";s:5:\"width\";i:300;s:6:\"height\";i:283;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:14:\"g1-768x724.png\";s:5:\"width\";i:768;s:6:\"height\";i:724;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("58","24","_wp_attached_file","2018/02/g2.png");
INSERT INTO `yucqn_postmeta` VALUES("59","24","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:14:\"2018/02/g2.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"g2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"g2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:14:\"g2-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("60","25","_wp_attached_file","2018/02/g3.png");
INSERT INTO `yucqn_postmeta` VALUES("61","25","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1025;s:4:\"file\";s:14:\"2018/02/g3.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"g3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"g3-293x300.png\";s:5:\"width\";i:293;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:14:\"g3-768x787.png\";s:5:\"width\";i:768;s:6:\"height\";i:787;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:15:\"g3-999x1024.png\";s:5:\"width\";i:999;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("62","26","_wp_attached_file","2018/02/g4.png");
INSERT INTO `yucqn_postmeta` VALUES("63","26","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:14:\"2018/02/g4.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"g4-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"g4-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:14:\"g4-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("68","29","_wp_attached_file","2018/02/MG_0915.png");
INSERT INTO `yucqn_postmeta` VALUES("69","29","_wp_attachment_metadata","a:5:{s:5:\"width\";i:976;s:6:\"height\";i:928;s:4:\"file\";s:19:\"2018/02/MG_0915.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_0915-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_0915-300x285.png\";s:5:\"width\";i:300;s:6:\"height\";i:285;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_0915-768x730.png\";s:5:\"width\";i:768;s:6:\"height\";i:730;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("70","30","_wp_attached_file","2018/02/MG_0928.png");
INSERT INTO `yucqn_postmeta` VALUES("71","30","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/02/MG_0928.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_0928-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_0928-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_0928-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("72","31","_wp_attached_file","2018/02/MG_0930.png");
INSERT INTO `yucqn_postmeta` VALUES("73","31","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:969;s:4:\"file\";s:19:\"2018/02/MG_0930.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_0930-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_0930-300x291.png\";s:5:\"width\";i:300;s:6:\"height\";i:291;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_0930-768x744.png\";s:5:\"width\";i:768;s:6:\"height\";i:744;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("74","32","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("75","32","_edit_lock","1525710953:1");
INSERT INTO `yucqn_postmeta` VALUES("78","33","galerie","a:3:{i:0;s:2:\"14\";i:1;s:2:\"13\";i:2;s:2:\"12\";}");
INSERT INTO `yucqn_postmeta` VALUES("79","33","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("80","33","vendu","1");
INSERT INTO `yucqn_postmeta` VALUES("81","33","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("82","33","completed_on","20180218");
INSERT INTO `yucqn_postmeta` VALUES("83","33","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("84","33","size_of_the_scene","15x15");
INSERT INTO `yucqn_postmeta` VALUES("85","33","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("86","33","size_of_the_frame","20x20");
INSERT INTO `yucqn_postmeta` VALUES("87","33","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("88","32","galerie","a:3:{i:0;s:2:\"14\";i:1;s:2:\"13\";i:2;s:2:\"12\";}");
INSERT INTO `yucqn_postmeta` VALUES("89","32","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("90","32","vendu","1");
INSERT INTO `yucqn_postmeta` VALUES("91","32","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("92","32","completed_on","20180218");
INSERT INTO `yucqn_postmeta` VALUES("93","32","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("94","32","size_of_the_scene","15x15");
INSERT INTO `yucqn_postmeta` VALUES("95","32","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("96","32","size_of_the_frame","20x20");
INSERT INTO `yucqn_postmeta` VALUES("97","32","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("98","34","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("99","34","_edit_lock","1527088545:1");
INSERT INTO `yucqn_postmeta` VALUES("100","34","_wp_page_template","index.php");
INSERT INTO `yucqn_postmeta` VALUES("101","36","_wp_attached_file","2018/02/lk1.png");
INSERT INTO `yucqn_postmeta` VALUES("102","36","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:814;s:4:\"file\";s:15:\"2018/02/lk1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"lk1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"lk1-300x244.png\";s:5:\"width\";i:300;s:6:\"height\";i:244;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"lk1-768x625.png\";s:5:\"width\";i:768;s:6:\"height\";i:625;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("103","37","_wp_attached_file","2018/02/lk2.png");
INSERT INTO `yucqn_postmeta` VALUES("104","37","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:805;s:4:\"file\";s:15:\"2018/02/lk2.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"lk2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"lk2-300x242.png\";s:5:\"width\";i:300;s:6:\"height\";i:242;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"lk2-768x618.png\";s:5:\"width\";i:768;s:6:\"height\";i:618;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("107","39","_wp_attached_file","2018/02/lk3.png");
INSERT INTO `yucqn_postmeta` VALUES("108","39","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:836;s:4:\"file\";s:15:\"2018/02/lk3.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"lk3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"lk3-300x251.png\";s:5:\"width\";i:300;s:6:\"height\";i:251;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"lk3-768x642.png\";s:5:\"width\";i:768;s:6:\"height\";i:642;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("117","44","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("118","44","field_5a8c520821ff9","a:14:{s:3:\"key\";s:19:\"field_5a8c520821ff9\";s:5:\"label\";s:7:\"Marquee\";s:4:\"name\";s:7:\"marquee\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"0\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:10:\"formatting\";s:4:\"html\";s:9:\"maxlength\";s:0:\"\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:3:{s:5:\"field\";s:4:\"null\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:0:\"\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:0;}");
INSERT INTO `yucqn_postmeta` VALUES("119","44","field_5a8c522321ffa","a:14:{s:3:\"key\";s:19:\"field_5a8c522321ffa\";s:5:\"label\";s:16:\"url de la vidéo\";s:4:\"name\";s:15:\"url_de_la_video\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"0\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:10:\"formatting\";s:4:\"html\";s:9:\"maxlength\";s:0:\"\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:3:{s:5:\"field\";s:4:\"null\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:0:\"\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:1;}");
INSERT INTO `yucqn_postmeta` VALUES("120","44","field_5a8c523321ffb","a:11:{s:3:\"key\";s:19:\"field_5a8c523321ffb\";s:5:\"label\";s:12:\"masque video\";s:4:\"name\";s:12:\"masque_video\";s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"0\";s:11:\"save_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:3:{s:5:\"field\";s:4:\"null\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:0:\"\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:3;}");
INSERT INTO `yucqn_postmeta` VALUES("122","44","position","normal");
INSERT INTO `yucqn_postmeta` VALUES("123","44","layout","no_box");
INSERT INTO `yucqn_postmeta` VALUES("124","44","hide_on_screen","");
INSERT INTO `yucqn_postmeta` VALUES("125","44","_edit_lock","1527085535:1");
INSERT INTO `yucqn_postmeta` VALUES("126","46","marquee","Here are my dioramas, the latest done on top, older on the bottom, you may click on each one to see other pictures, thank you very much -- ");
INSERT INTO `yucqn_postmeta` VALUES("127","46","_marquee","field_5a8c520821ff9");
INSERT INTO `yucqn_postmeta` VALUES("128","46","url_de_la_video","http://youtu.be/BsekcY04xvQ");
INSERT INTO `yucqn_postmeta` VALUES("129","46","_url_de_la_video","field_5a8c522321ffa");
INSERT INTO `yucqn_postmeta` VALUES("130","46","_","field_5a8c523321ffb");
INSERT INTO `yucqn_postmeta` VALUES("131","34","marquee","Here are my dioramas, the latest done on top, older on the bottom, you may click on each one to see other pictures, thank you very much -- ");
INSERT INTO `yucqn_postmeta` VALUES("132","34","_marquee","field_5a8c520821ff9");
INSERT INTO `yucqn_postmeta` VALUES("133","34","url_de_la_video","https://youtu.be/RTGbdr4yc7c");
INSERT INTO `yucqn_postmeta` VALUES("134","34","_url_de_la_video","field_5a8c522321ffa");
INSERT INTO `yucqn_postmeta` VALUES("135","34","_","field_5a8c523321ffb");
INSERT INTO `yucqn_postmeta` VALUES("138","32","_thumbnail_id","12");
INSERT INTO `yucqn_postmeta` VALUES("141","48","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("142","48","_edit_lock","1525710945:1");
INSERT INTO `yucqn_postmeta` VALUES("144","49","galerie","a:3:{i:0;s:2:\"39\";i:1;s:2:\"37\";i:2;s:2:\"36\";}");
INSERT INTO `yucqn_postmeta` VALUES("145","49","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("146","49","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("147","49","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("148","49","completed_on","20180109");
INSERT INTO `yucqn_postmeta` VALUES("149","49","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("150","49","size_of_the_scene","10x14");
INSERT INTO `yucqn_postmeta` VALUES("151","49","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("152","49","size_of_the_frame","14x18");
INSERT INTO `yucqn_postmeta` VALUES("153","49","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("154","48","galerie","a:3:{i:0;s:3:\"183\";i:1;s:3:\"182\";i:2;s:3:\"181\";}");
INSERT INTO `yucqn_postmeta` VALUES("155","48","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("156","48","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("157","48","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("158","48","completed_on","20180109");
INSERT INTO `yucqn_postmeta` VALUES("159","48","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("160","48","size_of_the_scene","14x9");
INSERT INTO `yucqn_postmeta` VALUES("161","48","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("162","48","size_of_the_frame","17,5x12,5");
INSERT INTO `yucqn_postmeta` VALUES("163","48","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("166","50","galerie","a:3:{i:0;s:2:\"39\";i:1;s:2:\"37\";i:2;s:2:\"36\";}");
INSERT INTO `yucqn_postmeta` VALUES("167","50","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("168","50","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("169","50","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("170","50","completed_on","20180109");
INSERT INTO `yucqn_postmeta` VALUES("171","50","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("172","50","size_of_the_scene","10x14");
INSERT INTO `yucqn_postmeta` VALUES("173","50","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("174","50","size_of_the_frame","14x18");
INSERT INTO `yucqn_postmeta` VALUES("175","50","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("178","52","_wp_attached_file","2018/02/jean_diorama_BdatBxWl6UM.jpg");
INSERT INTO `yucqn_postmeta` VALUES("179","52","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:36:\"2018/02/jean_diorama_BdatBxWl6UM.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"jean_diorama_BdatBxWl6UM-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"jean_diorama_BdatBxWl6UM-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"jean_diorama_BdatBxWl6UM-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("180","53","_wp_attached_file","2018/02/jean_diorama_BdatBddF5K4.jpg");
INSERT INTO `yucqn_postmeta` VALUES("181","53","_wp_attachment_metadata","a:5:{s:5:\"width\";i:973;s:6:\"height\";i:973;s:4:\"file\";s:36:\"2018/02/jean_diorama_BdatBddF5K4.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"jean_diorama_BdatBddF5K4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"jean_diorama_BdatBddF5K4-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"jean_diorama_BdatBddF5K4-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("182","54","_wp_attached_file","2018/02/jean_diorama_BdatBLXFDay.jpg");
INSERT INTO `yucqn_postmeta` VALUES("183","54","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:36:\"2018/02/jean_diorama_BdatBLXFDay.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"jean_diorama_BdatBLXFDay-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"jean_diorama_BdatBLXFDay-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"jean_diorama_BdatBLXFDay-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("216","57","_menu_item_type","post_type");
INSERT INTO `yucqn_postmeta` VALUES("217","57","_menu_item_menu_item_parent","0");
INSERT INTO `yucqn_postmeta` VALUES("218","57","_menu_item_object_id","9");
INSERT INTO `yucqn_postmeta` VALUES("219","57","_menu_item_object","page");
INSERT INTO `yucqn_postmeta` VALUES("220","57","_menu_item_target","");
INSERT INTO `yucqn_postmeta` VALUES("221","57","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `yucqn_postmeta` VALUES("222","57","_menu_item_xfn","");
INSERT INTO `yucqn_postmeta` VALUES("223","57","_menu_item_url","");
INSERT INTO `yucqn_postmeta` VALUES("234","59","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("235","59","_edit_lock","1519234513:1");
INSERT INTO `yucqn_postmeta` VALUES("238","60","link","http://www.mrpaint.sk/");
INSERT INTO `yucqn_postmeta` VALUES("239","60","_link","field_5a8c42d32b5a2");
INSERT INTO `yucqn_postmeta` VALUES("240","59","link","http://www.mrpaint.sk/");
INSERT INTO `yucqn_postmeta` VALUES("241","59","_link","field_5a8c42d32b5a2");
INSERT INTO `yucqn_postmeta` VALUES("242","61","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("243","61","_edit_lock","1519234440:1");
INSERT INTO `yucqn_postmeta` VALUES("246","62","link","http://www.model-scene.com/");
INSERT INTO `yucqn_postmeta` VALUES("247","62","_link","field_5a8c42d32b5a2");
INSERT INTO `yucqn_postmeta` VALUES("248","61","link","http://www.model-scene.com/");
INSERT INTO `yucqn_postmeta` VALUES("249","61","_link","field_5a8c42d32b5a2");
INSERT INTO `yucqn_postmeta` VALUES("250","5","rule","a:5:{s:5:\"param\";s:13:\"post_category\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"3\";s:8:\"order_no\";i:0;s:8:\"group_no\";i:0;}");
INSERT INTO `yucqn_postmeta` VALUES("253","63","link","http://www.model-scene.com/");
INSERT INTO `yucqn_postmeta` VALUES("254","63","_link","field_5a8c42d32b5a2");
INSERT INTO `yucqn_postmeta` VALUES("257","64","link","http://www.mrpaint.sk/");
INSERT INTO `yucqn_postmeta` VALUES("258","64","_link","field_5a8c42d32b5a2");
INSERT INTO `yucqn_postmeta` VALUES("261","65","link","http://www.jbadiorama.com");
INSERT INTO `yucqn_postmeta` VALUES("262","65","_link","field_5a8c42d32b5a2");
INSERT INTO `yucqn_postmeta` VALUES("263","66","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("264","66","_edit_lock","1525710937:1");
INSERT INTO `yucqn_postmeta` VALUES("265","67","_wp_attached_file","2018/02/gl1.jpg");
INSERT INTO `yucqn_postmeta` VALUES("266","67","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:15:\"2018/02/gl1.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"gl1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"gl1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"gl1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:17:\"gl1-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:15:\"gl1-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("267","68","_wp_attached_file","2018/02/gl2.jpg");
INSERT INTO `yucqn_postmeta` VALUES("268","68","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:15:\"2018/02/gl2.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"gl2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"gl2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"gl2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:17:\"gl2-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:15:\"gl2-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("269","69","_wp_attached_file","2018/02/gl3.jpg");
INSERT INTO `yucqn_postmeta` VALUES("270","69","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:15:\"2018/02/gl3.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"gl3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"gl3-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"gl3-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:17:\"gl3-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:15:\"gl3-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("271","70","_wp_attached_file","2018/02/gl4.jpg");
INSERT INTO `yucqn_postmeta` VALUES("272","70","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:15:\"2018/02/gl4.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"gl4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"gl4-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"gl4-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:17:\"gl4-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:15:\"gl4-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("273","67","_wp_attachment_image_alt","White shore diorama 1/35");
INSERT INTO `yucqn_postmeta` VALUES("276","71","galerie","a:4:{i:0;s:2:\"67\";i:1;s:2:\"68\";i:2;s:2:\"69\";i:3;s:2:\"70\";}");
INSERT INTO `yucqn_postmeta` VALUES("277","71","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("278","71","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("279","71","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("280","71","completed_on","20171128");
INSERT INTO `yucqn_postmeta` VALUES("281","71","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("282","71","size_of_the_scene","16x16");
INSERT INTO `yucqn_postmeta` VALUES("283","71","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("284","71","size_of_the_frame","24x24");
INSERT INTO `yucqn_postmeta` VALUES("285","71","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("286","66","galerie","a:4:{i:0;s:2:\"67\";i:1;s:2:\"68\";i:2;s:2:\"69\";i:3;s:2:\"70\";}");
INSERT INTO `yucqn_postmeta` VALUES("287","66","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("288","66","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("289","66","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("290","66","completed_on","20171128");
INSERT INTO `yucqn_postmeta` VALUES("291","66","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("292","66","size_of_the_scene","16x16");
INSERT INTO `yucqn_postmeta` VALUES("293","66","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("294","66","size_of_the_frame","22,5x22,5");
INSERT INTO `yucqn_postmeta` VALUES("295","66","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("299","72","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("300","72","_edit_lock","1525710917:1");
INSERT INTO `yucqn_postmeta` VALUES("301","73","_wp_attached_file","2018/02/seashore1.jpg");
INSERT INTO `yucqn_postmeta` VALUES("302","73","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:21:\"2018/02/seashore1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"seashore1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"seashore1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"seashore1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:21:\"seashore1-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("303","74","_wp_attached_file","2018/02/seashore2.jpg");
INSERT INTO `yucqn_postmeta` VALUES("304","74","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:21:\"2018/02/seashore2.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"seashore2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"seashore2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"seashore2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:21:\"seashore2-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("305","75","_wp_attached_file","2018/02/seashore3.jpg");
INSERT INTO `yucqn_postmeta` VALUES("306","75","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:21:\"2018/02/seashore3.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"seashore3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"seashore3-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"seashore3-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:21:\"seashore3-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("307","76","_wp_attached_file","2018/02/seashore4.jpg");
INSERT INTO `yucqn_postmeta` VALUES("308","76","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:21:\"2018/02/seashore4.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"seashore4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"seashore4-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"seashore4-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"seashore4-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:21:\"seashore4-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("309","77","_wp_attached_file","2018/02/seashore5.jpg");
INSERT INTO `yucqn_postmeta` VALUES("310","77","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:21:\"2018/02/seashore5.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"seashore5-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"seashore5-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"seashore5-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"seashore5-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:21:\"seashore5-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("313","78","galerie","a:5:{i:0;s:2:\"73\";i:1;s:2:\"74\";i:2;s:2:\"75\";i:3;s:2:\"76\";i:4;s:2:\"77\";}");
INSERT INTO `yucqn_postmeta` VALUES("314","78","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("315","78","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("316","78","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("317","78","completed_on","20171207");
INSERT INTO `yucqn_postmeta` VALUES("318","78","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("319","78","size_of_the_scene","10x16");
INSERT INTO `yucqn_postmeta` VALUES("320","78","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("321","78","size_of_the_frame","14x20");
INSERT INTO `yucqn_postmeta` VALUES("322","78","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("323","72","galerie","a:5:{i:0;s:2:\"73\";i:1;s:2:\"74\";i:2;s:2:\"75\";i:3;s:2:\"76\";i:4;s:2:\"77\";}");
INSERT INTO `yucqn_postmeta` VALUES("324","72","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("325","72","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("326","72","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("327","72","completed_on","20171207");
INSERT INTO `yucqn_postmeta` VALUES("328","72","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("329","72","size_of_the_scene","13,5x8,5");
INSERT INTO `yucqn_postmeta` VALUES("330","72","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("331","72","size_of_the_frame","17,5x12,5");
INSERT INTO `yucqn_postmeta` VALUES("332","72","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("333","72","_thumbnail_id","202");
INSERT INTO `yucqn_postmeta` VALUES("335","79","_wp_attached_file","2018/02/fd.png");
INSERT INTO `yucqn_postmeta` VALUES("336","79","_wp_attachment_metadata","a:5:{s:5:\"width\";i:600;s:6:\"height\";i:600;s:4:\"file\";s:14:\"2018/02/fd.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"fd-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"fd-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:14:\"fd-500x500.png\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("337","80","marquee","Here are my dioramas, the latest done on top, older on the bottom, you may click on each one to see other pictures, thank you very much -- ");
INSERT INTO `yucqn_postmeta` VALUES("338","80","_marquee","field_5a8c520821ff9");
INSERT INTO `yucqn_postmeta` VALUES("339","80","url_de_la_video","http://youtu.be/BsekcY04xvQ");
INSERT INTO `yucqn_postmeta` VALUES("340","80","_url_de_la_video","field_5a8c522321ffa");
INSERT INTO `yucqn_postmeta` VALUES("341","80","masque_video","79");
INSERT INTO `yucqn_postmeta` VALUES("342","80","_masque_video","field_5a8c523321ffb");
INSERT INTO `yucqn_postmeta` VALUES("343","34","masque_video","128");
INSERT INTO `yucqn_postmeta` VALUES("344","34","_masque_video","field_5a8c523321ffb");
INSERT INTO `yucqn_postmeta` VALUES("347","82","galerie","a:5:{i:0;s:2:\"73\";i:1;s:2:\"74\";i:2;s:2:\"75\";i:3;s:2:\"76\";i:4;s:2:\"77\";}");
INSERT INTO `yucqn_postmeta` VALUES("348","82","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("349","82","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("350","82","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("351","82","completed_on","20171207");
INSERT INTO `yucqn_postmeta` VALUES("352","82","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("353","82","size_of_the_scene","13,5x8,5");
INSERT INTO `yucqn_postmeta` VALUES("354","82","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("355","82","size_of_the_frame","17,5x12,5");
INSERT INTO `yucqn_postmeta` VALUES("356","82","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("359","83","galerie","a:5:{i:0;s:2:\"73\";i:1;s:2:\"74\";i:2;s:2:\"75\";i:3;s:2:\"76\";i:4;s:2:\"77\";}");
INSERT INTO `yucqn_postmeta` VALUES("360","83","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("361","83","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("362","83","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("363","83","completed_on","20171207");
INSERT INTO `yucqn_postmeta` VALUES("364","83","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("365","83","size_of_the_scene","13,5x8,5");
INSERT INTO `yucqn_postmeta` VALUES("366","83","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("367","83","size_of_the_frame","17,5x12,5");
INSERT INTO `yucqn_postmeta` VALUES("368","83","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("371","84","galerie","a:5:{i:0;s:2:\"73\";i:1;s:2:\"74\";i:2;s:2:\"75\";i:3;s:2:\"76\";i:4;s:2:\"77\";}");
INSERT INTO `yucqn_postmeta` VALUES("372","84","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("373","84","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("374","84","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("375","84","completed_on","20171207");
INSERT INTO `yucqn_postmeta` VALUES("376","84","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("377","84","size_of_the_scene","13,5x8,5");
INSERT INTO `yucqn_postmeta` VALUES("378","84","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("379","84","size_of_the_frame","17,5x12,5");
INSERT INTO `yucqn_postmeta` VALUES("380","84","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("383","86","galerie","a:3:{i:0;s:2:\"14\";i:1;s:2:\"13\";i:2;s:2:\"12\";}");
INSERT INTO `yucqn_postmeta` VALUES("384","86","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("385","86","vendu","1");
INSERT INTO `yucqn_postmeta` VALUES("386","86","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("387","86","completed_on","20180218");
INSERT INTO `yucqn_postmeta` VALUES("388","86","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("389","86","size_of_the_scene","15x15");
INSERT INTO `yucqn_postmeta` VALUES("390","86","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("391","86","size_of_the_frame","20x20");
INSERT INTO `yucqn_postmeta` VALUES("392","86","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("397","87","galerie","a:4:{i:0;s:2:\"67\";i:1;s:2:\"68\";i:2;s:2:\"69\";i:3;s:2:\"70\";}");
INSERT INTO `yucqn_postmeta` VALUES("398","87","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("399","87","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("400","87","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("401","87","completed_on","20171128");
INSERT INTO `yucqn_postmeta` VALUES("402","87","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("403","87","size_of_the_scene","16x16");
INSERT INTO `yucqn_postmeta` VALUES("404","87","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("405","87","size_of_the_frame","24x24");
INSERT INTO `yucqn_postmeta` VALUES("406","87","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("409","88","galerie","a:4:{i:0;s:2:\"67\";i:1;s:2:\"68\";i:2;s:2:\"69\";i:3;s:2:\"70\";}");
INSERT INTO `yucqn_postmeta` VALUES("410","88","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("411","88","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("412","88","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("413","88","completed_on","20171128");
INSERT INTO `yucqn_postmeta` VALUES("414","88","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("415","88","size_of_the_scene","16x16");
INSERT INTO `yucqn_postmeta` VALUES("416","88","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("417","88","size_of_the_frame","24x24");
INSERT INTO `yucqn_postmeta` VALUES("418","88","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("421","90","galerie","a:3:{i:0;s:2:\"39\";i:1;s:2:\"37\";i:2;s:2:\"36\";}");
INSERT INTO `yucqn_postmeta` VALUES("422","90","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("423","90","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("424","90","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("425","90","completed_on","20180109");
INSERT INTO `yucqn_postmeta` VALUES("426","90","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("427","90","size_of_the_scene","14x9");
INSERT INTO `yucqn_postmeta` VALUES("428","90","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("429","90","size_of_the_frame","17,5x12,5");
INSERT INTO `yucqn_postmeta` VALUES("430","90","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("433","91","galerie","a:4:{i:0;s:2:\"67\";i:1;s:2:\"68\";i:2;s:2:\"69\";i:3;s:2:\"70\";}");
INSERT INTO `yucqn_postmeta` VALUES("434","91","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("435","91","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("436","91","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("437","91","completed_on","20171128");
INSERT INTO `yucqn_postmeta` VALUES("438","91","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("439","91","size_of_the_scene","16,5x16,5");
INSERT INTO `yucqn_postmeta` VALUES("440","91","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("441","91","size_of_the_frame","22,5x22,5");
INSERT INTO `yucqn_postmeta` VALUES("442","91","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("445","92","galerie","a:4:{i:0;s:2:\"67\";i:1;s:2:\"68\";i:2;s:2:\"69\";i:3;s:2:\"70\";}");
INSERT INTO `yucqn_postmeta` VALUES("446","92","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("447","92","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("448","92","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("449","92","completed_on","20171128");
INSERT INTO `yucqn_postmeta` VALUES("450","92","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("451","92","size_of_the_scene","16x16");
INSERT INTO `yucqn_postmeta` VALUES("452","92","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("453","92","size_of_the_frame","22,5x22,5");
INSERT INTO `yucqn_postmeta` VALUES("454","92","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("455","93","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("456","93","_edit_lock","1525710910:1");
INSERT INTO `yucqn_postmeta` VALUES("457","93","_thumbnail_id","201");
INSERT INTO `yucqn_postmeta` VALUES("460","94","galerie","a:4:{i:0;s:2:\"26\";i:1;s:2:\"25\";i:2;s:2:\"24\";i:3;s:2:\"23\";}");
INSERT INTO `yucqn_postmeta` VALUES("461","94","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("462","94","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("463","94","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("464","94","completed_on","20180211");
INSERT INTO `yucqn_postmeta` VALUES("465","94","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("466","94","size_of_the_scene","16,5x16,5");
INSERT INTO `yucqn_postmeta` VALUES("467","94","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("468","94","size_of_the_frame","22,5x22,5");
INSERT INTO `yucqn_postmeta` VALUES("469","94","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("470","93","galerie","a:4:{i:0;s:2:\"26\";i:1;s:2:\"25\";i:2;s:2:\"24\";i:3;s:2:\"23\";}");
INSERT INTO `yucqn_postmeta` VALUES("471","93","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("472","93","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("473","93","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("474","93","completed_on","20180211");
INSERT INTO `yucqn_postmeta` VALUES("475","93","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("476","93","size_of_the_scene","16,5x16,5");
INSERT INTO `yucqn_postmeta` VALUES("477","93","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("478","93","size_of_the_frame","22,5x22,5");
INSERT INTO `yucqn_postmeta` VALUES("479","93","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("480","95","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("481","95","_edit_lock","1525710899:1");
INSERT INTO `yucqn_postmeta` VALUES("482","95","_thumbnail_id","203");
INSERT INTO `yucqn_postmeta` VALUES("485","96","galerie","a:3:{i:0;s:2:\"31\";i:1;s:2:\"30\";i:2;s:2:\"29\";}");
INSERT INTO `yucqn_postmeta` VALUES("486","96","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("487","96","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("488","96","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("489","96","completed_on","20180211");
INSERT INTO `yucqn_postmeta` VALUES("490","96","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("491","96","size_of_the_scene","13,5x13,5");
INSERT INTO `yucqn_postmeta` VALUES("492","96","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("493","96","size_of_the_frame","20x20");
INSERT INTO `yucqn_postmeta` VALUES("494","96","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("495","95","galerie","a:3:{i:0;s:2:\"31\";i:1;s:2:\"30\";i:2;s:2:\"29\";}");
INSERT INTO `yucqn_postmeta` VALUES("496","95","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("497","95","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("498","95","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("499","95","completed_on","20170211");
INSERT INTO `yucqn_postmeta` VALUES("500","95","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("501","95","size_of_the_scene","13,5x13,5");
INSERT INTO `yucqn_postmeta` VALUES("502","95","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("503","95","size_of_the_frame","20x20");
INSERT INTO `yucqn_postmeta` VALUES("504","95","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("507","97","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("508","97","_edit_lock","1525710890:1");
INSERT INTO `yucqn_postmeta` VALUES("512","98","galerie","a:3:{i:0;s:2:\"38\";i:1;s:2:\"40\";i:2;s:2:\"41\";}");
INSERT INTO `yucqn_postmeta` VALUES("513","98","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("514","98","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("515","98","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("516","98","completed_on","20180107");
INSERT INTO `yucqn_postmeta` VALUES("517","98","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("518","98","size_of_the_scene","15x10");
INSERT INTO `yucqn_postmeta` VALUES("519","98","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("520","98","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("521","98","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("522","97","galerie","a:4:{i:0;s:3:\"177\";i:1;s:3:\"176\";i:2;s:3:\"175\";i:3;s:3:\"174\";}");
INSERT INTO `yucqn_postmeta` VALUES("523","97","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("524","97","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("525","97","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("526","97","completed_on","20180107");
INSERT INTO `yucqn_postmeta` VALUES("527","97","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("528","97","size_of_the_scene","15x10");
INSERT INTO `yucqn_postmeta` VALUES("529","97","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("530","97","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("531","97","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("532","99","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("533","99","_edit_lock","1525693387:1");
INSERT INTO `yucqn_postmeta` VALUES("534","99","_thumbnail_id","54");
INSERT INTO `yucqn_postmeta` VALUES("537","100","galerie","a:3:{i:0;s:2:\"54\";i:1;s:2:\"53\";i:2;s:2:\"52\";}");
INSERT INTO `yucqn_postmeta` VALUES("538","100","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("539","100","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("540","100","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("541","100","completed_on","20180101");
INSERT INTO `yucqn_postmeta` VALUES("542","100","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("543","100","size_of_the_scene","13x8");
INSERT INTO `yucqn_postmeta` VALUES("544","100","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("545","100","size_of_the_frame","17,5x12,5");
INSERT INTO `yucqn_postmeta` VALUES("546","100","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("547","99","galerie","a:3:{i:0;s:2:\"54\";i:1;s:2:\"53\";i:2;s:2:\"52\";}");
INSERT INTO `yucqn_postmeta` VALUES("548","99","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("549","99","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("550","99","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("551","99","completed_on","20180101");
INSERT INTO `yucqn_postmeta` VALUES("552","99","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("553","99","size_of_the_scene","13x8");
INSERT INTO `yucqn_postmeta` VALUES("554","99","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("555","99","size_of_the_frame","17,5x12,5");
INSERT INTO `yucqn_postmeta` VALUES("556","99","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("557","101","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("558","101","_edit_lock","1525266623:1");
INSERT INTO `yucqn_postmeta` VALUES("562","102","galerie","a:4:{i:0;s:2:\"22\";i:1;s:2:\"21\";i:2;s:2:\"20\";i:3;s:2:\"19\";}");
INSERT INTO `yucqn_postmeta` VALUES("563","102","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("564","102","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("565","102","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("566","102","completed_on","20180220");
INSERT INTO `yucqn_postmeta` VALUES("567","102","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("568","102","size_of_the_scene","14,5x9,5");
INSERT INTO `yucqn_postmeta` VALUES("569","102","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("570","102","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("571","102","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("572","101","galerie","a:4:{i:0;s:3:\"186\";i:1;s:3:\"185\";i:2;s:3:\"184\";i:3;s:3:\"191\";}");
INSERT INTO `yucqn_postmeta` VALUES("573","101","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("574","101","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("575","101","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("576","101","completed_on","20180220");
INSERT INTO `yucqn_postmeta` VALUES("577","101","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("578","101","size_of_the_scene","14,5x9,5");
INSERT INTO `yucqn_postmeta` VALUES("579","101","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("580","101","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("581","101","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("582","103","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("583","103","_edit_lock","1525266598:1");
INSERT INTO `yucqn_postmeta` VALUES("587","104","galerie","a:2:{i:0;s:2:\"28\";i:1;s:2:\"27\";}");
INSERT INTO `yucqn_postmeta` VALUES("588","104","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("589","104","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("590","104","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("591","104","completed_on","20171220");
INSERT INTO `yucqn_postmeta` VALUES("592","104","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("593","104","size_of_the_scene","14x10");
INSERT INTO `yucqn_postmeta` VALUES("594","104","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("595","104","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("596","104","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("597","103","galerie","a:3:{i:0;s:3:\"160\";i:1;s:3:\"162\";i:2;s:3:\"161\";}");
INSERT INTO `yucqn_postmeta` VALUES("598","103","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("599","103","vendu","1");
INSERT INTO `yucqn_postmeta` VALUES("600","103","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("601","103","completed_on","20171220");
INSERT INTO `yucqn_postmeta` VALUES("602","103","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("603","103","size_of_the_scene","14x10");
INSERT INTO `yucqn_postmeta` VALUES("604","103","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("605","103","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("606","103","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("609","105","galerie","a:2:{i:0;s:2:\"28\";i:1;s:2:\"27\";}");
INSERT INTO `yucqn_postmeta` VALUES("610","105","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("611","105","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("612","105","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("613","105","completed_on","20171220");
INSERT INTO `yucqn_postmeta` VALUES("614","105","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("615","105","size_of_the_scene","14x10");
INSERT INTO `yucqn_postmeta` VALUES("616","105","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("617","105","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("618","105","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("619","106","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("620","106","_edit_lock","1525710873:1");
INSERT INTO `yucqn_postmeta` VALUES("621","107","_wp_attached_file","2018/02/jean_diorama_BcqKpywl-Gb-1.jpg");
INSERT INTO `yucqn_postmeta` VALUES("622","107","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:38:\"2018/02/jean_diorama_BcqKpywl-Gb-1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:38:\"jean_diorama_BcqKpywl-Gb-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:38:\"jean_diorama_BcqKpywl-Gb-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:38:\"jean_diorama_BcqKpywl-Gb-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:38:\"jean_diorama_BcqKpywl-Gb-1-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("623","108","_wp_attached_file","2018/02/jean_diorama_BcapR_yls4n.jpg");
INSERT INTO `yucqn_postmeta` VALUES("624","108","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:36:\"2018/02/jean_diorama_BcapR_yls4n.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"jean_diorama_BcapR_yls4n-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"jean_diorama_BcapR_yls4n-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"jean_diorama_BcapR_yls4n-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:36:\"jean_diorama_BcapR_yls4n-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("625","109","_wp_attached_file","2018/02/jean_diorama_BcqKrCfli0O.jpg");
INSERT INTO `yucqn_postmeta` VALUES("626","109","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:36:\"2018/02/jean_diorama_BcqKrCfli0O.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"jean_diorama_BcqKrCfli0O-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"jean_diorama_BcqKrCfli0O-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"jean_diorama_BcqKrCfli0O-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:36:\"jean_diorama_BcqKrCfli0O-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("627","106","_thumbnail_id","199");
INSERT INTO `yucqn_postmeta` VALUES("630","110","galerie","a:2:{i:0;s:3:\"109\";i:1;s:3:\"107\";}");
INSERT INTO `yucqn_postmeta` VALUES("631","110","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("632","110","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("633","110","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("634","110","completed_on","20171213");
INSERT INTO `yucqn_postmeta` VALUES("635","110","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("636","110","size_of_the_scene","14x10");
INSERT INTO `yucqn_postmeta` VALUES("637","110","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("638","110","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("639","110","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("640","106","galerie","a:3:{i:0;s:3:\"166\";i:1;s:3:\"165\";i:2;s:3:\"164\";}");
INSERT INTO `yucqn_postmeta` VALUES("641","106","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("642","106","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("643","106","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("644","106","completed_on","20171213");
INSERT INTO `yucqn_postmeta` VALUES("645","106","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("646","106","size_of_the_scene","14x10");
INSERT INTO `yucqn_postmeta` VALUES("647","106","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("648","106","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("649","106","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("650","115","marquee","Here are my dioramas, the latest done on top, older on the bottom, you may click on each one to see other pictures, thank you very much -- ");
INSERT INTO `yucqn_postmeta` VALUES("651","115","_marquee","field_5a8c520821ff9");
INSERT INTO `yucqn_postmeta` VALUES("652","115","url_de_la_video","http://youtu.be/BsekcY04xvQ");
INSERT INTO `yucqn_postmeta` VALUES("653","115","_url_de_la_video","field_5a8c522321ffa");
INSERT INTO `yucqn_postmeta` VALUES("654","115","masque_video","79");
INSERT INTO `yucqn_postmeta` VALUES("655","115","_masque_video","field_5a8c523321ffb");
INSERT INTO `yucqn_postmeta` VALUES("656","116","marquee","Here are my dioramas, the latest done on top, older on the bottom, you may click on each one to see other pictures, thank you very much -- ");
INSERT INTO `yucqn_postmeta` VALUES("657","116","_marquee","field_5a8c520821ff9");
INSERT INTO `yucqn_postmeta` VALUES("658","116","url_de_la_video","http://youtu.be/BsekcY04xvQ");
INSERT INTO `yucqn_postmeta` VALUES("659","116","_url_de_la_video","field_5a8c522321ffa");
INSERT INTO `yucqn_postmeta` VALUES("660","116","masque_video","79");
INSERT INTO `yucqn_postmeta` VALUES("661","116","_masque_video","field_5a8c523321ffb");
INSERT INTO `yucqn_postmeta` VALUES("680","125","_menu_item_type","taxonomy");
INSERT INTO `yucqn_postmeta` VALUES("681","125","_menu_item_menu_item_parent","0");
INSERT INTO `yucqn_postmeta` VALUES("682","125","_menu_item_object_id","6");
INSERT INTO `yucqn_postmeta` VALUES("683","125","_menu_item_object","category");
INSERT INTO `yucqn_postmeta` VALUES("684","125","_menu_item_target","");
INSERT INTO `yucqn_postmeta` VALUES("685","125","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `yucqn_postmeta` VALUES("686","125","_menu_item_xfn","");
INSERT INTO `yucqn_postmeta` VALUES("687","125","_menu_item_url","");
INSERT INTO `yucqn_postmeta` VALUES("692","126","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("693","126","field_5a8eb974430f5","a:10:{s:3:\"key\";s:19:\"field_5a8eb974430f5\";s:5:\"label\";s:7:\"gallery\";s:4:\"name\";s:7:\"gallery\";s:4:\"type\";s:7:\"gallery\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"0\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:2:{s:5:\"field\";s:4:\"null\";s:8:\"operator\";s:2:\"==\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:0;}");
INSERT INTO `yucqn_postmeta` VALUES("694","126","rule","a:5:{s:5:\"param\";s:13:\"post_category\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"6\";s:8:\"order_no\";i:0;s:8:\"group_no\";i:0;}");
INSERT INTO `yucqn_postmeta` VALUES("695","126","position","normal");
INSERT INTO `yucqn_postmeta` VALUES("696","126","layout","no_box");
INSERT INTO `yucqn_postmeta` VALUES("697","126","hide_on_screen","a:4:{i:0;s:8:\"comments\";i:1;s:9:\"revisions\";i:2;s:6:\"author\";i:3;s:6:\"format\";}");
INSERT INTO `yucqn_postmeta` VALUES("698","126","_edit_lock","1519302940:1");
INSERT INTO `yucqn_postmeta` VALUES("703","127","marquee","Here are my dioramas, the latest done on top, older on the bottom, you may click on each one to see other pictures, thank you very much -- ");
INSERT INTO `yucqn_postmeta` VALUES("704","127","_marquee","field_5a8c520821ff9");
INSERT INTO `yucqn_postmeta` VALUES("705","127","url_de_la_video","http://youtu.be/BsekcY04xvQ");
INSERT INTO `yucqn_postmeta` VALUES("706","127","_url_de_la_video","field_5a8c522321ffa");
INSERT INTO `yucqn_postmeta` VALUES("707","127","masque_video","79");
INSERT INTO `yucqn_postmeta` VALUES("708","127","_masque_video","field_5a8c523321ffb");
INSERT INTO `yucqn_postmeta` VALUES("709","128","_wp_attached_file","2018/02/fd-1.png");
INSERT INTO `yucqn_postmeta` VALUES("710","128","_wp_attachment_metadata","a:5:{s:5:\"width\";i:600;s:6:\"height\";i:600;s:4:\"file\";s:16:\"2018/02/fd-1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"fd-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"fd-1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:16:\"fd-1-500x500.png\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("711","129","marquee","Here are my dioramas, the latest done on top, older on the bottom, you may click on each one to see other pictures, thank you very much -- ");
INSERT INTO `yucqn_postmeta` VALUES("712","129","_marquee","field_5a8c520821ff9");
INSERT INTO `yucqn_postmeta` VALUES("713","129","url_de_la_video","https://youtu.be/RTGbdr4yc7c");
INSERT INTO `yucqn_postmeta` VALUES("714","129","_url_de_la_video","field_5a8c522321ffa");
INSERT INTO `yucqn_postmeta` VALUES("715","129","masque_video","128");
INSERT INTO `yucqn_postmeta` VALUES("716","129","_masque_video","field_5a8c523321ffb");
INSERT INTO `yucqn_postmeta` VALUES("719","130","galerie","a:2:{i:0;s:3:\"109\";i:1;s:3:\"107\";}");
INSERT INTO `yucqn_postmeta` VALUES("720","130","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("721","130","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("722","130","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("723","130","completed_on","20171213");
INSERT INTO `yucqn_postmeta` VALUES("724","130","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("725","130","size_of_the_scene","14x10");
INSERT INTO `yucqn_postmeta` VALUES("726","130","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("727","130","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("728","130","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("731","131","galerie","a:3:{i:0;s:2:\"31\";i:1;s:2:\"30\";i:2;s:2:\"29\";}");
INSERT INTO `yucqn_postmeta` VALUES("732","131","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("733","131","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("734","131","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("735","131","completed_on","20180211");
INSERT INTO `yucqn_postmeta` VALUES("736","131","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("737","131","size_of_the_scene","13,5x13,5");
INSERT INTO `yucqn_postmeta` VALUES("738","131","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("739","131","size_of_the_frame","20x20");
INSERT INTO `yucqn_postmeta` VALUES("740","131","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("743","132","galerie","a:3:{i:0;s:2:\"31\";i:1;s:2:\"30\";i:2;s:2:\"29\";}");
INSERT INTO `yucqn_postmeta` VALUES("744","132","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("745","132","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("746","132","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("747","132","completed_on","20180211");
INSERT INTO `yucqn_postmeta` VALUES("748","132","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("749","132","size_of_the_scene","13,5x13,5");
INSERT INTO `yucqn_postmeta` VALUES("750","132","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("751","132","size_of_the_frame","20x20");
INSERT INTO `yucqn_postmeta` VALUES("752","132","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("755","134","galerie","a:2:{i:0;s:3:\"109\";i:1;s:3:\"107\";}");
INSERT INTO `yucqn_postmeta` VALUES("756","134","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("757","134","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("758","134","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("759","134","completed_on","20171213");
INSERT INTO `yucqn_postmeta` VALUES("760","134","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("761","134","size_of_the_scene","14x10");
INSERT INTO `yucqn_postmeta` VALUES("762","134","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("763","134","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("764","134","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("767","135","galerie","a:3:{i:0;s:2:\"54\";i:1;s:2:\"53\";i:2;s:2:\"52\";}");
INSERT INTO `yucqn_postmeta` VALUES("768","135","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("769","135","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("770","135","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("771","135","completed_on","20180101");
INSERT INTO `yucqn_postmeta` VALUES("772","135","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("773","135","size_of_the_scene","13x8");
INSERT INTO `yucqn_postmeta` VALUES("774","135","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("775","135","size_of_the_frame","17,5x12,5");
INSERT INTO `yucqn_postmeta` VALUES("776","135","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("779","136","galerie","a:2:{i:0;s:2:\"28\";i:1;s:2:\"27\";}");
INSERT INTO `yucqn_postmeta` VALUES("780","136","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("781","136","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("782","136","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("783","136","completed_on","20171220");
INSERT INTO `yucqn_postmeta` VALUES("784","136","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("785","136","size_of_the_scene","14x10");
INSERT INTO `yucqn_postmeta` VALUES("786","136","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("787","136","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("788","136","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("791","137","galerie","a:2:{i:0;s:2:\"28\";i:1;s:2:\"27\";}");
INSERT INTO `yucqn_postmeta` VALUES("792","137","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("793","137","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("794","137","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("795","137","completed_on","20171220");
INSERT INTO `yucqn_postmeta` VALUES("796","137","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("797","137","size_of_the_scene","14x10");
INSERT INTO `yucqn_postmeta` VALUES("798","137","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("799","137","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("800","137","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("803","139","galerie","a:4:{i:0;s:2:\"22\";i:1;s:2:\"21\";i:2;s:2:\"20\";i:3;s:2:\"19\";}");
INSERT INTO `yucqn_postmeta` VALUES("804","139","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("805","139","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("806","139","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("807","139","completed_on","20180220");
INSERT INTO `yucqn_postmeta` VALUES("808","139","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("809","139","size_of_the_scene","14,5x9,5");
INSERT INTO `yucqn_postmeta` VALUES("810","139","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("811","139","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("812","139","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("818","140","galerie","a:3:{i:0;s:2:\"14\";i:1;s:2:\"13\";i:2;s:2:\"12\";}");
INSERT INTO `yucqn_postmeta` VALUES("819","140","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("820","140","vendu","1");
INSERT INTO `yucqn_postmeta` VALUES("821","140","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("822","140","completed_on","20180218");
INSERT INTO `yucqn_postmeta` VALUES("823","140","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("824","140","size_of_the_scene","15x15");
INSERT INTO `yucqn_postmeta` VALUES("825","140","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("826","140","size_of_the_frame","20x20");
INSERT INTO `yucqn_postmeta` VALUES("827","140","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("828","141","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("829","141","_edit_lock","1520860387:1");
INSERT INTO `yucqn_postmeta` VALUES("838","141","_thumbnail_id","200");
INSERT INTO `yucqn_postmeta` VALUES("841","146","galerie","a:4:{i:0;s:2:\"15\";i:1;s:2:\"17\";i:2;s:2:\"16\";i:3;s:2:\"18\";}");
INSERT INTO `yucqn_postmeta` VALUES("842","146","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("843","146","vendu","1");
INSERT INTO `yucqn_postmeta` VALUES("844","146","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("845","146","completed_on","20171117");
INSERT INTO `yucqn_postmeta` VALUES("846","146","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("847","146","size_of_the_scene","15x15");
INSERT INTO `yucqn_postmeta` VALUES("848","146","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("849","146","size_of_the_frame","20x20");
INSERT INTO `yucqn_postmeta` VALUES("850","146","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("851","141","galerie","a:4:{i:0;s:3:\"168\";i:1;s:3:\"171\";i:2;s:3:\"170\";i:3;s:3:\"169\";}");
INSERT INTO `yucqn_postmeta` VALUES("852","141","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("853","141","vendu","1");
INSERT INTO `yucqn_postmeta` VALUES("854","141","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("855","141","completed_on","20171117");
INSERT INTO `yucqn_postmeta` VALUES("856","141","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("857","141","size_of_the_scene","15x15");
INSERT INTO `yucqn_postmeta` VALUES("858","141","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("859","141","size_of_the_frame","20x20");
INSERT INTO `yucqn_postmeta` VALUES("860","141","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("865","147","galerie","a:3:{i:0;s:2:\"31\";i:1;s:2:\"30\";i:2;s:2:\"29\";}");
INSERT INTO `yucqn_postmeta` VALUES("866","147","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("867","147","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("868","147","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("869","147","completed_on","20170211");
INSERT INTO `yucqn_postmeta` VALUES("870","147","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("871","147","size_of_the_scene","13,5x13,5");
INSERT INTO `yucqn_postmeta` VALUES("872","147","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("873","147","size_of_the_frame","20x20");
INSERT INTO `yucqn_postmeta` VALUES("874","147","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("877","148","galerie","a:3:{i:0;s:2:\"38\";i:1;s:2:\"40\";i:2;s:2:\"41\";}");
INSERT INTO `yucqn_postmeta` VALUES("878","148","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("879","148","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("880","148","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("881","148","completed_on","20180107");
INSERT INTO `yucqn_postmeta` VALUES("882","148","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("883","148","size_of_the_scene","15x10");
INSERT INTO `yucqn_postmeta` VALUES("884","148","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("885","148","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("886","148","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("888","34","_yoast_wpseo_focuskw_text_input","Dioramas");
INSERT INTO `yucqn_postmeta` VALUES("889","34","_yoast_wpseo_focuskw","Dioramas");
INSERT INTO `yucqn_postmeta` VALUES("890","34","_yoast_wpseo_linkdex","42");
INSERT INTO `yucqn_postmeta` VALUES("891","34","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("892","34","_yoast_wpseo_opengraph-title","Distant Shores -1/35 box dioramas");
INSERT INTO `yucqn_postmeta` VALUES("893","34","_yoast_wpseo_opengraph-image","http://dswp.local/wp-content/uploads/2018/02/jean_diorama_BbnAtBHlZXu.jpg");
INSERT INTO `yucqn_postmeta` VALUES("894","34","_yoast_wpseo_title","Nature Dioramas miniatures 1/35 from Jean Diorama - Distant Shores");
INSERT INTO `yucqn_postmeta` VALUES("895","34","_yoast_wpseo_metadesc","This website shows the nature centered dioramas I have been building throughout the last part of 2017 and in 2018. The rules of the game are pretty simple : I bought a series of 3d boxes and I fill them with little scenes that must not be more than 2cm high.");
INSERT INTO `yucqn_postmeta` VALUES("896","9","_yoast_wpseo_focuskw_text_input","diorama");
INSERT INTO `yucqn_postmeta` VALUES("897","9","_yoast_wpseo_focuskw","diorama");
INSERT INTO `yucqn_postmeta` VALUES("898","9","_yoast_wpseo_linkdex","58");
INSERT INTO `yucqn_postmeta` VALUES("899","9","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("900","9","_yoast_wpseo_title","About Nature Dioramas miniatures 1/35 from Jean Diorama");
INSERT INTO `yucqn_postmeta` VALUES("901","9","_yoast_wpseo_metadesc","A short bio and links to other websites");
INSERT INTO `yucqn_postmeta` VALUES("902","149","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("903","149","_edit_lock","1519390746:1");
INSERT INTO `yucqn_postmeta` VALUES("904","150","_wp_attached_file","2018/02/MG_0933.jpg");
INSERT INTO `yucqn_postmeta` VALUES("905","150","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:859;s:4:\"file\";s:19:\"2018/02/MG_0933.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_0933-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_0933-300x258.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:258;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_0933-768x660.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:660;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_0933-500x430.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:430;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("906","150","_wp_attachment_image_alt","Elements of the sea");
INSERT INTO `yucqn_postmeta` VALUES("907","149","_thumbnail_id","150");
INSERT INTO `yucqn_postmeta` VALUES("910","151","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("911","151","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("912","149","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("913","149","_wp_old_date","2018-02-23");
INSERT INTO `yucqn_postmeta` VALUES("914","149","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("915","149","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("916","149","_yoast_wpseo_primary_category","6");
INSERT INTO `yucqn_postmeta` VALUES("917","152","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("918","152","_edit_lock","1519391553:1");
INSERT INTO `yucqn_postmeta` VALUES("919","153","_wp_attached_file","2018/02/MG_1007.jpg");
INSERT INTO `yucqn_postmeta` VALUES("920","153","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1042;s:4:\"file\";s:19:\"2018/02/MG_1007.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1007-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1007-288x300.jpg\";s:5:\"width\";i:288;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1007-768x800.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:800;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"MG_1007-983x1024.jpg\";s:5:\"width\";i:983;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1007-500x521.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:521;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("921","154","_wp_attached_file","2018/02/MG_1049.jpg");
INSERT INTO `yucqn_postmeta` VALUES("922","154","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/02/MG_1049.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1049-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1049-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1049-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1049-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("923","155","_wp_attached_file","2018/02/MG_1012.jpg");
INSERT INTO `yucqn_postmeta` VALUES("924","155","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/02/MG_1012.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1012-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1012-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1012-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1012-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("925","152","_thumbnail_id","155");
INSERT INTO `yucqn_postmeta` VALUES("928","156","gallery","a:2:{i:0;s:3:\"153\";i:1;s:3:\"155\";}");
INSERT INTO `yucqn_postmeta` VALUES("929","156","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("930","152","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("931","152","gallery","a:2:{i:0;s:3:\"153\";i:1;s:3:\"155\";}");
INSERT INTO `yucqn_postmeta` VALUES("932","152","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("933","152","_yoast_wpseo_primary_category","6");
INSERT INTO `yucqn_postmeta` VALUES("934","157","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("935","157","_edit_lock","1519392419:1");
INSERT INTO `yucqn_postmeta` VALUES("936","157","_thumbnail_id","154");
INSERT INTO `yucqn_postmeta` VALUES("939","158","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("940","158","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("941","157","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("942","157","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("943","157","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("944","157","_yoast_wpseo_primary_category","6");
INSERT INTO `yucqn_postmeta` VALUES("947","157","_wp_old_date","2018-02-23");
INSERT INTO `yucqn_postmeta` VALUES("950","159","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("951","159","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("957","152","_wp_old_date","2018-02-23");
INSERT INTO `yucqn_postmeta` VALUES("960","157","_wp_old_date","2018-01-01");
INSERT INTO `yucqn_postmeta` VALUES("961","160","_wp_attached_file","2018/02/MG_1044.jpg");
INSERT INTO `yucqn_postmeta` VALUES("962","160","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:787;s:4:\"file\";s:19:\"2018/02/MG_1044.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1044-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1044-300x236.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:236;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1044-768x604.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:604;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1044-500x394.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:394;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("963","161","_wp_attached_file","2018/02/MG_1042.jpg");
INSERT INTO `yucqn_postmeta` VALUES("964","161","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2183;s:6:\"height\";i:2183;s:4:\"file\";s:19:\"2018/02/MG_1042.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1042-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1042-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1042-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"MG_1042-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1042-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("965","162","_wp_attached_file","2018/02/MG_1036.jpg");
INSERT INTO `yucqn_postmeta` VALUES("966","162","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/02/MG_1036.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1036-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1036-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1036-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1036-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("967","160","_wp_attachment_image_alt","The Grey Sea 1/48 diorama");
INSERT INTO `yucqn_postmeta` VALUES("968","161","_wp_attachment_image_alt","The Grey Sea 1/48 diorama");
INSERT INTO `yucqn_postmeta` VALUES("969","162","_wp_attachment_image_alt","The Grey Sea 1/48 diorama");
INSERT INTO `yucqn_postmeta` VALUES("970","103","_thumbnail_id","160");
INSERT INTO `yucqn_postmeta` VALUES("972","163","galerie","a:3:{i:0;s:3:\"160\";i:1;s:3:\"162\";i:2;s:3:\"161\";}");
INSERT INTO `yucqn_postmeta` VALUES("973","163","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("974","163","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("975","163","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("976","163","completed_on","20171220");
INSERT INTO `yucqn_postmeta` VALUES("977","163","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("978","163","size_of_the_scene","14x10");
INSERT INTO `yucqn_postmeta` VALUES("979","163","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("980","163","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("981","163","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("982","103","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("983","103","_yoast_wpseo_primary_category","");
INSERT INTO `yucqn_postmeta` VALUES("984","164","_wp_attached_file","2018/02/MG_1035.jpg");
INSERT INTO `yucqn_postmeta` VALUES("985","164","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/02/MG_1035.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1035-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1035-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1035-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1035-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("986","165","_wp_attached_file","2018/02/MG_1040.jpg");
INSERT INTO `yucqn_postmeta` VALUES("987","165","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/02/MG_1040.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1040-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1040-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1040-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1040-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("988","166","_wp_attached_file","2018/02/MG_1034.jpg");
INSERT INTO `yucqn_postmeta` VALUES("989","166","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/02/MG_1034.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1034-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1034-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1034-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1034-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("990","166","_wp_attachment_image_alt","Ripples 1/35 diorama");
INSERT INTO `yucqn_postmeta` VALUES("992","167","galerie","a:3:{i:0;s:3:\"166\";i:1;s:3:\"165\";i:2;s:3:\"164\";}");
INSERT INTO `yucqn_postmeta` VALUES("993","167","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("994","167","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("995","167","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("996","167","completed_on","20171213");
INSERT INTO `yucqn_postmeta` VALUES("997","167","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("998","167","size_of_the_scene","14x10");
INSERT INTO `yucqn_postmeta` VALUES("999","167","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1000","167","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("1001","167","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1002","106","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1003","106","_yoast_wpseo_primary_category","");
INSERT INTO `yucqn_postmeta` VALUES("1004","165","_wp_attachment_image_alt","Ripples 1/35 diorama");
INSERT INTO `yucqn_postmeta` VALUES("1005","164","_wp_attachment_image_alt","Ripples 1/35 diorama");
INSERT INTO `yucqn_postmeta` VALUES("1006","168","_wp_attached_file","2018/02/MG_0900.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1007","168","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:987;s:4:\"file\";s:19:\"2018/02/MG_0900.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_0900-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_0900-300x296.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:296;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_0900-768x758.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:758;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_0900-500x494.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:494;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1008","169","_wp_attached_file","2018/02/MG_0905.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1009","169","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/02/MG_0905.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_0905-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_0905-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_0905-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_0905-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1010","170","_wp_attached_file","2018/02/MG_0909.png");
INSERT INTO `yucqn_postmeta` VALUES("1011","170","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/02/MG_0909.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_0909-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_0909-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_0909-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_0909-500x500.png\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1012","171","_wp_attached_file","2018/02/MG_0911.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1013","171","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/02/MG_0911.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_0911-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_0911-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_0911-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_0911-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1014","171","_wp_attachment_image_alt","Just the sea #2 1/35 diorama");
INSERT INTO `yucqn_postmeta` VALUES("1015","170","_wp_attachment_image_alt","Just the sea #2 1/35 diorama");
INSERT INTO `yucqn_postmeta` VALUES("1016","169","_wp_attachment_image_alt","Just the sea #2 1/35 diorama");
INSERT INTO `yucqn_postmeta` VALUES("1017","168","_wp_attachment_image_alt","Just the sea #2 1/35 diorama");
INSERT INTO `yucqn_postmeta` VALUES("1019","172","galerie","a:4:{i:0;s:3:\"168\";i:1;s:3:\"171\";i:2;s:3:\"170\";i:3;s:3:\"169\";}");
INSERT INTO `yucqn_postmeta` VALUES("1020","172","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1021","172","vendu","1");
INSERT INTO `yucqn_postmeta` VALUES("1022","172","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1023","172","completed_on","20171117");
INSERT INTO `yucqn_postmeta` VALUES("1024","172","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1025","172","size_of_the_scene","15x15");
INSERT INTO `yucqn_postmeta` VALUES("1026","172","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1027","172","size_of_the_frame","20x20");
INSERT INTO `yucqn_postmeta` VALUES("1028","172","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1029","141","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1030","141","_yoast_wpseo_primary_category","");
INSERT INTO `yucqn_postmeta` VALUES("1032","173","galerie","");
INSERT INTO `yucqn_postmeta` VALUES("1033","173","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1034","173","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1035","173","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1036","173","completed_on","20180107");
INSERT INTO `yucqn_postmeta` VALUES("1037","173","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1038","173","size_of_the_scene","15x10");
INSERT INTO `yucqn_postmeta` VALUES("1039","173","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1040","173","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("1041","173","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1042","97","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1043","97","_yoast_wpseo_primary_category","");
INSERT INTO `yucqn_postmeta` VALUES("1044","174","_wp_attached_file","2018/02/MG_1240.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1045","174","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/02/MG_1240.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1240-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1240-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1240-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1240-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1046","175","_wp_attached_file","2018/02/MG_1237.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1047","175","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/02/MG_1237.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1237-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1237-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1237-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1237-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1048","176","_wp_attached_file","2018/02/MG_1233.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1049","176","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1045;s:4:\"file\";s:19:\"2018/02/MG_1233.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1233-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1233-287x300.jpg\";s:5:\"width\";i:287;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1233-768x803.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:803;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"MG_1233-980x1024.jpg\";s:5:\"width\";i:980;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1233-500x523.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:523;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1050","177","_wp_attached_file","2018/02/MG_1234.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1051","177","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/02/MG_1234.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1234-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1234-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1234-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1234-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1052","177","_wp_attachment_image_alt","Top of the Lake 1/35 Diorama");
INSERT INTO `yucqn_postmeta` VALUES("1053","176","_wp_attachment_image_alt","Top of the Lake 1/35 Diorama");
INSERT INTO `yucqn_postmeta` VALUES("1054","175","_wp_attachment_image_alt","Top of the Lake 1/35 Diorama");
INSERT INTO `yucqn_postmeta` VALUES("1055","174","_wp_attachment_image_alt","Top of the Lake 1/35 Diorama");
INSERT INTO `yucqn_postmeta` VALUES("1056","97","_thumbnail_id","196");
INSERT INTO `yucqn_postmeta` VALUES("1058","178","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1059","178","_edit_lock","1519399983:1");
INSERT INTO `yucqn_postmeta` VALUES("1061","180","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1062","180","_edit_lock","1519400232:1");
INSERT INTO `yucqn_postmeta` VALUES("1063","181","_wp_attached_file","2018/02/MG_1238.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1064","181","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:897;s:4:\"file\";s:19:\"2018/02/MG_1238.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1238-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1238-300x269.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:269;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1238-768x689.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:689;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1238-500x449.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:449;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1065","182","_wp_attached_file","2018/02/MG_1228.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1066","182","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:918;s:4:\"file\";s:19:\"2018/02/MG_1228.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1228-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1228-300x275.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:275;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1228-768x705.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:705;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1228-500x459.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:459;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1067","183","_wp_attached_file","2018/02/MG_1244.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1068","183","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:843;s:4:\"file\";s:19:\"2018/02/MG_1244.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1244-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1244-300x253.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:253;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1244-768x647.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:647;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1244-500x422.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:422;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1069","183","_wp_attachment_image_alt","Winter Marsh 1/35 diorama");
INSERT INTO `yucqn_postmeta` VALUES("1070","182","_wp_attachment_image_alt","Winter Marsh 1/35 diorama");
INSERT INTO `yucqn_postmeta` VALUES("1071","181","_wp_attachment_image_alt","Winter Marsh 1/35 diorama");
INSERT INTO `yucqn_postmeta` VALUES("1073","48","_yoast_wpseo_primary_category","");
INSERT INTO `yucqn_postmeta` VALUES("1074","48","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1075","48","_thumbnail_id","197");
INSERT INTO `yucqn_postmeta` VALUES("1077","184","_wp_attached_file","2018/02/MG_1445.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1078","184","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:926;s:4:\"file\";s:19:\"2018/02/MG_1445.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1445-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1445-300x278.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:278;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1445-768x711.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:711;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1445-500x463.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:463;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1079","185","_wp_attached_file","2018/02/MG_1436.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1080","185","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:892;s:4:\"file\";s:19:\"2018/02/MG_1436.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1436-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1436-300x268.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:268;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1436-768x685.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:685;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1436-500x446.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:446;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1081","186","_wp_attached_file","2018/02/MG_1439.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1082","186","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1064;s:4:\"file\";s:19:\"2018/02/MG_1439.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1439-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1439-282x300.jpg\";s:5:\"width\";i:282;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1439-768x817.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:817;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"MG_1439-962x1024.jpg\";s:5:\"width\";i:962;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1439-500x532.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:532;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1083","187","_wp_attached_file","2018/02/MG_1445-1.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1084","187","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:926;s:4:\"file\";s:21:\"2018/02/MG_1445-1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"MG_1445-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"MG_1445-1-300x278.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:278;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"MG_1445-1-768x711.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:711;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:21:\"MG_1445-1-500x463.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:463;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1085","188","_wp_attached_file","2018/02/MG_1436-1.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1086","188","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:892;s:4:\"file\";s:21:\"2018/02/MG_1436-1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"MG_1436-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"MG_1436-1-300x268.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:268;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"MG_1436-1-768x685.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:685;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:21:\"MG_1436-1-500x446.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:446;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1087","189","_wp_attached_file","2018/02/MG_1439-1.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1088","189","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1064;s:4:\"file\";s:21:\"2018/02/MG_1439-1.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"MG_1439-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"MG_1439-1-282x300.jpg\";s:5:\"width\";i:282;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"MG_1439-1-768x817.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:817;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"MG_1439-1-962x1024.jpg\";s:5:\"width\";i:962;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:21:\"MG_1439-1-500x532.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:532;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1089","189","_wp_attachment_image_alt","The Icy River 1/35 diorama");
INSERT INTO `yucqn_postmeta` VALUES("1090","188","_wp_attachment_image_alt","The Icy River 1/35 diorama");
INSERT INTO `yucqn_postmeta` VALUES("1091","187","_wp_attachment_image_alt","The Icy River 1/35 diorama");
INSERT INTO `yucqn_postmeta` VALUES("1092","101","_thumbnail_id","195");
INSERT INTO `yucqn_postmeta` VALUES("1094","190","galerie","a:3:{i:0;s:3:\"186\";i:1;s:3:\"185\";i:2;s:3:\"184\";}");
INSERT INTO `yucqn_postmeta` VALUES("1095","190","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1096","190","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1097","190","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1098","190","completed_on","20180220");
INSERT INTO `yucqn_postmeta` VALUES("1099","190","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1100","190","size_of_the_scene","14,5x9,5");
INSERT INTO `yucqn_postmeta` VALUES("1101","190","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1102","190","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("1103","190","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1104","101","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1105","101","_yoast_wpseo_primary_category","");
INSERT INTO `yucqn_postmeta` VALUES("1106","191","_wp_attached_file","2018/02/MG_14392.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1107","191","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1044;s:6:\"height\";i:1072;s:4:\"file\";s:20:\"2018/02/MG_14392.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"MG_14392-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"MG_14392-292x300.jpg\";s:5:\"width\";i:292;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"MG_14392-768x789.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:789;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"MG_14392-997x1024.jpg\";s:5:\"width\";i:997;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:20:\"MG_14392-500x513.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:513;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1110","192","galerie","a:3:{i:0;s:3:\"160\";i:1;s:3:\"162\";i:2;s:3:\"161\";}");
INSERT INTO `yucqn_postmeta` VALUES("1111","192","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1112","192","vendu","1");
INSERT INTO `yucqn_postmeta` VALUES("1113","192","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1114","192","completed_on","20171220");
INSERT INTO `yucqn_postmeta` VALUES("1115","192","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1116","192","size_of_the_scene","14x10");
INSERT INTO `yucqn_postmeta` VALUES("1117","192","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1118","192","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("1119","192","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1120","195","_wp_attached_file","2018/02/MG_1436.png");
INSERT INTO `yucqn_postmeta` VALUES("1121","195","_wp_attachment_metadata","a:5:{s:5:\"width\";i:850;s:6:\"height\";i:850;s:4:\"file\";s:19:\"2018/02/MG_1436.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1436-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1436-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1436-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1436-500x500.png\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1122","196","_wp_attached_file","2018/02/MG_1233-1.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1123","196","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1113;s:6:\"height\";i:1114;s:4:\"file\";s:21:\"2018/02/MG_1233-1.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"MG_1233-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"MG_1233-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"MG_1233-1-768x769.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:769;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"MG_1233-1-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:21:\"MG_1233-1-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1124","197","_wp_attached_file","2018/02/MG_1244-1.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1125","197","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1266;s:6:\"height\";i:1266;s:4:\"file\";s:21:\"2018/02/MG_1244-1.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"MG_1244-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"MG_1244-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"MG_1244-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"MG_1244-1-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:21:\"MG_1244-1-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1126","198","_wp_attached_file","2018/02/MG_0994.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1127","198","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/02/MG_0994.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_0994-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_0994-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_0994-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_0994-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1128","199","_wp_attached_file","2018/02/MG_1034-1.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1129","199","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:21:\"2018/02/MG_1034-1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"MG_1034-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"MG_1034-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"MG_1034-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:21:\"MG_1034-1-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1130","199","_wp_attachment_image_alt","Ripples diorama 1/35");
INSERT INTO `yucqn_postmeta` VALUES("1132","200","_wp_attached_file","2018/02/MG_0909.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1133","200","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/02/MG_0909.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_0909-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_0909-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_0909-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_0909-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1134","200","_wp_attachment_image_alt","Juist the Sea diorama 1/35");
INSERT INTO `yucqn_postmeta` VALUES("1136","195","_wp_attachment_image_alt","Icy river diorama 1/35");
INSERT INTO `yucqn_postmeta` VALUES("1138","196","_wp_attachment_image_alt","Top of the lake diorama 1/35");
INSERT INTO `yucqn_postmeta` VALUES("1140","198","_wp_attachment_image_alt","White Shore diorama 1/35");
INSERT INTO `yucqn_postmeta` VALUES("1142","66","_yoast_wpseo_primary_category","");
INSERT INTO `yucqn_postmeta` VALUES("1143","66","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1144","201","_wp_attached_file","2018/02/MG_1449.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1145","201","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/02/MG_1449.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1449-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1449-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_1449-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1449-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1146","201","_wp_attachment_image_alt","Saint Laurent 1/35 diorama");
INSERT INTO `yucqn_postmeta` VALUES("1148","93","_yoast_wpseo_primary_category","");
INSERT INTO `yucqn_postmeta` VALUES("1149","93","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1150","202","_wp_attached_file","2018/02/MG_1017.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1151","202","_wp_attachment_metadata","a:5:{s:5:\"width\";i:730;s:6:\"height\";i:730;s:4:\"file\";s:19:\"2018/02/MG_1017.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_1017-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_1017-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_1017-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1153","72","_yoast_wpseo_primary_category","");
INSERT INTO `yucqn_postmeta` VALUES("1154","72","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1155","203","_wp_attached_file","2018/02/MG_09282.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1156","203","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1107;s:6:\"height\";i:1107;s:4:\"file\";s:20:\"2018/02/MG_09282.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"MG_09282-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"MG_09282-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"MG_09282-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"MG_09282-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:20:\"MG_09282-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1157","203","_wp_attachment_image_alt","Aivazovski 1/35 diorama");
INSERT INTO `yucqn_postmeta` VALUES("1159","204","galerie","a:3:{i:0;s:2:\"31\";i:1;s:2:\"30\";i:2;s:2:\"29\";}");
INSERT INTO `yucqn_postmeta` VALUES("1160","204","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1161","204","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1162","204","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1163","204","completed_on","20170211");
INSERT INTO `yucqn_postmeta` VALUES("1164","204","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1165","204","size_of_the_scene","13,5x13,5");
INSERT INTO `yucqn_postmeta` VALUES("1166","204","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1167","204","size_of_the_frame","20x20");
INSERT INTO `yucqn_postmeta` VALUES("1168","204","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1169","95","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1170","95","_yoast_wpseo_primary_category","");
INSERT INTO `yucqn_postmeta` VALUES("1171","197","_wp_attachment_image_alt","Winter Marsh diorama 1/35");
INSERT INTO `yucqn_postmeta` VALUES("1173","66","_thumbnail_id","198");
INSERT INTO `yucqn_postmeta` VALUES("1175","205","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1176","205","_edit_lock","1519466391:1");
INSERT INTO `yucqn_postmeta` VALUES("1178","206","link","http://atomscales.com/");
INSERT INTO `yucqn_postmeta` VALUES("1179","206","_link","field_5a8c42d32b5a2");
INSERT INTO `yucqn_postmeta` VALUES("1180","205","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1181","205","link","http://atomscales.com/");
INSERT INTO `yucqn_postmeta` VALUES("1182","205","_link","field_5a8c42d32b5a2");
INSERT INTO `yucqn_postmeta` VALUES("1183","205","_yoast_wpseo_primary_category","3");
INSERT INTO `yucqn_postmeta` VALUES("1184","207","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1185","207","_edit_lock","1540634251:1");
INSERT INTO `yucqn_postmeta` VALUES("1187","208","link","http://ricklawler-propaganda.com/propaganda/");
INSERT INTO `yucqn_postmeta` VALUES("1188","208","_link","field_5a8c42d32b5a2");
INSERT INTO `yucqn_postmeta` VALUES("1189","207","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1190","207","link","http://ricklawler-propaganda.com/propaganda/");
INSERT INTO `yucqn_postmeta` VALUES("1191","207","_link","field_5a8c42d32b5a2");
INSERT INTO `yucqn_postmeta` VALUES("1192","207","_yoast_wpseo_primary_category","3");
INSERT INTO `yucqn_postmeta` VALUES("1193","211","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1194","211","_edit_lock","1520357258:1");
INSERT INTO `yucqn_postmeta` VALUES("1195","212","_wp_attached_file","2018/03/IMG_20180301_211946.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1196","212","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:31:\"2018/03/IMG_20180301_211946.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG_20180301_211946-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG_20180301_211946-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG_20180301_211946-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:31:\"IMG_20180301_211946-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1197","213","_wp_attached_file","2018/03/IMG_20180225_133902_HDR.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1198","213","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:35:\"2018/03/IMG_20180225_133902_HDR.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"IMG_20180225_133902_HDR-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"IMG_20180225_133902_HDR-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"IMG_20180225_133902_HDR-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:35:\"IMG_20180225_133902_HDR-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1199","211","_thumbnail_id","212");
INSERT INTO `yucqn_postmeta` VALUES("1201","214","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1202","214","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1203","211","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1204","211","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1205","211","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1206","211","_yoast_wpseo_primary_category","6");
INSERT INTO `yucqn_postmeta` VALUES("1207","215","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1208","215","_edit_lock","1520357068:1");
INSERT INTO `yucqn_postmeta` VALUES("1209","215","_thumbnail_id","213");
INSERT INTO `yucqn_postmeta` VALUES("1211","215","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1212","215","_yoast_wpseo_primary_category","6");
INSERT INTO `yucqn_postmeta` VALUES("1214","211","_wp_old_date","2018-03-06");
INSERT INTO `yucqn_postmeta` VALUES("1215","217","_wp_attached_file","2018/03/IMG_20180307_211710.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1216","217","_wp_attachment_metadata","a:5:{s:5:\"width\";i:4160;s:6:\"height\";i:3120;s:4:\"file\";s:31:\"2018/03/IMG_20180307_211710.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG_20180307_211710-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG_20180307_211710-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG_20180307_211710-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG_20180307_211710-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:31:\"IMG_20180307_211710-500x375.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:12:\"Redmi Note 4\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1520457430\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"3.57\";s:3:\"iso\";s:3:\"640\";s:13:\"shutter_speed\";s:4:\"0.04\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1217","218","_wp_attached_file","2018/03/IMG_20180307_221148.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1218","218","_wp_attachment_metadata","a:5:{s:5:\"width\";i:4160;s:6:\"height\";i:3120;s:4:\"file\";s:31:\"2018/03/IMG_20180307_221148.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG_20180307_221148-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG_20180307_221148-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG_20180307_221148-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG_20180307_221148-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:31:\"IMG_20180307_221148-500x375.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:12:\"Redmi Note 4\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1520460708\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"3.57\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:4:\"0.04\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1219","219","_wp_attached_file","2018/03/IMG_20180307_222416.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1220","219","_wp_attachment_metadata","a:5:{s:5:\"width\";i:4160;s:6:\"height\";i:3120;s:4:\"file\";s:31:\"2018/03/IMG_20180307_222416.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG_20180307_222416-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG_20180307_222416-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG_20180307_222416-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG_20180307_222416-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:31:\"IMG_20180307_222416-500x375.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:12:\"Redmi Note 4\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1520461456\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"3.57\";s:3:\"iso\";s:3:\"320\";s:13:\"shutter_speed\";s:16:\"0.03030303030303\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1221","220","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1222","220","_edit_lock","1520521933:1");
INSERT INTO `yucqn_postmeta` VALUES("1223","220","_thumbnail_id","218");
INSERT INTO `yucqn_postmeta` VALUES("1225","221","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1226","221","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1227","220","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1228","220","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1229","220","_yoast_wpseo_primary_category","6");
INSERT INTO `yucqn_postmeta` VALUES("1231","222","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1232","222","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1233","220","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1235","223","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1236","223","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1237","225","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1238","225","_edit_lock","1520524207:1");
INSERT INTO `yucqn_postmeta` VALUES("1239","225","_thumbnail_id","219");
INSERT INTO `yucqn_postmeta` VALUES("1241","226","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1242","226","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1243","225","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1244","225","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1245","225","_yoast_wpseo_primary_category","6");
INSERT INTO `yucqn_postmeta` VALUES("1246","227","_menu_item_type","taxonomy");
INSERT INTO `yucqn_postmeta` VALUES("1247","227","_menu_item_menu_item_parent","0");
INSERT INTO `yucqn_postmeta` VALUES("1248","227","_menu_item_object_id","2");
INSERT INTO `yucqn_postmeta` VALUES("1249","227","_menu_item_object","category");
INSERT INTO `yucqn_postmeta` VALUES("1250","227","_menu_item_target","");
INSERT INTO `yucqn_postmeta` VALUES("1251","227","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `yucqn_postmeta` VALUES("1252","227","_menu_item_xfn","");
INSERT INTO `yucqn_postmeta` VALUES("1253","227","_menu_item_url","");
INSERT INTO `yucqn_postmeta` VALUES("1255","11","field_5aa2bbaaef6f0","a:12:{s:3:\"key\";s:19:\"field_5aa2bbaaef6f0\";s:5:\"label\";s:8:\"Location\";s:4:\"name\";s:6:\"gmapes\";s:4:\"type\";s:10:\"google_map\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"0\";s:10:\"center_lat\";s:0:\"\";s:10:\"center_lng\";s:0:\"\";s:4:\"zoom\";s:0:\"\";s:6:\"height\";s:0:\"\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5a8c47958283a\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"1\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:5;}");
INSERT INTO `yucqn_postmeta` VALUES("1256","11","rule","a:5:{s:5:\"param\";s:13:\"post_category\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"2\";s:8:\"order_no\";i:0;s:8:\"group_no\";i:0;}");
INSERT INTO `yucqn_postmeta` VALUES("1258","229","galerie","a:4:{i:0;s:3:\"168\";i:1;s:3:\"171\";i:2;s:3:\"170\";i:3;s:3:\"169\";}");
INSERT INTO `yucqn_postmeta` VALUES("1259","229","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1260","229","vendu","1");
INSERT INTO `yucqn_postmeta` VALUES("1261","229","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1262","229","completed_on","20171117");
INSERT INTO `yucqn_postmeta` VALUES("1263","229","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1264","229","size_of_the_scene","15x15");
INSERT INTO `yucqn_postmeta` VALUES("1265","229","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1266","229","size_of_the_frame","20x20");
INSERT INTO `yucqn_postmeta` VALUES("1267","229","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1268","229","gmapes","a:3:{s:7:\"address\";s:50:\"Pindo Sur, 140, 15296 O Pindo, La Coruña, Espagne\";s:3:\"lat\";s:17:\"42.88639612824101\";s:3:\"lng\";s:9:\"-9.140625\";}");
INSERT INTO `yucqn_postmeta` VALUES("1269","229","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1270","141","gmapes","a:3:{s:7:\"address\";s:50:\"Pindo Sur, 140, 15296 O Pindo, La Coruña, Espagne\";s:3:\"lat\";s:17:\"42.88639612824101\";s:3:\"lng\";s:9:\"-9.140625\";}");
INSERT INTO `yucqn_postmeta` VALUES("1271","141","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1273","230","galerie","a:3:{i:0;s:3:\"166\";i:1;s:3:\"165\";i:2;s:3:\"164\";}");
INSERT INTO `yucqn_postmeta` VALUES("1274","230","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1275","230","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1276","230","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1277","230","completed_on","20171213");
INSERT INTO `yucqn_postmeta` VALUES("1278","230","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1279","230","size_of_the_scene","14x10");
INSERT INTO `yucqn_postmeta` VALUES("1280","230","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1281","230","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("1282","230","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1283","230","gmapes","a:3:{s:7:\"address\";s:45:\"Unnamed Road, 85550 La Barre-de-Monts, France\";s:3:\"lat\";s:18:\"46.877640448714246\";s:3:\"lng\";s:18:\"-2.152891159057617\";}");
INSERT INTO `yucqn_postmeta` VALUES("1284","230","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1285","106","gmapes","a:3:{s:7:\"address\";s:45:\"Unnamed Road, 85550 La Barre-de-Monts, France\";s:3:\"lat\";s:18:\"46.877640448714246\";s:3:\"lng\";s:18:\"-2.152891159057617\";}");
INSERT INTO `yucqn_postmeta` VALUES("1286","106","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1288","231","galerie","a:3:{i:0;s:3:\"160\";i:1;s:3:\"162\";i:2;s:3:\"161\";}");
INSERT INTO `yucqn_postmeta` VALUES("1289","231","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1290","231","vendu","1");
INSERT INTO `yucqn_postmeta` VALUES("1291","231","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1292","231","completed_on","20171220");
INSERT INTO `yucqn_postmeta` VALUES("1293","231","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1294","231","size_of_the_scene","14x10");
INSERT INTO `yucqn_postmeta` VALUES("1295","231","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1296","231","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("1297","231","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1298","231","gmapes","a:3:{s:7:\"address\";s:11:\"Royaume-Uni\";s:3:\"lat\";s:17:\"50.58694239388468\";s:3:\"lng\";s:18:\"0.5416131492187333\";}");
INSERT INTO `yucqn_postmeta` VALUES("1299","231","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1300","103","gmapes","a:3:{s:7:\"address\";s:11:\"Royaume-Uni\";s:3:\"lat\";s:17:\"50.58694239388468\";s:3:\"lng\";s:18:\"0.5416131492187333\";}");
INSERT INTO `yucqn_postmeta` VALUES("1301","103","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1303","232","galerie","a:4:{i:0;s:3:\"186\";i:1;s:3:\"185\";i:2;s:3:\"184\";i:3;s:3:\"191\";}");
INSERT INTO `yucqn_postmeta` VALUES("1304","232","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1305","232","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1306","232","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1307","232","completed_on","20180220");
INSERT INTO `yucqn_postmeta` VALUES("1308","232","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1309","232","size_of_the_scene","14,5x9,5");
INSERT INTO `yucqn_postmeta` VALUES("1310","232","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1311","232","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("1312","232","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1313","232","gmapes","a:3:{s:7:\"address\";s:36:\"B4, 37444 St. Andreasberg, Allemagne\";s:3:\"lat\";s:17:\"51.76695637978056\";s:3:\"lng\";s:18:\"10.552024841308594\";}");
INSERT INTO `yucqn_postmeta` VALUES("1314","232","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1315","101","gmapes","a:3:{s:7:\"address\";s:36:\"B4, 37444 St. Andreasberg, Allemagne\";s:3:\"lat\";s:17:\"51.76695637978056\";s:3:\"lng\";s:18:\"10.552024841308594\";}");
INSERT INTO `yucqn_postmeta` VALUES("1316","101","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1318","233","galerie","a:3:{i:0;s:2:\"54\";i:1;s:2:\"53\";i:2;s:2:\"52\";}");
INSERT INTO `yucqn_postmeta` VALUES("1319","233","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1320","233","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1321","233","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1322","233","completed_on","20180101");
INSERT INTO `yucqn_postmeta` VALUES("1323","233","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1324","233","size_of_the_scene","13x8");
INSERT INTO `yucqn_postmeta` VALUES("1325","233","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1326","233","size_of_the_frame","17,5x12,5");
INSERT INTO `yucqn_postmeta` VALUES("1327","233","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1328","233","gmapes","a:3:{s:7:\"address\";s:33:\"D53, 74540 Héry-sur-Alby, France\";s:3:\"lat\";s:17:\"45.77572124633328\";s:3:\"lng\";s:17:\"6.005671624999991\";}");
INSERT INTO `yucqn_postmeta` VALUES("1329","233","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1330","99","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1331","99","gmapes","a:3:{s:7:\"address\";s:33:\"D53, 74540 Héry-sur-Alby, France\";s:3:\"lat\";s:17:\"45.77572124633328\";s:3:\"lng\";s:17:\"6.005671624999991\";}");
INSERT INTO `yucqn_postmeta` VALUES("1332","99","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1333","99","_yoast_wpseo_primary_category","");
INSERT INTO `yucqn_postmeta` VALUES("1335","234","galerie","a:4:{i:0;s:3:\"177\";i:1;s:3:\"176\";i:2;s:3:\"175\";i:3;s:3:\"174\";}");
INSERT INTO `yucqn_postmeta` VALUES("1336","234","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1337","234","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1338","234","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1339","234","completed_on","20180107");
INSERT INTO `yucqn_postmeta` VALUES("1340","234","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1341","234","size_of_the_scene","15x10");
INSERT INTO `yucqn_postmeta` VALUES("1342","234","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1343","234","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("1344","234","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1345","234","gmapes","a:3:{s:7:\"address\";s:58:\"Unnamed Road, Gayevka, Rostovskaya oblast\', Russie, 346848\";s:3:\"lat\";s:17:\"47.24225712804018\";s:3:\"lng\";s:18:\"38.668301501269525\";}");
INSERT INTO `yucqn_postmeta` VALUES("1346","234","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1347","97","gmapes","a:3:{s:7:\"address\";s:58:\"Unnamed Road, Gayevka, Rostovskaya oblast\', Russie, 346848\";s:3:\"lat\";s:17:\"47.24225712804018\";s:3:\"lng\";s:18:\"38.668301501269525\";}");
INSERT INTO `yucqn_postmeta` VALUES("1348","97","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1350","235","galerie","a:3:{i:0;s:2:\"31\";i:1;s:2:\"30\";i:2;s:2:\"29\";}");
INSERT INTO `yucqn_postmeta` VALUES("1351","235","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1352","235","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1353","235","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1354","235","completed_on","20170211");
INSERT INTO `yucqn_postmeta` VALUES("1355","235","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1356","235","size_of_the_scene","13,5x13,5");
INSERT INTO `yucqn_postmeta` VALUES("1357","235","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1358","235","size_of_the_frame","20x20");
INSERT INTO `yucqn_postmeta` VALUES("1359","235","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1360","235","gmapes","a:3:{s:7:\"address\";s:30:\"Т1606, Odessa Oblast, Ukraine\";s:3:\"lat\";s:16:\"45.8007725427009\";s:3:\"lng\";s:18:\"31.252713186523465\";}");
INSERT INTO `yucqn_postmeta` VALUES("1361","235","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1362","95","gmapes","a:3:{s:7:\"address\";s:30:\"Т1606, Odessa Oblast, Ukraine\";s:3:\"lat\";s:16:\"45.8007725427009\";s:3:\"lng\";s:18:\"31.252713186523465\";}");
INSERT INTO `yucqn_postmeta` VALUES("1363","95","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1365","236","galerie","a:4:{i:0;s:2:\"26\";i:1;s:2:\"25\";i:2;s:2:\"24\";i:3;s:2:\"23\";}");
INSERT INTO `yucqn_postmeta` VALUES("1366","236","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1367","236","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1368","236","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1369","236","completed_on","20180211");
INSERT INTO `yucqn_postmeta` VALUES("1370","236","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1371","236","size_of_the_scene","16,5x16,5");
INSERT INTO `yucqn_postmeta` VALUES("1372","236","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1373","236","size_of_the_frame","22,5x22,5");
INSERT INTO `yucqn_postmeta` VALUES("1374","236","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1375","236","gmapes","a:3:{s:7:\"address\";s:45:\"105 56e Av, Saint-Zotique, QC J0P 1Z0, Canada\";s:3:\"lat\";s:17:\"45.22621776390272\";s:3:\"lng\";s:18:\"-74.24840834374999\";}");
INSERT INTO `yucqn_postmeta` VALUES("1376","236","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1377","93","gmapes","a:3:{s:7:\"address\";s:45:\"105 56e Av, Saint-Zotique, QC J0P 1Z0, Canada\";s:3:\"lat\";s:17:\"45.22621776390272\";s:3:\"lng\";s:18:\"-74.24840834374999\";}");
INSERT INTO `yucqn_postmeta` VALUES("1378","93","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1380","237","galerie","a:5:{i:0;s:2:\"73\";i:1;s:2:\"74\";i:2;s:2:\"75\";i:3;s:2:\"76\";i:4;s:2:\"77\";}");
INSERT INTO `yucqn_postmeta` VALUES("1381","237","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1382","237","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1383","237","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1384","237","completed_on","20171207");
INSERT INTO `yucqn_postmeta` VALUES("1385","237","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1386","237","size_of_the_scene","13,5x8,5");
INSERT INTO `yucqn_postmeta` VALUES("1387","237","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1388","237","size_of_the_frame","17,5x12,5");
INSERT INTO `yucqn_postmeta` VALUES("1389","237","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1390","237","gmapes","a:3:{s:7:\"address\";s:42:\"Unnamed Road, 85340 Olonne-sur-Mer, France\";s:3:\"lat\";s:18:\"46.550527773376736\";s:3:\"lng\";s:19:\"-1.8334640891113168\";}");
INSERT INTO `yucqn_postmeta` VALUES("1391","237","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1392","72","gmapes","a:3:{s:7:\"address\";s:42:\"Unnamed Road, 85340 Olonne-sur-Mer, France\";s:3:\"lat\";s:18:\"46.550527773376736\";s:3:\"lng\";s:19:\"-1.8334640891113168\";}");
INSERT INTO `yucqn_postmeta` VALUES("1393","72","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1395","238","galerie","a:4:{i:0;s:2:\"67\";i:1;s:2:\"68\";i:2;s:2:\"69\";i:3;s:2:\"70\";}");
INSERT INTO `yucqn_postmeta` VALUES("1396","238","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1397","238","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1398","238","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1399","238","completed_on","20171128");
INSERT INTO `yucqn_postmeta` VALUES("1400","238","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1401","238","size_of_the_scene","16x16");
INSERT INTO `yucqn_postmeta` VALUES("1402","238","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1403","238","size_of_the_frame","22,5x22,5");
INSERT INTO `yucqn_postmeta` VALUES("1404","238","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1405","238","gmapes","a:3:{s:7:\"address\";s:46:\"6 Balletts Ln, Port Rexton, NL A0C 2H0, Canada\";s:3:\"lat\";s:17:\"48.36615921937985\";s:3:\"lng\";s:18:\"-53.31180056562499\";}");
INSERT INTO `yucqn_postmeta` VALUES("1406","238","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1407","66","gmapes","a:3:{s:7:\"address\";s:46:\"6 Balletts Ln, Port Rexton, NL A0C 2H0, Canada\";s:3:\"lat\";s:17:\"48.36615921937985\";s:3:\"lng\";s:18:\"-53.31180056562499\";}");
INSERT INTO `yucqn_postmeta` VALUES("1408","66","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1410","239","galerie","a:3:{i:0;s:3:\"183\";i:1;s:3:\"182\";i:2;s:3:\"181\";}");
INSERT INTO `yucqn_postmeta` VALUES("1411","239","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1412","239","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1413","239","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1414","239","completed_on","20180109");
INSERT INTO `yucqn_postmeta` VALUES("1415","239","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1416","239","size_of_the_scene","14x9");
INSERT INTO `yucqn_postmeta` VALUES("1417","239","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1418","239","size_of_the_frame","17,5x12,5");
INSERT INTO `yucqn_postmeta` VALUES("1419","239","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1420","239","gmapes","a:3:{s:7:\"address\";s:46:\"Boekhorsterweg, 2211 Noordwijkerhout, Pays-Bas\";s:3:\"lat\";s:17:\"52.28441921674068\";s:3:\"lng\";s:17:\"4.510091591113223\";}");
INSERT INTO `yucqn_postmeta` VALUES("1421","239","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1422","48","gmapes","a:3:{s:7:\"address\";s:46:\"Boekhorsterweg, 2211 Noordwijkerhout, Pays-Bas\";s:3:\"lat\";s:17:\"52.28441921674068\";s:3:\"lng\";s:17:\"4.510091591113223\";}");
INSERT INTO `yucqn_postmeta` VALUES("1423","48","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1425","240","galerie","a:3:{i:0;s:2:\"14\";i:1;s:2:\"13\";i:2;s:2:\"12\";}");
INSERT INTO `yucqn_postmeta` VALUES("1426","240","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1427","240","vendu","1");
INSERT INTO `yucqn_postmeta` VALUES("1428","240","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1429","240","completed_on","20180218");
INSERT INTO `yucqn_postmeta` VALUES("1430","240","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1431","240","size_of_the_scene","15x15");
INSERT INTO `yucqn_postmeta` VALUES("1432","240","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1433","240","size_of_the_frame","20x20");
INSERT INTO `yucqn_postmeta` VALUES("1434","240","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1435","240","gmapes","a:3:{s:7:\"address\";s:18:\"Sea Side Rd, Liban\";s:3:\"lat\";s:18:\"33.979029762562085\";s:3:\"lng\";s:17:\"35.61052418229974\";}");
INSERT INTO `yucqn_postmeta` VALUES("1436","240","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1437","32","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1438","32","gmapes","a:3:{s:7:\"address\";s:18:\"Sea Side Rd, Liban\";s:3:\"lat\";s:18:\"33.979029762562085\";s:3:\"lng\";s:17:\"35.61052418229974\";}");
INSERT INTO `yucqn_postmeta` VALUES("1439","32","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1440","32","_yoast_wpseo_primary_category","");
INSERT INTO `yucqn_postmeta` VALUES("1441","241","_wp_attached_file","2018/03/IMG_20180308_211734.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1442","242","_wp_attached_file","2018/03/IMG_20180308_211734-1.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1443","242","_wp_attachment_metadata","a:5:{s:5:\"width\";i:3174;s:6:\"height\";i:3087;s:4:\"file\";s:33:\"2018/03/IMG_20180308_211734-1.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"IMG_20180308_211734-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"IMG_20180308_211734-1-300x292.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:292;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"IMG_20180308_211734-1-768x747.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:747;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"IMG_20180308_211734-1-1024x996.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:996;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:33:\"IMG_20180308_211734-1-500x486.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:486;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:12:\"Redmi Note 4\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1520543349\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"3.57\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:16:\"0.03030303030303\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1444","245","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1445","245","_edit_lock","1520627364:1");
INSERT INTO `yucqn_postmeta` VALUES("1446","245","_thumbnail_id","242");
INSERT INTO `yucqn_postmeta` VALUES("1448","246","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1449","246","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1450","245","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1451","245","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1452","245","_yoast_wpseo_primary_category","6");
INSERT INTO `yucqn_postmeta` VALUES("1453","249","_wp_attached_file","2018/03/IMG_20180310_162510.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1454","249","_wp_attachment_metadata","a:5:{s:5:\"width\";i:3120;s:6:\"height\";i:4160;s:4:\"file\";s:31:\"2018/03/IMG_20180310_162510.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG_20180310_162510-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG_20180310_162510-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"IMG_20180310_162510-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG_20180310_162510-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:31:\"IMG_20180310_162510-500x667.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:667;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:12:\"Redmi Note 4\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1520699110\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"3.57\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:18:\"0.0020964360587002\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1455","250","_wp_attached_file","2018/03/IMG_20180310_163035.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1456","250","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2724;s:6:\"height\";i:2573;s:4:\"file\";s:31:\"2018/03/IMG_20180310_163035.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG_20180310_163035-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG_20180310_163035-300x283.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:283;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"IMG_20180310_163035-768x725.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:725;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG_20180310_163035-1024x967.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:967;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:31:\"IMG_20180310_163035-500x472.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:472;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:12:\"Redmi Note 4\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1520632755\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"3.57\";s:3:\"iso\";s:3:\"500\";s:13:\"shutter_speed\";s:4:\"0.04\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1457","248","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1458","248","_edit_lock","1520696369:1");
INSERT INTO `yucqn_postmeta` VALUES("1459","248","_thumbnail_id","250");
INSERT INTO `yucqn_postmeta` VALUES("1461","251","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1462","251","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1463","248","_yoast_wpseo_focuskw_text_input","Resin");
INSERT INTO `yucqn_postmeta` VALUES("1464","248","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1465","248","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1466","248","_yoast_wpseo_primary_category","6");
INSERT INTO `yucqn_postmeta` VALUES("1467","252","_wp_attached_file","2018/03/ytt1.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1468","252","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:869;s:4:\"file\";s:16:\"2018/03/ytt1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"ytt1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"ytt1-300x261.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:261;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:16:\"ytt1-768x667.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:667;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:16:\"ytt1-500x435.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:435;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1469","253","_wp_attached_file","2018/03/ytt2.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1470","253","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:863;s:4:\"file\";s:16:\"2018/03/ytt2.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"ytt2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"ytt2-300x259.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:259;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:16:\"ytt2-768x663.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:663;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:16:\"ytt2-500x432.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1471","254","_wp_attached_file","2018/03/ytt3.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1472","254","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:847;s:4:\"file\";s:16:\"2018/03/ytt3.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"ytt3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"ytt3-300x254.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:254;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:16:\"ytt3-768x650.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:650;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:16:\"ytt3-500x424.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:424;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1473","255","_wp_attached_file","2018/03/ytt4.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1474","255","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:830;s:4:\"file\";s:16:\"2018/03/ytt4.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"ytt4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"ytt4-300x249.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:249;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:16:\"ytt4-768x637.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:637;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:16:\"ytt4-500x415.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:415;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1475","256","_wp_attached_file","2018/03/ytt5.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1476","256","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:844;s:4:\"file\";s:16:\"2018/03/ytt5.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"ytt5-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"ytt5-300x253.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:253;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:16:\"ytt5-768x648.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:648;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:16:\"ytt5-500x422.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:422;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1477","257","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1478","257","_edit_lock","1529830089:1");
INSERT INTO `yucqn_postmeta` VALUES("1479","260","_wp_attached_file","2018/03/ytt5-1.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1480","260","_wp_attachment_metadata","a:5:{s:5:\"width\";i:618;s:6:\"height\";i:618;s:4:\"file\";s:18:\"2018/03/ytt5-1.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"ytt5-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"ytt5-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:18:\"ytt5-1-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1481","257","_thumbnail_id","260");
INSERT INTO `yucqn_postmeta` VALUES("1483","261","galerie","a:5:{i:0;s:3:\"256\";i:1;s:3:\"255\";i:2;s:3:\"254\";i:3;s:3:\"253\";i:4;s:3:\"252\";}");
INSERT INTO `yucqn_postmeta` VALUES("1484","261","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1485","261","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1486","261","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1487","261","completed_on","20180310");
INSERT INTO `yucqn_postmeta` VALUES("1488","261","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1489","261","size_of_the_scene","10.8 x 15.8 cm");
INSERT INTO `yucqn_postmeta` VALUES("1490","261","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1491","261","size_of_the_frame","20 x 15cm");
INSERT INTO `yucqn_postmeta` VALUES("1492","261","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1493","261","gmapes","a:3:{s:7:\"address\";s:26:\"Tchoukotka, Russie, 689271\";s:3:\"lat\";s:17:\"64.62985687504633\";s:3:\"lng\";s:19:\"-172.58046254648434\";}");
INSERT INTO `yucqn_postmeta` VALUES("1494","261","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1495","257","_yoast_wpseo_focuskw_text_input","Yttygran");
INSERT INTO `yucqn_postmeta` VALUES("1496","257","_yoast_wpseo_focuskw","Yttygran");
INSERT INTO `yucqn_postmeta` VALUES("1497","257","_yoast_wpseo_title","Yttygran 1/35 diorama whale bones Bering sea from Jean Diorama");
INSERT INTO `yucqn_postmeta` VALUES("1498","257","_yoast_wpseo_linkdex","50");
INSERT INTO `yucqn_postmeta` VALUES("1499","257","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1500","257","galerie","a:5:{i:0;s:3:\"256\";i:1;s:3:\"255\";i:2;s:3:\"254\";i:3;s:3:\"253\";i:4;s:3:\"252\";}");
INSERT INTO `yucqn_postmeta` VALUES("1501","257","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1502","257","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1503","257","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1504","257","completed_on","20180310");
INSERT INTO `yucqn_postmeta` VALUES("1505","257","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1506","257","size_of_the_scene","10.8 x 15.8 cm");
INSERT INTO `yucqn_postmeta` VALUES("1507","257","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1508","257","size_of_the_frame","20 x 15cm");
INSERT INTO `yucqn_postmeta` VALUES("1509","257","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1510","257","gmapes","a:3:{s:7:\"address\";s:26:\"Tchoukotka, Russie, 689271\";s:3:\"lat\";s:17:\"64.62985687504633\";s:3:\"lng\";s:19:\"-172.58046254648434\";}");
INSERT INTO `yucqn_postmeta` VALUES("1511","257","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1512","257","_yoast_wpseo_primary_category","");
INSERT INTO `yucqn_postmeta` VALUES("1514","263","galerie","a:5:{i:0;s:3:\"256\";i:1;s:3:\"255\";i:2;s:3:\"254\";i:3;s:3:\"253\";i:4;s:3:\"252\";}");
INSERT INTO `yucqn_postmeta` VALUES("1515","263","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1516","263","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1517","263","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1518","263","completed_on","20180310");
INSERT INTO `yucqn_postmeta` VALUES("1519","263","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1520","263","size_of_the_scene","10.8 x 15.8 cm");
INSERT INTO `yucqn_postmeta` VALUES("1521","263","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1522","263","size_of_the_frame","20 x 15cm");
INSERT INTO `yucqn_postmeta` VALUES("1523","263","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1524","263","gmapes","a:3:{s:7:\"address\";s:26:\"Tchoukotka, Russie, 689271\";s:3:\"lat\";s:17:\"64.62985687504633\";s:3:\"lng\";s:19:\"-172.58046254648434\";}");
INSERT INTO `yucqn_postmeta` VALUES("1525","263","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1526","257","_yoast_wpseo_metadesc","Box diorama done with various resins and mastics. Shows the Yttygran island on the Bering sea.");
INSERT INTO `yucqn_postmeta` VALUES("1528","264","galerie","a:4:{i:0;s:3:\"168\";i:1;s:3:\"171\";i:2;s:3:\"170\";i:3;s:3:\"169\";}");
INSERT INTO `yucqn_postmeta` VALUES("1529","264","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1530","264","vendu","1");
INSERT INTO `yucqn_postmeta` VALUES("1531","264","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1532","264","completed_on","20171117");
INSERT INTO `yucqn_postmeta` VALUES("1533","264","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1534","264","size_of_the_scene","15x15");
INSERT INTO `yucqn_postmeta` VALUES("1535","264","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1536","264","size_of_the_frame","20x20");
INSERT INTO `yucqn_postmeta` VALUES("1537","264","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1538","264","gmapes","a:3:{s:7:\"address\";s:50:\"Pindo Sur, 140, 15296 O Pindo, La Coruña, Espagne\";s:3:\"lat\";s:17:\"42.88639612824101\";s:3:\"lng\";s:9:\"-9.140625\";}");
INSERT INTO `yucqn_postmeta` VALUES("1539","264","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1540","141","_yoast_wpseo_focuskw_text_input","Sea shore diorama");
INSERT INTO `yucqn_postmeta` VALUES("1541","141","_yoast_wpseo_focuskw","Sea shore diorama");
INSERT INTO `yucqn_postmeta` VALUES("1542","141","_yoast_wpseo_title","Sea Shore diorama in 1/35 From Jean Diorama @ distant-shores");
INSERT INTO `yucqn_postmeta` VALUES("1543","141","_yoast_wpseo_linkdex","28");
INSERT INTO `yucqn_postmeta` VALUES("1545","265","galerie","a:3:{i:0;s:3:\"166\";i:1;s:3:\"165\";i:2;s:3:\"164\";}");
INSERT INTO `yucqn_postmeta` VALUES("1546","265","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1547","265","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1548","265","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1549","265","completed_on","20171213");
INSERT INTO `yucqn_postmeta` VALUES("1550","265","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1551","265","size_of_the_scene","14x10");
INSERT INTO `yucqn_postmeta` VALUES("1552","265","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1553","265","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("1554","265","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1555","265","gmapes","a:3:{s:7:\"address\";s:45:\"Unnamed Road, 85550 La Barre-de-Monts, France\";s:3:\"lat\";s:18:\"46.877640448714246\";s:3:\"lng\";s:18:\"-2.152891159057617\";}");
INSERT INTO `yucqn_postmeta` VALUES("1556","265","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1557","106","_yoast_wpseo_focuskw_text_input","Ripples");
INSERT INTO `yucqn_postmeta` VALUES("1558","106","_yoast_wpseo_focuskw","Ripples");
INSERT INTO `yucqn_postmeta` VALUES("1559","106","_yoast_wpseo_linkdex","50");
INSERT INTO `yucqn_postmeta` VALUES("1560","267","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1561","267","_edit_lock","1521316188:1");
INSERT INTO `yucqn_postmeta` VALUES("1562","268","_wp_attached_file","2018/03/bones.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1563","268","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:17:\"2018/03/bones.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"bones-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"bones-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:17:\"bones-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"bones-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:17:\"bones-500x500.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1564","268","_wp_attachment_image_alt","Whale bones at Yttygran");
INSERT INTO `yucqn_postmeta` VALUES("1565","267","_thumbnail_id","268");
INSERT INTO `yucqn_postmeta` VALUES("1567","269","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1568","269","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1569","267","_yoast_wpseo_title","Yttygran 1/35 whale bones Bering sea from Jean Diorama");
INSERT INTO `yucqn_postmeta` VALUES("1570","267","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1571","267","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1572","267","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1573","267","_yoast_wpseo_primary_category","6");
INSERT INTO `yucqn_postmeta` VALUES("1575","270","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1576","270","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1578","272","galerie","a:3:{i:0;s:3:\"160\";i:1;s:3:\"162\";i:2;s:3:\"161\";}");
INSERT INTO `yucqn_postmeta` VALUES("1579","272","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1580","272","vendu","1");
INSERT INTO `yucqn_postmeta` VALUES("1581","272","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1582","272","completed_on","20171220");
INSERT INTO `yucqn_postmeta` VALUES("1583","272","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1584","272","size_of_the_scene","14x10");
INSERT INTO `yucqn_postmeta` VALUES("1585","272","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1586","272","size_of_the_frame","20x15");
INSERT INTO `yucqn_postmeta` VALUES("1587","272","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1588","272","gmapes","a:3:{s:7:\"address\";s:11:\"Royaume-Uni\";s:3:\"lat\";s:17:\"50.58694239388468\";s:3:\"lng\";s:18:\"0.5416131492187333\";}");
INSERT INTO `yucqn_postmeta` VALUES("1589","272","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1590","103","_yoast_wpseo_focuskw_text_input","sea");
INSERT INTO `yucqn_postmeta` VALUES("1591","103","_yoast_wpseo_focuskw","sea");
INSERT INTO `yucqn_postmeta` VALUES("1592","103","_yoast_wpseo_title","The Grey Sea 1/35 diorama featureing resin made sea in a Box");
INSERT INTO `yucqn_postmeta` VALUES("1593","103","_yoast_wpseo_linkdex","36");
INSERT INTO `yucqn_postmeta` VALUES("1621","275","_wp_attached_file","2018/05/MG_3297.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1622","275","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:615;s:4:\"file\";s:19:\"2018/05/MG_3297.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_3297-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_3297-300x185.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:185;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_3297-768x472.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:472;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"news-thumb\";a:4:{s:4:\"file\";s:19:\"MG_3297-500x308.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:308;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1623","276","_edit_lock","1525880545:1");
INSERT INTO `yucqn_postmeta` VALUES("1624","276","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1625","275","_wp_attachment_image_alt","Ice in 1/35 icechunks");
INSERT INTO `yucqn_postmeta` VALUES("1626","276","_thumbnail_id","275");
INSERT INTO `yucqn_postmeta` VALUES("1628","277","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1629","277","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1630","276","_yoast_wpseo_focuskw_text_input","Ice modeling");
INSERT INTO `yucqn_postmeta` VALUES("1631","276","_yoast_wpseo_focuskw","Ice modeling");
INSERT INTO `yucqn_postmeta` VALUES("1632","276","_yoast_wpseo_linkdex","24");
INSERT INTO `yucqn_postmeta` VALUES("1633","276","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1634","276","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1635","276","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1636","276","_yoast_wpseo_primary_category","6");
INSERT INTO `yucqn_postmeta` VALUES("1637","44","field_5b057a3313c72","a:14:{s:3:\"key\";s:19:\"field_5b057a3313c72\";s:5:\"label\";s:15:\"video url react\";s:4:\"name\";s:15:\"video_url_react\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";s:1:\"0\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:10:\"formatting\";s:4:\"html\";s:9:\"maxlength\";s:0:\"\";s:17:\"conditional_logic\";a:3:{s:6:\"status\";s:1:\"0\";s:5:\"rules\";a:1:{i:0;a:2:{s:5:\"field\";s:4:\"null\";s:8:\"operator\";s:2:\"==\";}}s:8:\"allorany\";s:3:\"all\";}s:8:\"order_no\";i:2;}");
INSERT INTO `yucqn_postmeta` VALUES("1638","44","rule","a:5:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"34\";s:8:\"order_no\";i:0;s:8:\"group_no\";i:0;}");
INSERT INTO `yucqn_postmeta` VALUES("1639","279","marquee","Here are my dioramas, the latest done on top, older on the bottom, you may click on each one to see other pictures, thank you very much -- ");
INSERT INTO `yucqn_postmeta` VALUES("1640","279","_marquee","field_5a8c520821ff9");
INSERT INTO `yucqn_postmeta` VALUES("1641","279","url_de_la_video","https://youtu.be/RTGbdr4yc7c");
INSERT INTO `yucqn_postmeta` VALUES("1642","279","_url_de_la_video","field_5a8c522321ffa");
INSERT INTO `yucqn_postmeta` VALUES("1643","279","video_url_react","RTGbdr4yc7c");
INSERT INTO `yucqn_postmeta` VALUES("1644","279","_video_url_react","field_5b057a3313c72");
INSERT INTO `yucqn_postmeta` VALUES("1645","279","masque_video","128");
INSERT INTO `yucqn_postmeta` VALUES("1646","279","_masque_video","field_5a8c523321ffb");
INSERT INTO `yucqn_postmeta` VALUES("1648","34","video_url_react","RTGbdr4yc7c");
INSERT INTO `yucqn_postmeta` VALUES("1649","34","_video_url_react","field_5b057a3313c72");
INSERT INTO `yucqn_postmeta` VALUES("1650","34","_yoast_wpseo_is_cornerstone","1");
INSERT INTO `yucqn_postmeta` VALUES("1651","282","_edit_lock","1538067858:1");
INSERT INTO `yucqn_postmeta` VALUES("1652","282","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1653","283","_wp_attached_file","2018/06/MG_4289.png");
INSERT INTO `yucqn_postmeta` VALUES("1654","283","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:19:\"2018/06/MG_4289.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_4289-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_4289-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_4289-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"MG_4289-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1655","284","_wp_attached_file","2018/06/MG_4292.png");
INSERT INTO `yucqn_postmeta` VALUES("1656","284","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:19:\"2018/06/MG_4292.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_4292-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_4292-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_4292-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"MG_4292-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1657","285","_wp_attached_file","2018/06/MG_4295.png");
INSERT INTO `yucqn_postmeta` VALUES("1658","285","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:19:\"2018/06/MG_4295.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_4295-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_4295-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_4295-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"MG_4295-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1659","286","_wp_attached_file","2018/06/MG_42922.png");
INSERT INTO `yucqn_postmeta` VALUES("1660","286","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:20:\"2018/06/MG_42922.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"MG_42922-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"MG_42922-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"MG_42922-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1662","287","galerie","a:3:{i:0;s:3:\"283\";i:1;s:3:\"284\";i:2;s:3:\"285\";}");
INSERT INTO `yucqn_postmeta` VALUES("1663","287","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1664","287","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1665","287","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1666","287","completed_on","20180624");
INSERT INTO `yucqn_postmeta` VALUES("1667","287","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1668","287","size_of_the_scene","11");
INSERT INTO `yucqn_postmeta` VALUES("1669","287","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1670","287","size_of_the_frame","8");
INSERT INTO `yucqn_postmeta` VALUES("1671","287","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1672","287","gmapes","a:3:{s:7:\"address\";s:0:\"\";s:3:\"lat\";s:17:\"38.70262984568226\";s:3:\"lng\";s:18:\"20.894861396652573\";}");
INSERT INTO `yucqn_postmeta` VALUES("1673","287","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1674","282","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1675","282","galerie","a:3:{i:0;s:3:\"283\";i:1;s:3:\"284\";i:2;s:3:\"285\";}");
INSERT INTO `yucqn_postmeta` VALUES("1676","282","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1677","282","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1678","282","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1679","282","completed_on","20180624");
INSERT INTO `yucqn_postmeta` VALUES("1680","282","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1681","282","size_of_the_scene","11");
INSERT INTO `yucqn_postmeta` VALUES("1682","282","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1683","282","size_of_the_frame","8");
INSERT INTO `yucqn_postmeta` VALUES("1684","282","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1685","282","gmapes","a:3:{s:7:\"address\";s:0:\"\";s:3:\"lat\";s:17:\"38.70262984568226\";s:3:\"lng\";s:18:\"20.894861396652573\";}");
INSERT INTO `yucqn_postmeta` VALUES("1686","282","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1687","282","_yoast_wpseo_primary_category","2");
INSERT INTO `yucqn_postmeta` VALUES("1689","288","galerie","a:5:{i:0;s:3:\"256\";i:1;s:3:\"255\";i:2;s:3:\"254\";i:3;s:3:\"253\";i:4;s:3:\"252\";}");
INSERT INTO `yucqn_postmeta` VALUES("1690","288","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1691","288","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1692","288","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1693","288","completed_on","20180310");
INSERT INTO `yucqn_postmeta` VALUES("1694","288","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1695","288","size_of_the_scene","10.8 x 15.8 cm");
INSERT INTO `yucqn_postmeta` VALUES("1696","288","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1697","288","size_of_the_frame","20 x 15cm");
INSERT INTO `yucqn_postmeta` VALUES("1698","288","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1699","288","gmapes","a:3:{s:7:\"address\";s:26:\"Tchoukotka, Russie, 689271\";s:3:\"lat\";s:17:\"64.62985687504633\";s:3:\"lng\";s:19:\"-172.58046254648434\";}");
INSERT INTO `yucqn_postmeta` VALUES("1700","288","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1702","282","_thumbnail_id","286");
INSERT INTO `yucqn_postmeta` VALUES("1704","292","galerie","a:3:{i:0;s:3:\"283\";i:1;s:3:\"284\";i:2;s:3:\"285\";}");
INSERT INTO `yucqn_postmeta` VALUES("1705","292","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1706","292","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1707","292","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1708","292","completed_on","20180624");
INSERT INTO `yucqn_postmeta` VALUES("1709","292","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1710","292","size_of_the_scene","11");
INSERT INTO `yucqn_postmeta` VALUES("1711","292","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1712","292","size_of_the_frame","8");
INSERT INTO `yucqn_postmeta` VALUES("1713","292","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1714","292","gmapes","a:3:{s:7:\"address\";s:0:\"\";s:3:\"lat\";s:17:\"38.70262984568226\";s:3:\"lng\";s:18:\"20.894861396652573\";}");
INSERT INTO `yucqn_postmeta` VALUES("1715","292","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1718","295","galerie","a:3:{i:0;s:3:\"283\";i:1;s:3:\"284\";i:2;s:3:\"285\";}");
INSERT INTO `yucqn_postmeta` VALUES("1719","295","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1720","295","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1721","295","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1722","295","completed_on","20180624");
INSERT INTO `yucqn_postmeta` VALUES("1723","295","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1724","295","size_of_the_scene","11");
INSERT INTO `yucqn_postmeta` VALUES("1725","295","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1726","295","size_of_the_frame","8");
INSERT INTO `yucqn_postmeta` VALUES("1727","295","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1728","295","gmapes","a:3:{s:7:\"address\";s:0:\"\";s:3:\"lat\";s:17:\"38.70262984568226\";s:3:\"lng\";s:18:\"20.894861396652573\";}");
INSERT INTO `yucqn_postmeta` VALUES("1729","295","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1730","300","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1731","300","_edit_lock","1529860945:1");
INSERT INTO `yucqn_postmeta` VALUES("1732","301","_wp_attached_file","2018/06/IMG_20180620_200341.jpg");
INSERT INTO `yucqn_postmeta` VALUES("1733","301","_wp_attachment_metadata","a:5:{s:5:\"width\";i:3120;s:6:\"height\";i:4160;s:4:\"file\";s:31:\"2018/06/IMG_20180620_200341.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"IMG_20180620_200341-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"IMG_20180620_200341-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"IMG_20180620_200341-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"IMG_20180620_200341-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"2\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:12:\"Redmi Note 4\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1529525021\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"3.57\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:4:\"0.04\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1734","300","_thumbnail_id","301");
INSERT INTO `yucqn_postmeta` VALUES("1736","303","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1737","303","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1738","300","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1739","300","gallery","");
INSERT INTO `yucqn_postmeta` VALUES("1740","300","_gallery","field_5a8eb974430f5");
INSERT INTO `yucqn_postmeta` VALUES("1741","300","_yoast_wpseo_primary_category","6");
INSERT INTO `yucqn_postmeta` VALUES("1742","305","_edit_lock","1540632803:1");
INSERT INTO `yucqn_postmeta` VALUES("1743","305","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1744","306","_wp_attached_file","2018/09/tghumb-1.png");
INSERT INTO `yucqn_postmeta` VALUES("1745","306","_wp_attachment_metadata","a:5:{s:5:\"width\";i:990;s:6:\"height\";i:990;s:4:\"file\";s:20:\"2018/09/tghumb-1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"tghumb-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"tghumb-1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"tghumb-1-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1746","307","_wp_attached_file","2018/09/MG_5459-1.png");
INSERT INTO `yucqn_postmeta` VALUES("1747","307","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:21:\"2018/09/MG_5459-1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"MG_5459-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"MG_5459-1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"MG_5459-1-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1748","308","_wp_attached_file","2018/09/MG_5467-1.png");
INSERT INTO `yucqn_postmeta` VALUES("1749","308","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:21:\"2018/09/MG_5467-1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"MG_5467-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"MG_5467-1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"MG_5467-1-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1750","305","_thumbnail_id","306");
INSERT INTO `yucqn_postmeta` VALUES("1752","309","galerie","a:2:{i:0;s:3:\"308\";i:1;s:3:\"307\";}");
INSERT INTO `yucqn_postmeta` VALUES("1753","309","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1754","309","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1755","309","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1756","309","completed_on","");
INSERT INTO `yucqn_postmeta` VALUES("1757","309","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1758","309","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("1759","309","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1760","309","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("1761","309","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1762","309","gmapes","");
INSERT INTO `yucqn_postmeta` VALUES("1763","309","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1764","305","_yoast_wpseo_content_score","30");
INSERT INTO `yucqn_postmeta` VALUES("1765","305","galerie","a:2:{i:0;s:3:\"308\";i:1;s:3:\"307\";}");
INSERT INTO `yucqn_postmeta` VALUES("1766","305","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1767","305","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1768","305","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1769","305","completed_on","");
INSERT INTO `yucqn_postmeta` VALUES("1770","305","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1771","305","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("1772","305","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1773","305","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("1774","305","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1775","305","gmapes","a:3:{s:7:\"address\";s:0:\"\";s:3:\"lat\";s:18:\"53.848654392082324\";s:3:\"lng\";s:19:\"-23.164559873356666\";}");
INSERT INTO `yucqn_postmeta` VALUES("1776","305","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1777","305","_yoast_wpseo_primary_category","2");
INSERT INTO `yucqn_postmeta` VALUES("1779","310","galerie","a:2:{i:0;s:3:\"308\";i:1;s:3:\"307\";}");
INSERT INTO `yucqn_postmeta` VALUES("1780","310","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1781","310","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1782","310","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1783","310","completed_on","");
INSERT INTO `yucqn_postmeta` VALUES("1784","310","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1785","310","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("1786","310","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1787","310","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("1788","310","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1789","310","gmapes","");
INSERT INTO `yucqn_postmeta` VALUES("1790","310","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1791","311","_edit_lock","1540631111:1");
INSERT INTO `yucqn_postmeta` VALUES("1792","311","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1793","312","_wp_attached_file","2018/09/MG_5617-1.png");
INSERT INTO `yucqn_postmeta` VALUES("1794","312","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1017;s:6:\"height\";i:1000;s:4:\"file\";s:21:\"2018/09/MG_5617-1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"MG_5617-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"MG_5617-1-300x295.png\";s:5:\"width\";i:300;s:6:\"height\";i:295;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"MG_5617-1-768x755.png\";s:5:\"width\";i:768;s:6:\"height\";i:755;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1795","313","_wp_attached_file","2018/09/MG_5621-1.png");
INSERT INTO `yucqn_postmeta` VALUES("1796","313","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:21:\"2018/09/MG_5621-1.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"MG_5621-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"MG_5621-1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"MG_5621-1-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"MG_5621-1-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1797","314","_wp_attached_file","2018/09/MG_5625-1.png");
INSERT INTO `yucqn_postmeta` VALUES("1798","314","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:21:\"2018/09/MG_5625-1.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"MG_5625-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"MG_5625-1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"MG_5625-1-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"MG_5625-1-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1799","315","_wp_attached_file","2018/09/MG_5626-1.png");
INSERT INTO `yucqn_postmeta` VALUES("1800","315","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:21:\"2018/09/MG_5626-1.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"MG_5626-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"MG_5626-1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"MG_5626-1-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"MG_5626-1-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1801","316","_wp_attached_file","2018/09/MG_5628-1.png");
INSERT INTO `yucqn_postmeta` VALUES("1802","316","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:21:\"2018/09/MG_5628-1.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"MG_5628-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"MG_5628-1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"MG_5628-1-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"MG_5628-1-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1803","317","_wp_attached_file","2018/09/s_MG_5617-1.png");
INSERT INTO `yucqn_postmeta` VALUES("1804","317","_wp_attachment_metadata","a:5:{s:5:\"width\";i:580;s:6:\"height\";i:580;s:4:\"file\";s:23:\"2018/09/s_MG_5617-1.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"s_MG_5617-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"s_MG_5617-1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1805","311","_thumbnail_id","317");
INSERT INTO `yucqn_postmeta` VALUES("1807","318","galerie","a:5:{i:0;s:3:\"312\";i:1;s:3:\"313\";i:2;s:3:\"314\";i:3;s:3:\"316\";i:4;s:3:\"315\";}");
INSERT INTO `yucqn_postmeta` VALUES("1808","318","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1809","318","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1810","318","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1811","318","completed_on","");
INSERT INTO `yucqn_postmeta` VALUES("1812","318","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1813","318","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("1814","318","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1815","318","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("1816","318","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1817","318","gmapes","");
INSERT INTO `yucqn_postmeta` VALUES("1818","318","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1819","311","_yoast_wpseo_content_score","60");
INSERT INTO `yucqn_postmeta` VALUES("1820","311","galerie","a:5:{i:0;s:3:\"312\";i:1;s:3:\"313\";i:2;s:3:\"314\";i:3;s:3:\"316\";i:4;s:3:\"315\";}");
INSERT INTO `yucqn_postmeta` VALUES("1821","311","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1822","311","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1823","311","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1824","311","completed_on","20180916");
INSERT INTO `yucqn_postmeta` VALUES("1825","311","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1826","311","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("1827","311","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1828","311","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("1829","311","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1830","311","gmapes","a:3:{s:7:\"address\";s:7:\"islande\";s:3:\"lat\";s:16:\"65.0890119742668\";s:3:\"lng\";s:18:\"-22.47505997894973\";}");
INSERT INTO `yucqn_postmeta` VALUES("1831","311","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1832","311","_yoast_wpseo_primary_category","2");
INSERT INTO `yucqn_postmeta` VALUES("1833","320","_edit_lock","1540632024:1");
INSERT INTO `yucqn_postmeta` VALUES("1834","320","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1835","321","_wp_attached_file","2018/10/MG_5633.png");
INSERT INTO `yucqn_postmeta` VALUES("1836","321","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:19:\"2018/10/MG_5633.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_5633-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_5633-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_5633-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"MG_5633-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1837","322","_wp_attached_file","2018/10/MG_5635.png");
INSERT INTO `yucqn_postmeta` VALUES("1838","322","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:19:\"2018/10/MG_5635.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_5635-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_5635-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_5635-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"MG_5635-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1839","323","_wp_attached_file","2018/10/MG_5641.png");
INSERT INTO `yucqn_postmeta` VALUES("1840","323","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:19:\"2018/10/MG_5641.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_5641-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_5641-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_5641-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"MG_5641-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1841","324","_wp_attached_file","2018/10/site.png");
INSERT INTO `yucqn_postmeta` VALUES("1842","324","_wp_attachment_metadata","a:5:{s:5:\"width\";i:512;s:6:\"height\";i:512;s:4:\"file\";s:16:\"2018/10/site.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"site-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"site-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1843","320","_thumbnail_id","324");
INSERT INTO `yucqn_postmeta` VALUES("1845","325","galerie","a:3:{i:0;s:3:\"321\";i:1;s:3:\"322\";i:2;s:3:\"323\";}");
INSERT INTO `yucqn_postmeta` VALUES("1846","325","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1847","325","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1848","325","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1849","325","completed_on","");
INSERT INTO `yucqn_postmeta` VALUES("1850","325","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1851","325","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("1852","325","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1853","325","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("1854","325","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1855","325","gmapes","");
INSERT INTO `yucqn_postmeta` VALUES("1856","325","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1857","320","_yoast_wpseo_content_score","60");
INSERT INTO `yucqn_postmeta` VALUES("1858","320","galerie","a:3:{i:0;s:3:\"321\";i:1;s:3:\"322\";i:2;s:3:\"323\";}");
INSERT INTO `yucqn_postmeta` VALUES("1859","320","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1860","320","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1861","320","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1862","320","completed_on","20180923");
INSERT INTO `yucqn_postmeta` VALUES("1863","320","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1864","320","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("1865","320","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1866","320","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("1867","320","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1868","320","gmapes","a:3:{s:7:\"address\";s:12:\"aiguebelette\";s:3:\"lat\";s:17:\"45.48156761727435\";s:3:\"lng\";s:17:\"6.934866558258818\";}");
INSERT INTO `yucqn_postmeta` VALUES("1869","320","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1870","320","_yoast_wpseo_primary_category","2");
INSERT INTO `yucqn_postmeta` VALUES("1871","326","_edit_lock","1540632450:1");
INSERT INTO `yucqn_postmeta` VALUES("1872","326","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1873","327","_wp_attached_file","2018/10/MG_434-e1538818532334.png");
INSERT INTO `yucqn_postmeta` VALUES("1874","327","_wp_attachment_metadata","a:5:{s:5:\"width\";i:407;s:6:\"height\";i:385;s:4:\"file\";s:33:\"2018/10/MG_434-e1538818532334.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"MG_434-e1538818532334-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"MG_434-e1538818532334-300x284.png\";s:5:\"width\";i:300;s:6:\"height\";i:284;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"MG_434-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1875","328","_wp_attached_file","2018/10/MG_4327.png");
INSERT INTO `yucqn_postmeta` VALUES("1876","328","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/10/MG_4327.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_4327-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_4327-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_4327-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1877","329","_wp_attached_file","2018/10/MG_4325.png");
INSERT INTO `yucqn_postmeta` VALUES("1878","329","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/10/MG_4325.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_4325-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_4325-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_4325-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1879","330","_wp_attached_file","2018/10/MG_4324.png");
INSERT INTO `yucqn_postmeta` VALUES("1880","330","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/10/MG_4324.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_4324-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_4324-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_4324-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1881","327","_wp_attachment_backup_sizes","a:4:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:10:\"MG_434.png\";}s:14:\"thumbnail-orig\";a:4:{s:4:\"file\";s:18:\"MG_434-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"medium-orig\";a:4:{s:4:\"file\";s:18:\"MG_434-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:17:\"medium_large-orig\";a:4:{s:4:\"file\";s:18:\"MG_434-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}");
INSERT INTO `yucqn_postmeta` VALUES("1882","331","_wp_attached_file","2018/10/MG_4325-1.png");
INSERT INTO `yucqn_postmeta` VALUES("1883","331","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:21:\"2018/10/MG_4325-1.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"MG_4325-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"MG_4325-1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"MG_4325-1-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1884","326","_thumbnail_id","327");
INSERT INTO `yucqn_postmeta` VALUES("1886","332","galerie","a:3:{i:0;s:3:\"330\";i:1;s:3:\"329\";i:2;s:3:\"328\";}");
INSERT INTO `yucqn_postmeta` VALUES("1887","332","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1888","332","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1889","332","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1890","332","completed_on","");
INSERT INTO `yucqn_postmeta` VALUES("1891","332","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1892","332","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("1893","332","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1894","332","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("1895","332","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1896","332","gmapes","");
INSERT INTO `yucqn_postmeta` VALUES("1897","332","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1898","326","_yoast_wpseo_content_score","60");
INSERT INTO `yucqn_postmeta` VALUES("1899","326","galerie","a:3:{i:0;s:3:\"330\";i:1;s:3:\"329\";i:2;s:3:\"328\";}");
INSERT INTO `yucqn_postmeta` VALUES("1900","326","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1901","326","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1902","326","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1903","326","completed_on","20180701");
INSERT INTO `yucqn_postmeta` VALUES("1904","326","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1905","326","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("1906","326","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1907","326","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("1908","326","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1909","326","gmapes","a:3:{s:7:\"address\";s:0:\"\";s:3:\"lat\";s:18:\"45.793602986946546\";s:3:\"lng\";s:17:\"4.823034139731476\";}");
INSERT INTO `yucqn_postmeta` VALUES("1910","326","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1911","326","_yoast_wpseo_primary_category","2");
INSERT INTO `yucqn_postmeta` VALUES("1914","335","galerie","a:3:{i:0;s:3:\"330\";i:1;s:3:\"329\";i:2;s:3:\"328\";}");
INSERT INTO `yucqn_postmeta` VALUES("1915","335","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1916","335","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1917","335","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1918","335","completed_on","20180701");
INSERT INTO `yucqn_postmeta` VALUES("1919","335","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1920","335","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("1921","335","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1922","335","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("1923","335","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1924","335","gmapes","a:3:{s:7:\"address\";s:0:\"\";s:3:\"lat\";s:18:\"45.793602986946546\";s:3:\"lng\";s:17:\"4.823034139731476\";}");
INSERT INTO `yucqn_postmeta` VALUES("1925","335","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1927","336","galerie","a:3:{i:0;s:3:\"321\";i:1;s:3:\"322\";i:2;s:3:\"323\";}");
INSERT INTO `yucqn_postmeta` VALUES("1928","336","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1929","336","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1930","336","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1931","336","completed_on","20180923");
INSERT INTO `yucqn_postmeta` VALUES("1932","336","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1933","336","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("1934","336","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1935","336","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("1936","336","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1937","336","gmapes","a:3:{s:7:\"address\";s:12:\"aiguebelette\";s:3:\"lat\";s:17:\"45.48156761727435\";s:3:\"lng\";s:17:\"6.934866558258818\";}");
INSERT INTO `yucqn_postmeta` VALUES("1938","336","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1940","337","galerie","a:5:{i:0;s:3:\"312\";i:1;s:3:\"313\";i:2;s:3:\"314\";i:3;s:3:\"316\";i:4;s:3:\"315\";}");
INSERT INTO `yucqn_postmeta` VALUES("1941","337","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1942","337","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1943","337","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1944","337","completed_on","20180916");
INSERT INTO `yucqn_postmeta` VALUES("1945","337","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1946","337","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("1947","337","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1948","337","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("1949","337","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1950","337","gmapes","a:3:{s:7:\"address\";s:7:\"islande\";s:3:\"lat\";s:16:\"65.0890119742668\";s:3:\"lng\";s:18:\"-22.47505997894973\";}");
INSERT INTO `yucqn_postmeta` VALUES("1951","337","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1953","338","galerie","a:5:{i:0;s:3:\"312\";i:1;s:3:\"313\";i:2;s:3:\"314\";i:3;s:3:\"316\";i:4;s:3:\"315\";}");
INSERT INTO `yucqn_postmeta` VALUES("1954","338","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1955","338","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1956","338","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1957","338","completed_on","20180916");
INSERT INTO `yucqn_postmeta` VALUES("1958","338","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1959","338","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("1960","338","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1961","338","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("1962","338","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1963","338","gmapes","a:3:{s:7:\"address\";s:7:\"islande\";s:3:\"lat\";s:16:\"65.0890119742668\";s:3:\"lng\";s:18:\"-22.47505997894973\";}");
INSERT INTO `yucqn_postmeta` VALUES("1964","338","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1966","339","galerie","a:2:{i:0;s:3:\"308\";i:1;s:3:\"307\";}");
INSERT INTO `yucqn_postmeta` VALUES("1967","339","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1968","339","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1969","339","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1970","339","completed_on","");
INSERT INTO `yucqn_postmeta` VALUES("1971","339","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("1972","339","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("1973","339","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("1974","339","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("1975","339","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("1976","339","gmapes","a:3:{s:7:\"address\";s:0:\"\";s:3:\"lat\";s:18:\"53.848654392082324\";s:3:\"lng\";s:19:\"-23.164559873356666\";}");
INSERT INTO `yucqn_postmeta` VALUES("1977","339","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("1979","342","_wp_attached_file","2018/10/MG_5686.png");
INSERT INTO `yucqn_postmeta` VALUES("1980","342","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:19:\"2018/10/MG_5686.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_5686-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_5686-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_5686-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1981","343","_wp_attached_file","2018/10/MG_5689.png");
INSERT INTO `yucqn_postmeta` VALUES("1982","343","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:19:\"2018/10/MG_5689.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_5689-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_5689-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_5689-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"MG_5689-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1983","344","_wp_attached_file","2018/10/MG_5691.png");
INSERT INTO `yucqn_postmeta` VALUES("1984","344","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:19:\"2018/10/MG_5691.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_5691-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_5691-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_5691-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"MG_5691-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1985","345","_wp_attached_file","2018/10/MG_5696.png");
INSERT INTO `yucqn_postmeta` VALUES("1986","345","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:19:\"2018/10/MG_5696.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_5696-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_5696-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_5696-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"MG_5696-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1987","346","_wp_attached_file","2018/10/MG_5698.png");
INSERT INTO `yucqn_postmeta` VALUES("1988","346","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:19:\"2018/10/MG_5698.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_5698-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_5698-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_5698-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"MG_5698-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1989","347","_wp_attached_file","2018/10/care2.png");
INSERT INTO `yucqn_postmeta` VALUES("1990","347","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1101;s:6:\"height\";i:1101;s:4:\"file\";s:17:\"2018/10/care2.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"care2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"care2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:17:\"care2-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"care2-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("1991","348","_edit_lock","1540651060:1");
INSERT INTO `yucqn_postmeta` VALUES("1992","348","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("1993","348","_thumbnail_id","347");
INSERT INTO `yucqn_postmeta` VALUES("1995","349","galerie","a:4:{i:0;s:3:\"345\";i:1;s:3:\"346\";i:2;s:3:\"344\";i:3;s:3:\"343\";}");
INSERT INTO `yucqn_postmeta` VALUES("1996","349","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("1997","349","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("1998","349","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("1999","349","completed_on","");
INSERT INTO `yucqn_postmeta` VALUES("2000","349","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("2001","349","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("2002","349","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("2003","349","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("2004","349","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("2005","349","gmapes","a:3:{s:7:\"address\";s:6:\"kassel\";s:3:\"lat\";s:17:\"51.29793676987048\";s:3:\"lng\";s:17:\"9.654172703282143\";}");
INSERT INTO `yucqn_postmeta` VALUES("2006","349","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("2007","348","_yoast_wpseo_content_score","60");
INSERT INTO `yucqn_postmeta` VALUES("2008","348","galerie","a:4:{i:0;s:3:\"345\";i:1;s:3:\"346\";i:2;s:3:\"344\";i:3;s:3:\"343\";}");
INSERT INTO `yucqn_postmeta` VALUES("2009","348","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("2010","348","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("2011","348","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("2012","348","completed_on","20181013");
INSERT INTO `yucqn_postmeta` VALUES("2013","348","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("2014","348","size_of_the_scene","14x9 cm");
INSERT INTO `yucqn_postmeta` VALUES("2015","348","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("2016","348","size_of_the_frame","15x10cm");
INSERT INTO `yucqn_postmeta` VALUES("2017","348","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("2018","348","gmapes","a:3:{s:7:\"address\";s:6:\"kassel\";s:3:\"lat\";s:17:\"51.29793676987048\";s:3:\"lng\";s:17:\"9.654172703282143\";}");
INSERT INTO `yucqn_postmeta` VALUES("2019","348","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("2020","348","_yoast_wpseo_primary_category","2");
INSERT INTO `yucqn_postmeta` VALUES("2022","350","galerie","a:4:{i:0;s:3:\"345\";i:1;s:3:\"346\";i:2;s:3:\"344\";i:3;s:3:\"343\";}");
INSERT INTO `yucqn_postmeta` VALUES("2023","350","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("2024","350","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("2025","350","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("2026","350","completed_on","20181013");
INSERT INTO `yucqn_postmeta` VALUES("2027","350","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("2028","350","size_of_the_scene","14x9 cm");
INSERT INTO `yucqn_postmeta` VALUES("2029","350","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("2030","350","size_of_the_frame","15x10cm");
INSERT INTO `yucqn_postmeta` VALUES("2031","350","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("2032","350","gmapes","a:3:{s:7:\"address\";s:6:\"kassel\";s:3:\"lat\";s:17:\"51.29793676987048\";s:3:\"lng\";s:17:\"9.654172703282143\";}");
INSERT INTO `yucqn_postmeta` VALUES("2033","350","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("2035","353","galerie","a:5:{i:0;s:3:\"312\";i:1;s:3:\"313\";i:2;s:3:\"314\";i:3;s:3:\"316\";i:4;s:3:\"315\";}");
INSERT INTO `yucqn_postmeta` VALUES("2036","353","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("2037","353","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("2038","353","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("2039","353","completed_on","20180916");
INSERT INTO `yucqn_postmeta` VALUES("2040","353","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("2041","353","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("2042","353","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("2043","353","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("2044","353","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("2045","353","gmapes","a:3:{s:7:\"address\";s:7:\"islande\";s:3:\"lat\";s:16:\"65.0890119742668\";s:3:\"lng\";s:18:\"-22.47505997894973\";}");
INSERT INTO `yucqn_postmeta` VALUES("2046","353","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("2048","355","galerie","a:3:{i:0;s:3:\"321\";i:1;s:3:\"322\";i:2;s:3:\"323\";}");
INSERT INTO `yucqn_postmeta` VALUES("2049","355","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("2050","355","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("2051","355","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("2052","355","completed_on","20180923");
INSERT INTO `yucqn_postmeta` VALUES("2053","355","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("2054","355","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("2055","355","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("2056","355","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("2057","355","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("2058","355","gmapes","a:3:{s:7:\"address\";s:12:\"aiguebelette\";s:3:\"lat\";s:17:\"45.48156761727435\";s:3:\"lng\";s:17:\"6.934866558258818\";}");
INSERT INTO `yucqn_postmeta` VALUES("2059","355","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("2061","357","galerie","a:4:{i:0;s:3:\"345\";i:1;s:3:\"346\";i:2;s:3:\"344\";i:3;s:3:\"343\";}");
INSERT INTO `yucqn_postmeta` VALUES("2062","357","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("2063","357","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("2064","357","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("2065","357","completed_on","20181013");
INSERT INTO `yucqn_postmeta` VALUES("2066","357","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("2067","357","size_of_the_scene","14x9 cm");
INSERT INTO `yucqn_postmeta` VALUES("2068","357","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("2069","357","size_of_the_frame","15x10cm");
INSERT INTO `yucqn_postmeta` VALUES("2070","357","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("2071","357","gmapes","a:3:{s:7:\"address\";s:6:\"kassel\";s:3:\"lat\";s:17:\"51.29793676987048\";s:3:\"lng\";s:17:\"9.654172703282143\";}");
INSERT INTO `yucqn_postmeta` VALUES("2072","357","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("2074","358","galerie","a:4:{i:0;s:3:\"345\";i:1;s:3:\"346\";i:2;s:3:\"344\";i:3;s:3:\"343\";}");
INSERT INTO `yucqn_postmeta` VALUES("2075","358","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("2076","358","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("2077","358","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("2078","358","completed_on","20181013");
INSERT INTO `yucqn_postmeta` VALUES("2079","358","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("2080","358","size_of_the_scene","14x9 cm");
INSERT INTO `yucqn_postmeta` VALUES("2081","358","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("2082","358","size_of_the_frame","15x10cm");
INSERT INTO `yucqn_postmeta` VALUES("2083","358","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("2084","358","gmapes","a:3:{s:7:\"address\";s:6:\"kassel\";s:3:\"lat\";s:17:\"51.29793676987048\";s:3:\"lng\";s:17:\"9.654172703282143\";}");
INSERT INTO `yucqn_postmeta` VALUES("2085","358","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("2087","360","galerie","a:3:{i:0;s:3:\"330\";i:1;s:3:\"329\";i:2;s:3:\"328\";}");
INSERT INTO `yucqn_postmeta` VALUES("2088","360","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("2089","360","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("2090","360","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("2091","360","completed_on","20180701");
INSERT INTO `yucqn_postmeta` VALUES("2092","360","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("2093","360","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("2094","360","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("2095","360","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("2096","360","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("2097","360","gmapes","a:3:{s:7:\"address\";s:0:\"\";s:3:\"lat\";s:18:\"45.793602986946546\";s:3:\"lng\";s:17:\"4.823034139731476\";}");
INSERT INTO `yucqn_postmeta` VALUES("2098","360","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("2100","361","galerie","a:2:{i:0;s:3:\"308\";i:1;s:3:\"307\";}");
INSERT INTO `yucqn_postmeta` VALUES("2101","361","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("2102","361","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("2103","361","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("2104","361","completed_on","");
INSERT INTO `yucqn_postmeta` VALUES("2105","361","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("2106","361","size_of_the_scene","");
INSERT INTO `yucqn_postmeta` VALUES("2107","361","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("2108","361","size_of_the_frame","");
INSERT INTO `yucqn_postmeta` VALUES("2109","361","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("2110","361","gmapes","a:3:{s:7:\"address\";s:0:\"\";s:3:\"lat\";s:18:\"53.848654392082324\";s:3:\"lng\";s:19:\"-23.164559873356666\";}");
INSERT INTO `yucqn_postmeta` VALUES("2111","361","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("2112","362","_edit_lock","1540634250:1");
INSERT INTO `yucqn_postmeta` VALUES("2113","362","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("2115","362","_yoast_wpseo_content_score","60");
INSERT INTO `yucqn_postmeta` VALUES("2116","362","_yoast_wpseo_primary_category","3");
INSERT INTO `yucqn_postmeta` VALUES("2118","364","link","http://www.model-scene.com/");
INSERT INTO `yucqn_postmeta` VALUES("2119","364","_link","field_5a8c42d32b5a2");
INSERT INTO `yucqn_postmeta` VALUES("2120","362","link","http://www.model-scene.com/");
INSERT INTO `yucqn_postmeta` VALUES("2121","362","_link","field_5a8c42d32b5a2");
INSERT INTO `yucqn_postmeta` VALUES("2122","366","_edit_lock","1542653535:1");
INSERT INTO `yucqn_postmeta` VALUES("2123","366","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("2124","367","_wp_attached_file","2018/11/carre.jpg");
INSERT INTO `yucqn_postmeta` VALUES("2125","367","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:17:\"2018/11/carre.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"carre-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"carre-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:17:\"carre-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("2126","368","_wp_attached_file","2018/11/wavebreaker_2.jpg");
INSERT INTO `yucqn_postmeta` VALUES("2127","368","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:25:\"2018/11/wavebreaker_2.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"wavebreaker_2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"wavebreaker_2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"wavebreaker_2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:27:\"wavebreaker_2-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("2130","370","_wp_attached_file","2018/11/wavebreaker_1.jpg");
INSERT INTO `yucqn_postmeta` VALUES("2131","370","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:25:\"2018/11/wavebreaker_1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"wavebreaker_1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"wavebreaker_1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"wavebreaker_1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:27:\"wavebreaker_1-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("2132","366","_thumbnail_id","367");
INSERT INTO `yucqn_postmeta` VALUES("2134","371","galerie","a:3:{i:0;s:3:\"368\";i:1;s:3:\"369\";i:2;s:3:\"370\";}");
INSERT INTO `yucqn_postmeta` VALUES("2135","371","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("2136","371","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("2137","371","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("2138","371","completed_on","20181118");
INSERT INTO `yucqn_postmeta` VALUES("2139","371","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("2140","371","size_of_the_scene","14");
INSERT INTO `yucqn_postmeta` VALUES("2141","371","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("2142","371","size_of_the_frame","9");
INSERT INTO `yucqn_postmeta` VALUES("2143","371","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("2144","371","gmapes","a:3:{s:7:\"address\";s:0:\"\";s:3:\"lat\";s:17:\"38.14521785053591\";s:3:\"lng\";s:18:\"13.386721763944479\";}");
INSERT INTO `yucqn_postmeta` VALUES("2145","371","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("2146","366","galerie","a:3:{i:0;s:3:\"368\";i:1;s:3:\"370\";i:2;s:3:\"373\";}");
INSERT INTO `yucqn_postmeta` VALUES("2147","366","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("2148","366","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("2149","366","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("2150","366","completed_on","20181118");
INSERT INTO `yucqn_postmeta` VALUES("2151","366","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("2152","366","size_of_the_scene","14");
INSERT INTO `yucqn_postmeta` VALUES("2153","366","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("2154","366","size_of_the_frame","9");
INSERT INTO `yucqn_postmeta` VALUES("2155","366","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("2156","366","gmapes","a:3:{s:7:\"address\";s:18:\"Civitavecchia Port\";s:3:\"lat\";s:18:\"41.743903635196304\";s:3:\"lng\";s:18:\"12.223029289579245\";}");
INSERT INTO `yucqn_postmeta` VALUES("2157","366","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("2160","373","_wp_attached_file","2018/11/wavebreaker_3.jpg");
INSERT INTO `yucqn_postmeta` VALUES("2161","373","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:25:\"2018/11/wavebreaker_3.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"wavebreaker_3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"wavebreaker_3-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"wavebreaker_3-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:27:\"wavebreaker_3-1024x1024.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("2163","374","galerie","a:3:{i:0;s:3:\"368\";i:1;s:3:\"370\";i:2;s:3:\"373\";}");
INSERT INTO `yucqn_postmeta` VALUES("2164","374","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("2165","374","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("2166","374","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("2167","374","completed_on","20181118");
INSERT INTO `yucqn_postmeta` VALUES("2168","374","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("2169","374","size_of_the_scene","14");
INSERT INTO `yucqn_postmeta` VALUES("2170","374","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("2171","374","size_of_the_frame","9");
INSERT INTO `yucqn_postmeta` VALUES("2172","374","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("2173","374","gmapes","a:3:{s:7:\"address\";s:0:\"\";s:3:\"lat\";s:17:\"38.14521785053591\";s:3:\"lng\";s:18:\"13.386721763944479\";}");
INSERT INTO `yucqn_postmeta` VALUES("2174","374","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("2176","375","galerie","a:3:{i:0;s:3:\"368\";i:1;s:3:\"370\";i:2;s:3:\"373\";}");
INSERT INTO `yucqn_postmeta` VALUES("2177","375","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("2178","375","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("2179","375","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("2180","375","completed_on","20181118");
INSERT INTO `yucqn_postmeta` VALUES("2181","375","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("2182","375","size_of_the_scene","14");
INSERT INTO `yucqn_postmeta` VALUES("2183","375","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("2184","375","size_of_the_frame","9");
INSERT INTO `yucqn_postmeta` VALUES("2185","375","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("2186","375","gmapes","a:3:{s:7:\"address\";s:0:\"\";s:3:\"lat\";s:17:\"38.14521785053591\";s:3:\"lng\";s:18:\"13.386721763944479\";}");
INSERT INTO `yucqn_postmeta` VALUES("2187","375","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("2189","376","galerie","a:3:{i:0;s:3:\"368\";i:1;s:3:\"370\";i:2;s:3:\"373\";}");
INSERT INTO `yucqn_postmeta` VALUES("2190","376","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("2191","376","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("2192","376","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("2193","376","completed_on","20181118");
INSERT INTO `yucqn_postmeta` VALUES("2194","376","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("2195","376","size_of_the_scene","14");
INSERT INTO `yucqn_postmeta` VALUES("2196","376","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("2197","376","size_of_the_frame","9");
INSERT INTO `yucqn_postmeta` VALUES("2198","376","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("2199","376","gmapes","a:3:{s:7:\"address\";s:0:\"\";s:3:\"lat\";s:17:\"38.14521785053591\";s:3:\"lng\";s:18:\"13.386721763944479\";}");
INSERT INTO `yucqn_postmeta` VALUES("2200","376","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("2202","377","galerie","a:3:{i:0;s:3:\"368\";i:1;s:3:\"370\";i:2;s:3:\"373\";}");
INSERT INTO `yucqn_postmeta` VALUES("2203","377","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("2204","377","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("2205","377","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("2206","377","completed_on","20181118");
INSERT INTO `yucqn_postmeta` VALUES("2207","377","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("2208","377","size_of_the_scene","14");
INSERT INTO `yucqn_postmeta` VALUES("2209","377","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("2210","377","size_of_the_frame","9");
INSERT INTO `yucqn_postmeta` VALUES("2211","377","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("2212","377","gmapes","a:3:{s:7:\"address\";s:18:\"Civitavecchia Port\";s:3:\"lat\";s:18:\"41.743903635196304\";s:3:\"lng\";s:18:\"12.223029289579245\";}");
INSERT INTO `yucqn_postmeta` VALUES("2213","377","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("2214","379","_edit_lock","1548667829:1");
INSERT INTO `yucqn_postmeta` VALUES("2215","380","_wp_attached_file","2019/01/bmwe21-1.png");
INSERT INTO `yucqn_postmeta` VALUES("2216","380","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:20:\"2019/01/bmwe21-1.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"bmwe21-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"bmwe21-1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"bmwe21-1-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"bmwe21-1-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("2217","381","_wp_attached_file","2019/01/bmwe21-2.png");
INSERT INTO `yucqn_postmeta` VALUES("2218","381","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:20:\"2019/01/bmwe21-2.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"bmwe21-2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"bmwe21-2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"bmwe21-2-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"bmwe21-2-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("2219","382","_wp_attached_file","2019/01/bmwe21-3.png");
INSERT INTO `yucqn_postmeta` VALUES("2220","382","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1132;s:4:\"file\";s:20:\"2019/01/bmwe21-3.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"bmwe21-3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"bmwe21-3-300x283.png\";s:5:\"width\";i:300;s:6:\"height\";i:283;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"bmwe21-3-768x724.png\";s:5:\"width\";i:768;s:6:\"height\";i:724;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"bmwe21-3-1024x966.png\";s:5:\"width\";i:1024;s:6:\"height\";i:966;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("2221","383","_wp_attached_file","2019/01/bmwe21-4.png");
INSERT INTO `yucqn_postmeta` VALUES("2222","383","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:20:\"2019/01/bmwe21-4.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"bmwe21-4-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"bmwe21-4-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"bmwe21-4-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"bmwe21-4-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("2223","384","_wp_attached_file","2019/01/square.png");
INSERT INTO `yucqn_postmeta` VALUES("2224","384","_wp_attachment_metadata","a:5:{s:5:\"width\";i:471;s:6:\"height\";i:471;s:4:\"file\";s:18:\"2019/01/square.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"square-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"square-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `yucqn_postmeta` VALUES("2225","384","_wp_attachment_image_alt","BMW E21 1/35 diorama");
INSERT INTO `yucqn_postmeta` VALUES("2226","379","_edit_last","1");
INSERT INTO `yucqn_postmeta` VALUES("2227","379","_thumbnail_id","384");
INSERT INTO `yucqn_postmeta` VALUES("2229","385","galerie","a:4:{i:0;s:3:\"382\";i:1;s:3:\"380\";i:2;s:3:\"381\";i:3;s:3:\"383\";}");
INSERT INTO `yucqn_postmeta` VALUES("2230","385","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("2231","385","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("2232","385","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("2233","385","completed_on","20190126");
INSERT INTO `yucqn_postmeta` VALUES("2234","385","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("2235","385","size_of_the_scene","12cm");
INSERT INTO `yucqn_postmeta` VALUES("2236","385","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("2237","385","size_of_the_frame","9cm");
INSERT INTO `yucqn_postmeta` VALUES("2238","385","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("2239","385","gmapes","a:3:{s:7:\"address\";s:5:\"mainz\";s:3:\"lat\";s:17:\"49.96846306928141\";s:3:\"lng\";s:18:\"10.829502912640805\";}");
INSERT INTO `yucqn_postmeta` VALUES("2240","385","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("2241","379","galerie","a:4:{i:0;s:3:\"382\";i:1;s:3:\"380\";i:2;s:3:\"381\";i:3;s:3:\"383\";}");
INSERT INTO `yucqn_postmeta` VALUES("2242","379","_galerie","field_5a8c46f182839");
INSERT INTO `yucqn_postmeta` VALUES("2243","379","vendu","0");
INSERT INTO `yucqn_postmeta` VALUES("2244","379","_vendu","field_5a8c47958283a");
INSERT INTO `yucqn_postmeta` VALUES("2245","379","completed_on","20190126");
INSERT INTO `yucqn_postmeta` VALUES("2246","379","_completed_on","field_5a8c47b38283b");
INSERT INTO `yucqn_postmeta` VALUES("2247","379","size_of_the_scene","12cm");
INSERT INTO `yucqn_postmeta` VALUES("2248","379","_size_of_the_scene","field_5a8c47da8283c");
INSERT INTO `yucqn_postmeta` VALUES("2249","379","size_of_the_frame","9cm");
INSERT INTO `yucqn_postmeta` VALUES("2250","379","_size_of_the_frame","field_5a8c47ee8283d");
INSERT INTO `yucqn_postmeta` VALUES("2251","379","gmapes","a:3:{s:7:\"address\";s:5:\"mainz\";s:3:\"lat\";s:17:\"49.96846306928141\";s:3:\"lng\";s:18:\"10.829502912640805\";}");
INSERT INTO `yucqn_postmeta` VALUES("2252","379","_gmapes","field_5aa2bbaaef6f0");
INSERT INTO `yucqn_postmeta` VALUES("2253","388","_edit_lock","1548668846:1");


DROP TABLE IF EXISTS `yucqn_posts`;

CREATE TABLE `yucqn_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=402 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `yucqn_posts` VALUES("5","1","2018-02-20 16:47:26","2018-02-20 15:47:26","","Link","","publish","closed","closed","","acf_link","","","2018-02-21 18:33:15","2018-02-21 17:33:15","","0","http://dswp.local/?post_type=acf&#038;p=5","0","acf","","0");
INSERT INTO `yucqn_posts` VALUES("6","1","2018-02-20 16:48:00","2018-02-20 15:48:00","Where it all began","JBA Diorama","","publish","open","open","","jba-diorama","","","2018-02-21 18:37:52","2018-02-21 17:37:52","","0","http://dswp.local/?p=6","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("7","1","2018-02-20 16:48:00","2018-02-20 15:48:00","","JBA Diorama","","inherit","closed","closed","","6-revision-v1","","","2018-02-20 16:48:00","2018-02-20 15:48:00","","6","http://dswp.local/2018/02/20/6-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("9","1","2018-02-20 16:51:39","2018-02-20 15:51:39","This website shows the nature centered dioramas I have been building throughout the last part of 2017 and in 2018.

The rules of the game are pretty simple : I bought a series of 3d boxes and I fill them with little scenes that must not be more than 2cm high. I must build those pretty fast so as not to loose interest too.

I have a lot of experience concerning the creation of nature in scale as well as the sea coming from my not so science fiction not so highly historical dioramas, the point here is to focus on only the nature part of my work.

I also try to follow the seasons like for instance showing a pond with shriveled lilies in winter as well as decayed leaves.

I get some wonderful energies working on this stuff, it\'s quite a zen thing, really relaxing -indeed while building those I found out my work had some appeal to a much wider audience than I ever had

So the plan for 2018 is to have roughly 20 of those that I could show on an exhibition. But those tend to be quite successful indeed and I have been selling quite a few of them.

And that\'s the idea here: those things are easy to pack and to dispatch. They can be on your mantelpiece for not such a fortune, please contact me!

For the other stuff I do, please have a look on my other website <a href=\"http://www.jbadiorama.com\" target=\"_blank\" rel=\"noopener\">www.jbadiorama.com</a>","About/ Contact/ Links","","publish","closed","closed","","about","","","2018-03-09 12:28:24","2018-03-09 11:28:24","","0","http://dswp.local/?page_id=9","0","page","","0");
INSERT INTO `yucqn_posts` VALUES("10","1","2018-02-20 16:51:39","2018-02-20 15:51:39","My name is Jean Diorama, I am French but that\'s irrevelant, I was born in 1970, I speak English and a little German and always liked to be on my own.

I created my first true diorama one day of September 1979 with some Airfix 1/72 soft plastic figs and a cardboard made British Churchill tank complete with static grass used for railway modelling. This started a long series of mostly world war two 1/72 dioramas that ended up when I found out that this kind of warlike hobby was really unfashionable with girls, so I wisely slipped to Science fiction stuff, I was still probably seen as being a creep but at least not a dangerous one anymore.

I built my Games Workshop figs and dioramas for quite some time, but then around University I started to really slip from conventional scenes to more abstract stuff using some Prince August Middle Earth figs. I eventually found out that I could empty my mind and express a lot of feelings in my dioramas, and I started to literary pour my life into these.

From purely historic or movies inspiration, my ideas I found while listening to music. From 1/72 or 1/48, I finally switched to the 1/35 scale when I realized that it was the perfect scale for human drama.

I then realized I wanted a complete freedom with my dioramas; relativize the whole idea of \"accuracy\" and generally speaking suffer no artificial limitation in my hobby.

Back after the military service, I started to build dioramas in 1/35. The mood of my dioramas had significantly lifted during those years but a rather chaotic life led me to cast a dark shadow over my work which quite a few years later is still there even though I run a rather happy life these days.

At one point (after Abbey, Untitled 3 and the subsequent one that I still didn\'t photographed) I fell I was reaching a dead end and the quality of my work plummeted. So much indeed that I put the 2 last of the series to the dustbin. Then I stopped modelling. This was fortunate as I had met my wife, changed town and learned stuff in order to pay the rent in a better way than before.

Though the pause ran for 5 years from 2000 to 2005, I never really stop to model in my head, so when i started back again the new ideas were there, there was new tricks I had devised and my will was further fed with a lot of revenge.

My ideas had evolve. Indeed I tried to get more subtle about those. I realized I didn\'t like any more being tagged \"SF\" or \"ships\" or or whatever, my new world was to be set in some historical past but slightly warped. Guys into SF would like my stuff because of the otherworldly moods, guys into boats or whatever would like the dioramas because I am dead accurate. In the meantime I started a process which would lead me at some point to stop completely relying on products available on the market models or figures.

These days my main goal is to completely evade from the traditional modelling schemes. I don\'t evne care anymore to tell stories with my dioramas. I am now into moods, I want those to be strong enough that my dioramas could appeal to a much wider public than the modelling world.","About","","inherit","closed","closed","","9-revision-v1","","","2018-02-20 16:51:39","2018-02-20 15:51:39","","9","http://dswp.local/2018/02/20/9-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("11","1","2018-02-20 17:08:48","2018-02-20 16:08:48","","Diorama","","publish","closed","closed","","acf_diorama","","","2018-03-09 17:52:22","2018-03-09 16:52:22","","0","http://dswp.local/?post_type=acf&#038;p=11","0","acf","","0");
INSERT INTO `yucqn_posts` VALUES("12","1","2018-02-20 17:13:20","2018-02-20 16:13:20","","1","","inherit","open","closed","","1","","","2018-02-20 17:13:20","2018-02-20 16:13:20","","0","http://dswp.local/wp-content/uploads/2018/02/1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("13","1","2018-02-20 17:13:22","2018-02-20 16:13:22","","2","","inherit","open","closed","","2","","","2018-02-20 17:13:22","2018-02-20 16:13:22","","0","http://dswp.local/wp-content/uploads/2018/02/2.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("14","1","2018-02-20 17:13:24","2018-02-20 16:13:24","","3","","inherit","open","closed","","3","","","2018-02-20 17:13:24","2018-02-20 16:13:24","","0","http://dswp.local/wp-content/uploads/2018/02/3.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("15","1","2018-02-20 17:13:48","2018-02-20 16:13:48","","1","","inherit","open","closed","","1-2","","","2018-02-20 17:13:48","2018-02-20 16:13:48","","0","http://dswp.local/wp-content/uploads/2018/02/1-1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("16","1","2018-02-20 17:13:50","2018-02-20 16:13:50","","2","","inherit","open","closed","","2-2","","","2018-02-20 17:13:50","2018-02-20 16:13:50","","0","http://dswp.local/wp-content/uploads/2018/02/2-1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("17","1","2018-02-20 17:13:51","2018-02-20 16:13:51","","3","","inherit","open","closed","","3-2","","","2018-02-20 17:13:51","2018-02-20 16:13:51","","0","http://dswp.local/wp-content/uploads/2018/02/3-1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("18","1","2018-02-20 17:13:53","2018-02-20 16:13:53","","4","","inherit","open","closed","","4","","","2018-02-20 17:13:53","2018-02-20 16:13:53","","0","http://dswp.local/wp-content/uploads/2018/02/4.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("23","1","2018-02-20 17:14:41","2018-02-20 16:14:41","","g1","","inherit","open","closed","","g1","","","2018-02-20 17:14:41","2018-02-20 16:14:41","","0","http://dswp.local/wp-content/uploads/2018/02/g1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("24","1","2018-02-20 17:14:43","2018-02-20 16:14:43","","g2","","inherit","open","closed","","g2","","","2018-02-20 17:14:43","2018-02-20 16:14:43","","0","http://dswp.local/wp-content/uploads/2018/02/g2.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("25","1","2018-02-20 17:14:45","2018-02-20 16:14:45","","g3","","inherit","open","closed","","g3","","","2018-02-20 17:14:45","2018-02-20 16:14:45","","0","http://dswp.local/wp-content/uploads/2018/02/g3.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("26","1","2018-02-20 17:14:47","2018-02-20 16:14:47","","g4","","inherit","open","closed","","g4","","","2018-02-20 17:14:47","2018-02-20 16:14:47","","0","http://dswp.local/wp-content/uploads/2018/02/g4.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("29","1","2018-02-20 17:17:50","2018-02-20 16:17:50","","_MG_0915","","inherit","open","closed","","_mg_0915","","","2018-02-20 17:17:50","2018-02-20 16:17:50","","0","http://dswp.local/wp-content/uploads/2018/02/MG_0915.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("30","1","2018-02-20 17:17:53","2018-02-20 16:17:53","","_MG_0928","","inherit","open","closed","","_mg_0928","","","2018-02-20 17:17:53","2018-02-20 16:17:53","","0","http://dswp.local/wp-content/uploads/2018/02/MG_0928.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("31","1","2018-02-20 17:17:55","2018-02-20 16:17:55","","_MG_0930","","inherit","open","closed","","_mg_0930","","","2018-02-20 17:17:55","2018-02-20 16:17:55","","0","http://dswp.local/wp-content/uploads/2018/02/MG_0930.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("32","1","2018-02-20 17:26:21","2018-02-20 16:26:21","I gave out the first of that series to someone who is very dear to me and I was suddenly deprived of my first diorama, the only one with true saturated colors I did so far.

As I still had the form I used for it (silicon one, reusable), I decided to do a new one while saturating the colors even more and to get a more uniform color of the sea.

In order to create a nice hot-spot I also darkened the place where the two waves meet..

Well that one was sold pretty fast as well so I will be trying out a third version with yet different colors soon.","Just the Sea 1 #2","","publish","open","open","","just-the-sea-1-2","","","2018-05-07 18:35:53","2018-05-07 16:35:53","","0","http://dswp.local/?p=32","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("33","1","2018-02-20 17:26:21","2018-02-20 16:26:21","Modeling paste over cardboard, resin form and acrylic gel.

I wanted to get more saturated colours than usual","Just the Sea 1 #2","","inherit","closed","closed","","32-revision-v1","","","2018-02-20 17:26:21","2018-02-20 16:26:21","","32","http://dswp.local/2018/02/20/32-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("34","1","2018-02-20 17:27:59","2018-02-20 16:27:59","<div dir=\"auto\">This website is a side project -it shows the nature centered dioramas I have been building throughout the last part of 2017 and in 2018.</div>
<div dir=\"auto\">The rules of the game are pretty simple : I bought a series of 3d boxes and I fill them with little scenes that must not be more than 2cm high. I must build those pretty fast so as not to loose interest too. I focus on nature and sea shores..</div>
<div dir=\"auto\"></div>","Distant Shores","","publish","closed","closed","","distant-shores","","","2018-05-23 16:28:21","2018-05-23 14:28:21","","0","http://dswp.local/?page_id=34","0","page","","0");
INSERT INTO `yucqn_posts` VALUES("35","1","2018-02-20 17:27:59","2018-02-20 16:27:59","","Accueil","","inherit","closed","closed","","34-revision-v1","","","2018-02-20 17:27:59","2018-02-20 16:27:59","","34","http://dswp.local/2018/02/20/34-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("36","1","2018-02-20 17:30:20","2018-02-20 16:30:20","","lk1","","inherit","open","closed","","lk1","","","2018-02-20 17:30:20","2018-02-20 16:30:20","","0","http://dswp.local/wp-content/uploads/2018/02/lk1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("37","1","2018-02-20 17:30:22","2018-02-20 16:30:22","","lk2","","inherit","open","closed","","lk2","","","2018-02-20 17:30:22","2018-02-20 16:30:22","","0","http://dswp.local/wp-content/uploads/2018/02/lk2.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("39","1","2018-02-20 17:30:25","2018-02-20 16:30:25","","lk3","","inherit","open","closed","","lk3","","","2018-02-20 17:30:25","2018-02-20 16:30:25","","0","http://dswp.local/wp-content/uploads/2018/02/lk3.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("44","1","2018-02-20 17:52:29","2018-02-20 16:52:29","","Homepage","","publish","closed","closed","","acf_homepage","","","2018-05-23 16:27:27","2018-05-23 14:27:27","","0","http://dswp.local/?post_type=acf&#038;p=44","0","acf","","0");
INSERT INTO `yucqn_posts` VALUES("45","1","2018-02-22 10:25:56","2018-02-22 09:25:56","<div dir=\"auto\">This website shows the nature centered dioramas I have been building throughout the last part of 2017 and in 2018.</div>
<div dir=\"auto\">The rules of the game are pretty simple : I bought a series of 3d boxes and I fill them with little scenes that must not be more than 2cm high. I must build those pretty fast so as not to loose interest too. I focus on nature</div>
<div dir=\"auto\">I have a lot of experience concerning the creation of nature in scale as well as the sea coming from my not so science fiction not so highly historical dioramas, the point here is to focus on only the nature part of my work. I also try to follow the seasons like for instance showing a pond with shriveled lilies in winter as well as decayed leaves.</div>
<div dir=\"auto\">I get some wonderful énergies working on this stuff, it\'s quite a zen thing, really relaxing.</div>
<div dir=\"auto\">while building those I found out my work had some appeal to a much wider audience than I ever had</div>
<div dir=\"auto\">So the plan for 2018 is to have roughly 20 of those that I could show on an exhibition. But those tend to be quite successful indeed and I have been selling quite a few of them.</div>
<div dir=\"auto\">And that\'s the idea here :those things are easy to pack and easy to dispatch. They can be on your mantelpiece for not such a fortune, please contact me!</div>
<div dir=\"auto\">For the other stuff I do, please have a look</div>","SEA Diorama","","inherit","closed","closed","","34-autosave-v1","","","2018-02-22 10:25:56","2018-02-22 09:25:56","","34","http://dswp.local/2018/02/20/34-autosave-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("46","1","2018-02-20 17:57:00","2018-02-20 16:57:00","Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae placeat maiores mollitia quisquam eligendi explicabo earum aliquid, tempora, cum incidunt aspernatur eveniet? Sapiente eius, ab assumenda necessitatibus nam, error animi.","SEA Diorama","","inherit","closed","closed","","34-revision-v1","","","2018-02-20 17:57:00","2018-02-20 16:57:00","","34","http://dswp.local/2018/02/20/34-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("48","1","2018-02-20 18:02:45","2018-02-20 17:02:45","<div dir=\"auto\">Ever since I am a small kid I have been fascinated by marshes, ponds you name it.</div>
<div dir=\"auto\">I remember when I was a kid going in full winter near a small lake which had been emptied and the guys were picking up the fishes like they would have gather apples..</div>
<div dir=\"auto\">The whole place was shrouded in mystery and I loved that.</div>
<div dir=\"auto\">But this fascination had their limits.</div>
<div dir=\"auto\">For once I never seem to a have had the right shoes to get close enough so I got to catch a glimpse of the edge of the water through a gap between reeds.</div>
<div dir=\"auto\">Now I can enjoy a bird view of just that.</div>","Winter Marsh","","publish","open","open","","winter-marsh","","","2018-05-07 18:35:45","2018-05-07 16:35:45","","0","http://dswp.local/?p=48","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("49","1","2018-02-20 18:02:08","2018-02-20 17:02:08","Reeds done out of paper, various bits of mud a","Winter Marsh","","inherit","closed","closed","","48-revision-v1","","","2018-02-20 18:02:08","2018-02-20 17:02:08","","48","http://dswp.local/2018/02/20/48-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("50","1","2018-02-20 18:02:45","2018-02-20 17:02:45","Reeds done out of paper, various bits of mud and sand embeded in acrylic gels, lilies for my winter pond. The diorama is mostly transparent","Winter Marsh","","inherit","closed","closed","","48-revision-v1","","","2018-02-20 18:02:45","2018-02-20 17:02:45","","48","http://dswp.local/2018/02/20/48-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("52","1","2018-02-20 18:05:48","2018-02-20 17:05:48","","jean_diorama_BdatBxWl6UM","","inherit","open","closed","","jean_diorama_bdatbxwl6um","","","2018-02-20 18:05:48","2018-02-20 17:05:48","","0","http://dswp.local/wp-content/uploads/2018/02/jean_diorama_BdatBxWl6UM.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("53","1","2018-02-20 18:05:49","2018-02-20 17:05:49","","jean_diorama_BdatBddF5K4","","inherit","open","closed","","jean_diorama_bdatbddf5k4","","","2018-02-20 18:05:49","2018-02-20 17:05:49","","0","http://dswp.local/wp-content/uploads/2018/02/jean_diorama_BdatBddF5K4.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("54","1","2018-02-20 18:05:51","2018-02-20 17:05:51","","jean_diorama_BdatBLXFDay","","inherit","open","closed","","jean_diorama_bdatblxfday","","","2018-02-20 18:05:51","2018-02-20 17:05:51","","0","http://dswp.local/wp-content/uploads/2018/02/jean_diorama_BdatBLXFDay.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("57","1","2018-02-20 20:59:59","2018-02-20 19:59:59"," ","","","publish","closed","closed","","57","","","2018-04-23 09:14:21","2018-04-23 07:14:21","","0","http://dswp.local/?p=57","3","nav_menu_item","","0");
INSERT INTO `yucqn_posts` VALUES("59","1","2018-02-21 17:54:16","2018-02-21 16:54:16","Quite simply the best paints around (warning those are lacquers)","Mr Paint","","publish","open","open","","mr-paint","","","2018-02-21 18:36:57","2018-02-21 17:36:57","","0","http://dswp.local/?p=59","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("60","1","2018-02-21 17:54:16","2018-02-21 16:54:16","","Mr Paint","","inherit","closed","closed","","59-revision-v1","","","2018-02-21 17:54:16","2018-02-21 16:54:16","","59","http://dswp.local/2018/02/21/59-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("61","1","2018-02-21 17:54:44","2018-02-21 16:54:44","Where I get the ready made laser cut leaves I sometimes use","Model Scene","","publish","open","open","","model-scene","","","2018-02-21 18:33:48","2018-02-21 17:33:48","","0","http://dswp.local/?p=61","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("62","1","2018-02-21 17:54:44","2018-02-21 16:54:44","","Model Scene","","inherit","closed","closed","","61-revision-v1","","","2018-02-21 17:54:44","2018-02-21 16:54:44","","61","http://dswp.local/2018/02/21/61-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("63","1","2018-02-21 18:33:48","2018-02-21 17:33:48","Where I get the ready made laser cut leaves I sometimes use","Model Scene","","inherit","closed","closed","","61-revision-v1","","","2018-02-21 18:33:48","2018-02-21 17:33:48","","61","http://dswp.local/2018/02/21/61-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("64","1","2018-02-21 18:36:57","2018-02-21 17:36:57","Quite simply the best paints around (warning those are lacquers)","Mr Paint","","inherit","closed","closed","","59-revision-v1","","","2018-02-21 18:36:57","2018-02-21 17:36:57","","59","http://dswp.local/2018/02/21/59-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("65","1","2018-02-21 18:37:52","2018-02-21 17:37:52","Where it all began","JBA Diorama","","inherit","closed","closed","","6-revision-v1","","","2018-02-21 18:37:52","2018-02-21 17:37:52","","6","http://dswp.local/2018/02/21/6-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("66","1","2018-02-21 20:28:01","2018-02-21 19:28:01","\"Yeah it\'s rather nice, the primary lines are good, but you missed the secondary ones\".
The art teacher leaves the room, I suddenly feel slightly depressed..

The sea in winter. Lots of fog a white atmosphere you can\'t see much not a lot of colors. I walk on the beach in Aquitaine, some white pine driftwood lies around.
I give it a kick so that I don\'t freeze too quickly. Oh beneath the baked cooked boiled surface lies a red wood whose color shines In the morning.","White shore","","publish","open","open","","white-shore","","","2018-05-07 18:35:37","2018-05-07 16:35:37","","0","http://dswp.local/?p=66","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("67","1","2018-02-21 20:25:07","2018-02-21 19:25:07","","gl1","","inherit","open","closed","","gl1","","","2018-02-21 20:25:33","2018-02-21 19:25:33","","66","http://dswp.local/wp-content/uploads/2018/02/gl1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("68","1","2018-02-21 20:25:08","2018-02-21 19:25:08","","gl2","","inherit","open","closed","","gl2","","","2018-02-21 20:25:08","2018-02-21 19:25:08","","66","http://dswp.local/wp-content/uploads/2018/02/gl2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("69","1","2018-02-21 20:25:10","2018-02-21 19:25:10","","gl3","","inherit","open","closed","","gl3","","","2018-02-21 20:25:10","2018-02-21 19:25:10","","66","http://dswp.local/wp-content/uploads/2018/02/gl3.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("70","1","2018-02-21 20:25:11","2018-02-21 19:25:11","","gl4","","inherit","open","closed","","gl4","","","2018-02-21 20:25:11","2018-02-21 19:25:11","","66","http://dswp.local/wp-content/uploads/2018/02/gl4.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("71","1","2018-02-21 20:28:01","2018-02-21 19:28:01","\"yeah it\'s rather nice, the primary lines are good, but you missed the secondary ones\".
The art teacher leaves the room, I suddenly feel slightly depressed","White shore","","inherit","closed","closed","","66-revision-v1","","","2018-02-21 20:28:01","2018-02-21 19:28:01","","66","http://dswp.local/2018/02/21/66-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("72","1","2018-02-21 20:39:50","2018-02-21 19:39:50","<div dir=\"auto\">So it happens my mom lives close to the Bassin d\'Arcachon which is located on Western France.</div>
<div dir=\"auto\">When the tide is low the sea almost leaves the whole place and you can see a limitless area of ooze. It can be quite dangerous too: when you walk too far in, the mud sucks your leg in and the place can transform itself in sort of not so quick sands.</div>
<div dir=\"auto\">Worse even when you sort of scratch this mud with the tip of the foot, you get it covered by a black gooey substance.</div>
<div dir=\"auto\">This is this kind of treacherous muddy beaches I wanted to reproduce here.</div>
<div dir=\"auto\">Of course there are no rocks on the Bassin darcachon but I could use a bit of extra drama.</div>","Muddy shore","","publish","open","open","","green-sea-shore","","","2018-05-07 18:35:17","2018-05-07 16:35:17","","0","http://dswp.local/?p=72","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("73","1","2018-02-21 20:39:03","2018-02-21 19:39:03","","seashore1","","inherit","open","closed","","seashore1","","","2018-02-21 20:39:03","2018-02-21 19:39:03","","72","http://dswp.local/wp-content/uploads/2018/02/seashore1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("74","1","2018-02-21 20:39:04","2018-02-21 19:39:04","","seashore2","","inherit","open","closed","","seashore2","","","2018-02-21 20:39:04","2018-02-21 19:39:04","","72","http://dswp.local/wp-content/uploads/2018/02/seashore2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("75","1","2018-02-21 20:39:05","2018-02-21 19:39:05","","seashore3","","inherit","open","closed","","seashore3","","","2018-02-21 20:39:05","2018-02-21 19:39:05","","72","http://dswp.local/wp-content/uploads/2018/02/seashore3.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("76","1","2018-02-21 20:39:06","2018-02-21 19:39:06","","seashore4","","inherit","open","closed","","seashore4","","","2018-02-21 20:39:06","2018-02-21 19:39:06","","72","http://dswp.local/wp-content/uploads/2018/02/seashore4.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("77","1","2018-02-21 20:39:08","2018-02-21 19:39:08","","seashore5","","inherit","open","closed","","seashore5","","","2018-02-21 20:39:08","2018-02-21 19:39:08","","72","http://dswp.local/wp-content/uploads/2018/02/seashore5.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("78","1","2018-02-21 20:39:50","2018-02-21 19:39:50","","Green Sea shore","","inherit","closed","closed","","72-revision-v1","","","2018-02-21 20:39:50","2018-02-21 19:39:50","","72","http://dswp.local/2018/02/21/72-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("79","1","2018-02-22 09:13:10","2018-02-22 08:13:10","","fd","","inherit","open","closed","","fd","","","2018-02-22 09:13:10","2018-02-22 08:13:10","","34","http://dswp.local/wp-content/uploads/2018/02/fd.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("80","1","2018-02-22 09:13:16","2018-02-22 08:13:16","Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae placeat maiores mollitia quisquam eligendi explicabo earum aliquid, tempora, cum incidunt aspernatur eveniet? Sapiente eius, ab assumenda necessitatibus nam, error animi.","SEA Diorama","","inherit","closed","closed","","34-revision-v1","","","2018-02-22 09:13:16","2018-02-22 08:13:16","","34","http://dswp.local/2018/02/22/34-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("81","1","2018-02-22 09:53:12","2018-02-22 08:53:12","<div dir=\"auto\">So it happens my mom lives close to the Bassin d\'Arcachon which is located on Western France.</div>
<div dir=\"auto\">When the tide is low the sea almost leaves the whole place and you can see a limitless area of ooze. It can be quite dangerous too: when you walk too far in, the mud sucks your leg in and the place can transform itself in sort of not so quick sands.</div>
<div dir=\"auto\">Worse even when you sort of scratch this mud with the foot it\'s often a black gooey substance that covers your feet.</div>
<div dir=\"auto\">This is this kind of treacherous muddy beaches I wanted to reproduce here.</div>
<div dir=\"auto\">Of course there are no rocks on the Bassin darcachon but I could use a bit of extra drama</div>","Green Sea shore","","inherit","closed","closed","","72-autosave-v1","","","2018-02-22 09:53:12","2018-02-22 08:53:12","","72","http://dswp.local/2018/02/22/72-autosave-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("82","1","2018-02-22 09:52:08","2018-02-22 08:52:08","<div dir=\"auto\">So it happens my mom lives on the bassin darcachon which is located on western France. When the tide is low the sea almost leaves the whole place and you can see an almost limitless area of mud. It can be quite dangerous too: when you walk too far in the mud sucks your leg in and the place can transform itself in sort of not so quick sands.</div>
<div dir=\"auto\">Worse even when you sort of scratch this mud with the foot it\'s often a black gooey substance that covers your feet.</div>
<div dir=\"auto\">This is this kind of treacherous muddy beaches I wanted to reproduce here.</div>
<div dir=\"auto\">Of course there are no rocks on the Bassin darcachon but I could use a bit of extra drama</div>","Green Sea shore","","inherit","closed","closed","","72-revision-v1","","","2018-02-22 09:52:08","2018-02-22 08:52:08","","72","http://dswp.local/2018/02/22/72-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("83","1","2018-02-22 09:54:12","2018-02-22 08:54:12","<div dir=\"auto\">So it happens my mom lives close to the Bassin d\'Arcachon which is located on Western France.</div>
<div dir=\"auto\">When the tide is low the sea almost leaves the whole place and you can see a limitless area of ooze. It can be quite dangerous too: when you walk too far in, the mud sucks your leg in and the place can transform itself in sort of not so quick sands.</div>
<div dir=\"auto\">Worse even when you sort of scratch this mud with the tip of the foot, you get it covered by a black gooey substance.</div>
<div dir=\"auto\">This is this kind of treacherous muddy beaches I wanted to reproduce here.</div>
<div dir=\"auto\">Of course there are no rocks on the Bassin darcachon but I could use a bit of extra drama.</div>","Green Sea shore","","inherit","closed","closed","","72-revision-v1","","","2018-02-22 09:54:12","2018-02-22 08:54:12","","72","http://dswp.local/2018/02/22/72-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("84","1","2018-02-22 09:54:29","2018-02-22 08:54:29","<div dir=\"auto\">So it happens my mom lives close to the Bassin d\'Arcachon which is located on Western France.</div>
<div dir=\"auto\">When the tide is low the sea almost leaves the whole place and you can see a limitless area of ooze. It can be quite dangerous too: when you walk too far in, the mud sucks your leg in and the place can transform itself in sort of not so quick sands.</div>
<div dir=\"auto\">Worse even when you sort of scratch this mud with the tip of the foot, you get it covered by a black gooey substance.</div>
<div dir=\"auto\">This is this kind of treacherous muddy beaches I wanted to reproduce here.</div>
<div dir=\"auto\">Of course there are no rocks on the Bassin darcachon but I could use a bit of extra drama.</div>","Muddy shore","","inherit","closed","closed","","72-revision-v1","","","2018-02-22 09:54:29","2018-02-22 08:54:29","","72","http://dswp.local/2018/02/22/72-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("85","1","2018-02-22 09:56:14","2018-02-22 08:56:14","<div dir=\"auto\">I gave out the first of that series to someone who is very dear to me and I was suddenly deprived of my first diorama, the only one with true saturated colors I did so far.</div>
<div dir=\"auto\">As I still had the form I used for it (silicon one, reusable), I decided to do a new one while saturating the colors even more and to get a more uniform color of the sea.</div>
<div dir=\"auto\">In order to create a nice hot-spot I also darkened the place where the two waves meet..</div>
<div dir=\"auto\">Well that one was sold pretty fast as well so I will be trying out a third version with yet different colors</div>","Just the Sea 1 #2","","inherit","closed","closed","","32-autosave-v1","","","2018-02-22 09:56:14","2018-02-22 08:56:14","","32","http://dswp.local/2018/02/22/32-autosave-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("86","1","2018-02-22 09:56:20","2018-02-22 08:56:20","<div dir=\"auto\">I gave out the first of that series to someone who is very dear to me and I was suddenly deprived of my first diorama, the only one with true saturated colors I did so far.</div>
<div dir=\"auto\">As I still had the form I used for it (silicon one, reusable), I decided to do a new one while saturating the colors even more and to get a more uniform color of the sea.</div>
<div dir=\"auto\">In order to create a nice hot-spot I also darkened the place where the two waves meet..</div>
<div dir=\"auto\">Well that one was sold pretty fast as well so I will be trying out a third version with yet different colors soon.</div>","Just the Sea 1 #2","","inherit","closed","closed","","32-revision-v1","","","2018-02-22 09:56:20","2018-02-22 08:56:20","","32","http://dswp.local/2018/02/22/32-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("87","1","2018-02-22 09:58:11","2018-02-22 08:58:11","\"yeah it\'s rather nice, the primary lines are good, but you missed the secondary ones\".
The art teacher leaves the room, I suddenly feel slightly depressed..

The sea in winter. Lots of fog a white atmosphere you can\'t see much not a lot of colors. I walk on the beach in Aquitaine, some white pine driftwood lies around.
I give it a kick so that I don\'t freeze too quickly. Oh beneath the baked cooked boiled surface lies a red wood whose color shines In the morning.","White shore","","inherit","closed","closed","","66-revision-v1","","","2018-02-22 09:58:11","2018-02-22 08:58:11","","66","http://dswp.local/2018/02/22/66-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("88","1","2018-02-22 09:58:20","2018-02-22 08:58:20","\"Yeah it\'s rather nice, the primary lines are good, but you missed the secondary ones\".
The art teacher leaves the room, I suddenly feel slightly depressed..

The sea in winter. Lots of fog a white atmosphere you can\'t see much not a lot of colors. I walk on the beach in Aquitaine, some white pine driftwood lies around.
I give it a kick so that I don\'t freeze too quickly. Oh beneath the baked cooked boiled surface lies a red wood whose color shines In the morning.","White shore","","inherit","closed","closed","","66-revision-v1","","","2018-02-22 09:58:20","2018-02-22 08:58:20","","66","http://dswp.local/2018/02/22/66-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("89","1","2018-02-22 09:59:56","2018-02-22 08:59:56","<div dir=\"auto\">Ever since I am a small kid I have been fascinated by marshes, ponds you name it.</div>
<div dir=\"auto\">I remember when I was a kid going in full winter near a small lake which had been emptied and the guys were picking up the fishes like they would have gather apples..</div>
<div dir=\"auto\">The whole place was shrouded in mystery and I loved that.</div>
<div dir=\"auto\">But this fascination had their limits.</div>
<div dir=\"auto\">For once I never seem to a have had the right shoes to get close enough so I got to catch a glimpse of the edge of the water through a gap between reeds.</div>
<div dir=\"auto\">Now I can enjoy a bird view of just that.</div>","Winter Marsh","","inherit","closed","closed","","48-autosave-v1","","","2018-02-22 09:59:56","2018-02-22 08:59:56","","48","http://dswp.local/2018/02/22/48-autosave-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("90","1","2018-02-22 10:00:11","2018-02-22 09:00:11","<div dir=\"auto\">Ever since I am a small kid I have been fascinated by marshes, ponds you name it.</div>
<div dir=\"auto\">I remember when I was a kid going in full winter near a small lake which had been emptied and the guys were picking up the fishes like they would have gather apples..</div>
<div dir=\"auto\">The whole place was shrouded in mystery and I loved that.</div>
<div dir=\"auto\">But this fascination had their limits.</div>
<div dir=\"auto\">For once I never seem to a have had the right shoes to get close enough so I got to catch a glimpse of the edge of the water through a gap between reeds.</div>
<div dir=\"auto\">Now I can enjoy a bird view of just that.</div>","Winter Marsh","","inherit","closed","closed","","48-revision-v1","","","2018-02-22 10:00:11","2018-02-22 09:00:11","","48","http://dswp.local/2018/02/22/48-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("91","1","2018-02-22 10:01:14","2018-02-22 09:01:14","\"Yeah it\'s rather nice, the primary lines are good, but you missed the secondary ones\".
The art teacher leaves the room, I suddenly feel slightly depressed..

The sea in winter. Lots of fog a white atmosphere you can\'t see much not a lot of colors. I walk on the beach in Aquitaine, some white pine driftwood lies around.
I give it a kick so that I don\'t freeze too quickly. Oh beneath the baked cooked boiled surface lies a red wood whose color shines In the morning.","White shore","","inherit","closed","closed","","66-revision-v1","","","2018-02-22 10:01:14","2018-02-22 09:01:14","","66","http://dswp.local/2018/02/22/66-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("92","1","2018-02-22 10:01:32","2018-02-22 09:01:32","\"Yeah it\'s rather nice, the primary lines are good, but you missed the secondary ones\".
The art teacher leaves the room, I suddenly feel slightly depressed..

The sea in winter. Lots of fog a white atmosphere you can\'t see much not a lot of colors. I walk on the beach in Aquitaine, some white pine driftwood lies around.
I give it a kick so that I don\'t freeze too quickly. Oh beneath the baked cooked boiled surface lies a red wood whose color shines In the morning.","White shore","","inherit","closed","closed","","66-revision-v1","","","2018-02-22 10:01:32","2018-02-22 09:01:32","","66","http://dswp.local/2018/02/22/66-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("93","1","2018-02-22 10:03:37","2018-02-22 09:03:37","","Saint Laurent","","publish","open","open","","saint-laurent","","","2018-05-07 18:35:10","2018-05-07 16:35:10","","0","http://dswp.local/?p=93","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("94","1","2018-02-22 10:03:37","2018-02-22 09:03:37","","Saint Laurent","","inherit","closed","closed","","93-revision-v1","","","2018-02-22 10:03:37","2018-02-22 09:03:37","","93","http://dswp.local/2018/02/22/93-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("95","1","2018-02-22 10:05:42","2018-02-22 09:05:42","Aivazovski is not the best painter in history but I think he was my work\'s major influence at some point.

I like it all, the colors, the shape, the movement, the historical frame,  the drama.

Here is a typical diorama inspired by his work. I still have a lot of work to reach the level of his small footnail though.

Yet it works, happy about the foam as well as transparency.","Aivazovsky","","publish","open","open","","aivazovsky","","","2018-05-07 18:34:58","2018-05-07 16:34:58","","0","http://dswp.local/?p=95","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("96","1","2018-02-22 10:05:42","2018-02-22 09:05:42","","Aivazovsky","","inherit","closed","closed","","95-revision-v1","","","2018-02-22 10:05:42","2018-02-22 09:05:42","","95","http://dswp.local/2018/02/22/95-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("97","1","2018-02-22 10:09:33","2018-02-22 09:09:33","One of the lesser of the series I suppose? I should work on it again. The colors are good and make it for a rather uneventful water scape. Something has to be done! Watch this space!","Top of  the Lake","","publish","open","open","","top-of-the-lake","","","2018-05-07 18:34:50","2018-05-07 16:34:50","","0","http://dswp.local/?p=97","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("98","1","2018-02-22 10:09:33","2018-02-22 09:09:33","","Top of  the lake","","inherit","closed","closed","","97-revision-v1","","","2018-02-22 10:09:33","2018-02-22 09:09:33","","97","http://dswp.local/2018/02/22/97-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("99","1","2018-02-22 10:11:04","2018-02-22 09:11:04","Dreary humid, foggy autumn and then the yellow leaves fall in the river filled with pure water as renewed by the countless scattered showers. I feel both cold and happy when looking at that one.","Brook in autumn","","publish","open","open","","brook-in-autumn-2","","","2018-05-07 13:43:07","2018-05-07 11:43:07","","0","http://dswp.local/?p=99","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("100","1","2018-02-22 10:11:04","2018-02-22 09:11:04","","Brook in autumn","","inherit","closed","closed","","99-revision-v1","","","2018-02-22 10:11:04","2018-02-22 09:11:04","","99","http://dswp.local/2018/02/22/99-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("101","1","2018-02-22 10:12:25","2018-02-22 09:12:25","Another one I have mixed feelings about. In truth this is a sort of draft : I have a truck model that waits for me since about 2 years now. The plan was to put it near a icy torrent like that one. But then I was unsure of the icy effects and about how they would be rendered so I tried that small diorama.

Conclusion is I shouldn\'t have build the two sides of the river, the shape is alright and the weird kind of lighting is okay, but the small ripples are not a great work at all.
And can anyone notice the icy effects on the ledges? No you hardly can on my pictures.

I suppose it\'s another one I could spend a couple of hours on.","The Icy River","","publish","open","open","","the-icy-river","","","2018-05-02 15:10:23","2018-05-02 13:10:23","","0","http://dswp.local/?p=101","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("102","1","2018-02-22 10:12:25","2018-02-22 09:12:25","","The Icy River","","inherit","closed","closed","","101-revision-v1","","","2018-02-22 10:12:25","2018-02-22 09:12:25","","101","http://dswp.local/2018/02/22/101-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("103","1","2018-02-22 10:14:14","2018-02-22 09:14:14","The Grey sea is my best of the series so far.

It has it all. First it\'s done at a smaller scale than the usual 1/35 and then it\'s simple and falls together. The epitome of my technique of quite simply letting my hand thinking for myself. Thanks for watching. I will probably be doing a very close diorama with more transparency as well as using more pale blue tones.","The Grey Sea","","publish","open","open","","the-grey-sea","","","2018-05-02 15:09:57","2018-05-02 13:09:57","","0","http://dswp.local/?p=103","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("104","1","2018-02-22 10:14:14","2018-02-22 09:14:14","","the grey sea","","inherit","closed","closed","","103-revision-v1","","","2018-02-22 10:14:14","2018-02-22 09:14:14","","103","http://dswp.local/2018/02/22/103-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("105","1","2018-02-22 10:14:23","2018-02-22 09:14:23","","The grey sea","","inherit","closed","closed","","103-revision-v1","","","2018-02-22 10:14:23","2018-02-22 09:14:23","","103","http://dswp.local/2018/02/22/103-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("106","1","2018-02-22 10:19:00","2018-02-22 09:19:00","I always have the temptation of going a bit beyond those nature dioramas by including some human input at some point and then I say to myself heck no.. Not yet. Let\'s finish first at least 20 of those and then we\'ll see.

And every time this temptation occurs I feel the need of doing something quite abstract like that piece of shore called \"Ripples\" which has just some sand and a bit of sea and basic lighting effect.
That\'s my most zen piece so far, I\'m quite fond of it even If I want to do it again with brighter colors","Ripples","","publish","open","open","","ripples","","","2018-05-07 18:34:33","2018-05-07 16:34:33","","0","http://dswp.local/?p=106","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("107","1","2018-02-22 10:17:34","2018-02-22 09:17:34","","jean_diorama_BcqKpywl-Gb (1)","","inherit","open","closed","","jean_diorama_bcqkpywl-gb-1","","","2018-02-22 10:17:34","2018-02-22 09:17:34","","106","http://dswp.local/wp-content/uploads/2018/02/jean_diorama_BcqKpywl-Gb-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("108","1","2018-02-22 10:17:35","2018-02-22 09:17:35","","jean_diorama_BcapR_yls4n","","inherit","open","closed","","jean_diorama_bcapr_yls4n","","","2018-02-22 10:17:35","2018-02-22 09:17:35","","106","http://dswp.local/wp-content/uploads/2018/02/jean_diorama_BcapR_yls4n.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("109","1","2018-02-22 10:17:51","2018-02-22 09:17:51","","jean_diorama_BcqKrCfli0O","","inherit","open","closed","","jean_diorama_bcqkrcfli0o","","","2018-02-22 10:17:51","2018-02-22 09:17:51","","106","http://dswp.local/wp-content/uploads/2018/02/jean_diorama_BcqKrCfli0O.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("110","1","2018-02-22 10:19:00","2018-02-22 09:19:00","","Ripples","","inherit","closed","closed","","106-revision-v1","","","2018-02-22 10:19:00","2018-02-22 09:19:00","","106","http://dswp.local/2018/02/22/106-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("111","1","2018-02-22 11:07:16","2018-02-22 10:07:16","This website shows the nature centered dioramas I have been building throughout the last part of 2017 and in 2018.
The rules of the game are pretty simple : I bought a series of 3d boxes and I fill them with little scenes that must not be more than 2cm high. I must build those pretty fast so as not to loose interest too.

I have a lot of experience concerning the creation of nature in scale as well as the sea coming from my not so science fiction not so highly historical dioramas, the point here is to focus on only the nature part of my work.

I also try to follow the seasons like for instance showing a pond with shriveled lilies in winter as well as decayed leaves.

I get some wonderful energies working on this stuff, it\'s quite a zen thing, really relaxing -indeed while building those I found out my work had some appeal to a much wider audience than I ever had

So the plan for 2018 is to have roughly 20 of those that I could show on an exhibition. But those tend to be quite successful indeed and I have been selling quite a few of them.

And that\'s the idea here: those things are easy to pack and to dispatch. They can be on your mantelpiece for not such a fortune, please contact me!

For the other stuff I do, please have a look on my other website <a href=\"http://www.jbadiorama.com\" target=\"_blank\" rel=\"noopener\">www.jbadiorama.com</a>","About/Contact","","inherit","closed","closed","","9-autosave-v1","","","2018-02-22 11:07:16","2018-02-22 10:07:16","","9","http://dswp.local/2018/02/22/9-autosave-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("112","1","2018-02-22 10:23:46","2018-02-22 09:23:46","<div dir=\"auto\">This website shows the nature centered dioramas I have been building throughout the last part of 2017 and in 2018.</div>
<div dir=\"auto\">The rules of the game are pretty simple : I bought a series of 3d boxes and I fill them with little scenes that must not be more than 2cm high. I must build those pretty fast so as not to loose interest too.</div>
<div dir=\"auto\">I have a lot of experience concerning the creation of nature in scale as well as the sea coming from my not so science fiction not so highly historical dioramas, the point here is to focus on only the nature part of my work.</div>
<div dir=\"auto\">I also try to follow the seasons like for instance showing a pond with shriveled lilies in winter as well as decayed leaves.</div>
<div dir=\"auto\">I get some wonderful energies working on this stuff, it\'s quite a zen thing, really relaxing -indeed while building those I found out my work had some appeal to a much wider audience than I ever had</div>
<div dir=\"auto\">So the plan for 2018 is to have roughly 20 of those that I could show on an exhibition. But those tend to be quite successful indeed and I have been selling quite a few of them.</div>
<div dir=\"auto\">And that\'s the idea here: those things are easy to pack and to dispatch. They can be on your mantelpiece for not such a fortune, please contact me!</div>
<div dir=\"auto\">For the other stuff I do, please have a look on my other website <a href=\"http://www.jbadiorama.com\" target=\"_blank\" rel=\"noopener\">www.jbadiorama.com</a></div>","About","","inherit","closed","closed","","9-revision-v1","","","2018-02-22 10:23:46","2018-02-22 09:23:46","","9","http://dswp.local/2018/02/22/9-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("113","1","2018-02-22 10:23:54","2018-02-22 09:23:54","<div dir=\"auto\">This website shows the nature centered dioramas I have been building throughout the last part of 2017 and in 2018.</div>
<div dir=\"auto\">The rules of the game are pretty simple : I bought a series of 3d boxes and I fill them with little scenes that must not be more than 2cm high. I must build those pretty fast so as not to loose interest too.</div>
<div dir=\"auto\">I have a lot of experience concerning the creation of nature in scale as well as the sea coming from my not so science fiction not so highly historical dioramas, the point here is to focus on only the nature part of my work.</div>
<div dir=\"auto\">I also try to follow the seasons like for instance showing a pond with shriveled lilies in winter as well as decayed leaves.</div>
<div dir=\"auto\">I get some wonderful energies working on this stuff, it\'s quite a zen thing, really relaxing -indeed while building those I found out my work had some appeal to a much wider audience than I ever had</div>
<div dir=\"auto\">So the plan for 2018 is to have roughly 20 of those that I could show on an exhibition. But those tend to be quite successful indeed and I have been selling quite a few of them.</div>
<div dir=\"auto\">And that\'s the idea here: those things are easy to pack and to dispatch. They can be on your mantelpiece for not such a fortune, please contact me!</div>
<div dir=\"auto\">For the other stuff I do, please have a look on my other website <a href=\"http://www.jbadiorama.com\" target=\"_blank\" rel=\"noopener\">www.jbadiorama.com</a></div>","About/Contact","","inherit","closed","closed","","9-revision-v1","","","2018-02-22 10:23:54","2018-02-22 09:23:54","","9","http://dswp.local/2018/02/22/9-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("114","1","2018-02-22 10:24:43","2018-02-22 09:24:43","<div dir=\"auto\">This website shows the nature centered dioramas I have been building throughout the last part of 2017 and in 2018.</div>
<div dir=\"auto\">The rules of the game are pretty simple : I bought a series of 3d boxes and I fill them with little scenes that must not be more than 2cm high. I must build those pretty fast so as not to loose interest too.</div>
<div dir=\"auto\"></div>
<div dir=\"auto\">I have a lot of experience concerning the creation of nature in scale as well as the sea coming from my not so science fiction not so highly historical dioramas, the point here is to focus on only the nature part of my work.</div>
<div dir=\"auto\"></div>
<div dir=\"auto\">I also try to follow the seasons like for instance showing a pond with shriveled lilies in winter as well as decayed leaves.</div>
<div dir=\"auto\"></div>
<div dir=\"auto\">I get some wonderful energies working on this stuff, it\'s quite a zen thing, really relaxing -indeed while building those I found out my work had some appeal to a much wider audience than I ever had</div>
<div dir=\"auto\"></div>
<div dir=\"auto\">So the plan for 2018 is to have roughly 20 of those that I could show on an exhibition. But those tend to be quite successful indeed and I have been selling quite a few of them.</div>
<div dir=\"auto\"></div>
<div dir=\"auto\">And that\'s the idea here: those things are easy to pack and to dispatch. They can be on your mantelpiece for not such a fortune, please contact me!</div>
<div dir=\"auto\"></div>
<div dir=\"auto\">For the other stuff I do, please have a look on my other website <a href=\"http://www.jbadiorama.com\" target=\"_blank\" rel=\"noopener\">www.jbadiorama.com</a></div>","About/Contact","","inherit","closed","closed","","9-revision-v1","","","2018-02-22 10:24:43","2018-02-22 09:24:43","","9","http://dswp.local/2018/02/22/9-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("115","1","2018-02-22 10:26:07","2018-02-22 09:26:07","<div dir=\"auto\">This website shows the nature centered dioramas I have been building throughout the last part of 2017 and in 2018.</div>
<div dir=\"auto\">The rules of the game are pretty simple : I bought a series of 3d boxes and I fill them with little scenes that must not be more than 2cm high. I must build those pretty fast so as not to loose interest too. I focus on nature and sea shores..</div>
<div dir=\"auto\"></div>","SEA Diorama","","inherit","closed","closed","","34-revision-v1","","","2018-02-22 10:26:07","2018-02-22 09:26:07","","34","http://dswp.local/2018/02/22/34-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("116","1","2018-02-22 10:26:52","2018-02-22 09:26:52","<div dir=\"auto\">This website is a side project -it shows the nature centered dioramas I have been building throughout the last part of 2017 and in 2018.</div>
<div dir=\"auto\">The rules of the game are pretty simple : I bought a series of 3d boxes and I fill them with little scenes that must not be more than 2cm high. I must build those pretty fast so as not to loose interest too. I focus on nature and sea shores..</div>
<div dir=\"auto\"></div>","SEA Diorama","","inherit","closed","closed","","34-revision-v1","","","2018-02-22 10:26:52","2018-02-22 09:26:52","","34","http://dswp.local/2018/02/22/34-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("119","1","2018-02-22 11:08:01","2018-02-22 10:08:01","<p> This website shows the nature centered dioramas I have been building throughout the last part of 2017 and in 2018.</p>
<p>The rules of the game are pretty simple : I bought a series of 3d boxes and I fill them with little scenes that must not be more than 2cm high. I must build those pretty fast so as not to loose interest too.</p>

<p>I have a lot of experience concerning the creation of nature in scale as well as the sea coming from my not so science fiction not so highly historical dioramas, the point here is to focus on only the nature part of my work.</p>

<p>I also try to follow the seasons like for instance showing a pond with shriveled lilies in winter as well as decayed leaves.</p>

<p>I get some wonderful energies working on this stuff, it\'s quite a zen thing, really relaxing -indeed while building those I found out my work had some appeal to a much wider audience than I ever had</p>

<p>So the plan for 2018 is to have roughly 20 of those that I could show on an exhibition. But those tend to be quite successful indeed and I have been selling quite a few of them.</p>

<p>And that\'s the idea here: those things are easy to pack and to dispatch. They can be on your mantelpiece for not such a fortune, please contact me!</p>

<p>For the other stuff I do, please have a look on my other website <a href=\"http://www.jbadiorama.com\" target=\"_blank\" rel=\"noopener\">www.jbadiorama.com</a></p>","About/Contact","","inherit","closed","closed","","9-revision-v1","","","2018-02-22 11:08:01","2018-02-22 10:08:01","","9","http://dswp.local/2018/02/22/9-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("125","1","2018-02-22 11:53:55","2018-02-22 10:53:55"," ","","","publish","closed","closed","","125","","","2018-04-23 09:14:21","2018-04-23 07:14:21","","0","http://dswp.local/?p=125","2","nav_menu_item","","0");
INSERT INTO `yucqn_posts` VALUES("126","1","2018-02-22 13:37:57","2018-02-22 12:37:57","","Blog","","publish","closed","closed","","acf_blog","","","2018-02-22 13:37:57","2018-02-22 12:37:57","","0","http://dswp.local/?post_type=acf&#038;p=126","0","acf","","0");
INSERT INTO `yucqn_posts` VALUES("127","1","2018-02-22 19:57:52","2018-02-22 18:57:52","<div dir=\"auto\">This website is a side project -it shows the nature centered dioramas I have been building throughout the last part of 2017 and in 2018.</div>
<div dir=\"auto\">The rules of the game are pretty simple : I bought a series of 3d boxes and I fill them with little scenes that must not be more than 2cm high. I must build those pretty fast so as not to loose interest too. I focus on nature and sea shores..</div>
<div dir=\"auto\"></div>","Distant Shores","","inherit","closed","closed","","34-revision-v1","","","2018-02-22 19:57:52","2018-02-22 18:57:52","","34","http://dswp.local/127/34-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("128","1","2018-02-22 20:17:23","2018-02-22 19:17:23","","fd","","inherit","open","closed","","fd-2","","","2018-02-22 20:17:23","2018-02-22 19:17:23","","34","http://dswp.local/wp-content/uploads/2018/02/fd-1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("129","1","2018-02-22 20:17:29","2018-02-22 19:17:29","<div dir=\"auto\">This website is a side project -it shows the nature centered dioramas I have been building throughout the last part of 2017 and in 2018.</div>
<div dir=\"auto\">The rules of the game are pretty simple : I bought a series of 3d boxes and I fill them with little scenes that must not be more than 2cm high. I must build those pretty fast so as not to loose interest too. I focus on nature and sea shores..</div>
<div dir=\"auto\"></div>","Distant Shores","","inherit","closed","closed","","34-revision-v1","","","2018-02-22 20:17:29","2018-02-22 19:17:29","","34","http://dswp.local/129/34-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("130","1","2018-02-23 12:02:38","2018-02-23 11:02:38","<div dir=\"auto\">I always have the temptation of going a bit beyond those nature dioramas by including some human input at some point and then I say to myself heck no.. Not yet. Let\'s finish first at least 20 of those and then we\'ll see.</div>
<div dir=\"auto\">And every time this temptation occurs I feel the need of doing something quite abstract like that piece of shore which has just some sand and a bit of sea and basic lighting effect.</div>
<div dir=\"auto\">That\'s my most zen piece so far, I\'m quite fond of it even If I want to do it again with brighter colors</div>","Ripples","","inherit","closed","closed","","106-revision-v1","","","2018-02-23 12:02:38","2018-02-23 11:02:38","","106","http://dswp.local/130/106-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("131","1","2018-02-23 12:04:11","2018-02-23 11:04:11","<div dir=\"auto\">Aivazovski is not the best painter in history but I think he was my work\'s major influence at some point.</div>
<div dir=\"auto\">I like it all, the colors, the shape, the movement, the historical frame,  the drama.</div>
<div dir=\"auto\">Here is a typical diorama inspired by his work. I still have a lot of work to reach the level of his small footnail though.</div>
<div dir=\"auto\">Yet it works, happy about the foam as well as transparency.</div>","Aivazovsky","","inherit","closed","closed","","95-revision-v1","","","2018-02-23 12:04:11","2018-02-23 11:04:11","","95","http://dswp.local/131/95-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("132","1","2018-02-23 12:04:54","2018-02-23 11:04:54","<p>Aivazovski is not the best painter in history but I think he was my work\'s major influence at some point.</p>
<p>I like it all, the colors, the shape, the movement, the historical frame,  the drama.</p>
<p>Here is a typical diorama inspired by his work. I still have a lot of work to reach the level of his small footnail though.</p>
<p>Yet it works, happy about the foam as well as transparency.</p>","Aivazovsky","","inherit","closed","closed","","95-revision-v1","","","2018-02-23 12:04:54","2018-02-23 11:04:54","","95","http://dswp.local/132/95-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("133","1","2018-02-23 12:06:00","2018-02-23 11:06:00","<p>I always have the temptation of going a bit beyond those nature dioramas by including some human input at some point and then I say to myself heck no.. Not yet. Let\'s finish first at least 20 of those and then we\'ll see.</p>
And every time this temptation occurs I feel the need of doing something quite abstract like that piece of shore which has just some sand and a bit of sea and basic lighting effect.
That\'s my most zen piece so far, I\'m quite fond of it even If I want to do it again with brighter colors</p>","Ripples","","inherit","closed","closed","","106-autosave-v1","","","2018-02-23 12:06:00","2018-02-23 11:06:00","","106","http://dswp.local/133/106-autosave-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("134","1","2018-02-23 12:06:05","2018-02-23 11:06:05","<p>I always have the temptation of going a bit beyond those nature dioramas by including some human input at some point and then I say to myself heck no.. Not yet. Let\'s finish first at least 20 of those and then we\'ll see.</p>
<p>And every time this temptation occurs I feel the need of doing something quite abstract like that piece of shore which has just some sand and a bit of sea and basic lighting effect.
That\'s my most zen piece so far, I\'m quite fond of it even If I want to do it again with brighter colors</p>","Ripples","","inherit","closed","closed","","106-revision-v1","","","2018-02-23 12:06:05","2018-02-23 11:06:05","","106","http://dswp.local/134/106-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("135","1","2018-02-23 12:07:25","2018-02-23 11:07:25","<p>Dreary humid, foggy autumn and then the yellow leaves fall in the river filled with pure water as renewed by the countless scattered showers. I feel both cold and happy when looking at that one.</p>","Brook in autumn","","inherit","closed","closed","","99-revision-v1","","","2018-02-23 12:07:25","2018-02-23 11:07:25","","99","http://dswp.local/135/99-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("136","1","2018-02-23 12:08:05","2018-02-23 11:08:05","<p>The Grey sea is my best of the series so far. </p>
<p>It has it all. First it\'s done at a smaller scale than the usual 1/35 and then it\'s simple and falls together. The epitome of my technique of quite simply letting my hand thinking for myself. Thanks for watching. I will probably be doing a very close diorama with more transparency as well as using more pale blue tones. </p>
","The grey sea","","inherit","closed","closed","","103-revision-v1","","","2018-02-23 12:08:05","2018-02-23 11:08:05","","103","http://dswp.local/136/103-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("137","1","2018-02-23 12:08:21","2018-02-23 11:08:21","<p>The Grey sea is my best of the series so far. </p>
<p>It has it all. First it\'s done at a smaller scale than the usual 1/35 and then it\'s simple and falls together. The epitome of my technique of quite simply letting my hand thinking for myself. Thanks for watching. I will probably be doing a very close diorama with more transparency as well as using more pale blue tones. </p>
","The Grey Sea","","inherit","closed","closed","","103-revision-v1","","","2018-02-23 12:08:21","2018-02-23 11:08:21","","103","http://dswp.local/137/103-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("138","1","2018-02-23 12:09:32","2018-02-23 11:09:32","<p>Another one I have mixed feelings about. In truth this is a sort of draft : I have a truck model that waits for me since about 2 years now. The plan was to put it near a icy torrent like that one. But then I was unsure of the icy effects and about how they would be rendered so I tried that small diorama. </p>

<p>Conclusion is I shouldn\'t have build the two sides of the river, the shape is alright and the weird kind of lighting is okay, but the small ripples are not a great work at all. 
And can anyone notice the icy effects on the ledges? No you can\'t on my pictures. </p>
<p>I suppose it\'s another one I could spend a couple of hours on. </p>","The Icy River","","inherit","closed","closed","","101-autosave-v1","","","2018-02-23 12:09:32","2018-02-23 11:09:32","","101","http://dswp.local/138/101-autosave-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("139","1","2018-02-23 12:09:47","2018-02-23 11:09:47","<p>Another one I have mixed feelings about. In truth this is a sort of draft : I have a truck model that waits for me since about 2 years now. The plan was to put it near a icy torrent like that one. But then I was unsure of the icy effects and about how they would be rendered so I tried that small diorama. </p>

<p>Conclusion is I shouldn\'t have build the two sides of the river, the shape is alright and the weird kind of lighting is okay, but the small ripples are not a great work at all. 
And can anyone notice the icy effects on the ledges? No you hardly can on my pictures. </p>
<p>I suppose it\'s another one I could spend a couple of hours on. </p>","The Icy River","","inherit","closed","closed","","101-revision-v1","","","2018-02-23 12:09:47","2018-02-23 11:09:47","","101","http://dswp.local/139/101-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("140","1","2018-02-23 12:14:02","2018-02-23 11:14:02","<p>I gave out the first of that series to someone who is very dear to me and I was suddenly deprived of my first diorama, the only one with true saturated colors I did so far.</p>
<p>As I still had the form I used for it (silicon one, reusable), I decided to do a new one while saturating the colors even more and to get a more uniform color of the sea.</p>
<p>In order to create a nice hot-spot I also darkened the place where the two waves meet..</p>
<p>Well that one was sold pretty fast as well so I will be trying out a third version with yet different colors soon.</p>","Just the Sea 1 #2","","inherit","closed","closed","","32-revision-v1","","","2018-02-23 12:14:02","2018-02-23 11:14:02","","32","http://dswp.local/140/32-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("141","1","2018-02-23 12:16:44","2018-02-23 11:16:44","The second prototype! Long gone now, looks like blue flowers..","Just the Sea 1 #1","","publish","open","open","","just-the-sea-1-1","","","2018-03-12 14:11:52","2018-03-12 13:11:52","","0","http://dswp.local/?p=141","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("146","1","2018-02-23 12:16:44","2018-02-23 11:16:44","<p>The second prototype! Long gone now, looks like blue flowers..</p> ","Just the Sea 1 #1","","inherit","closed","closed","","141-revision-v1","","","2018-02-23 12:16:44","2018-02-23 11:16:44","","141","http://dswp.local/146/141-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("147","1","2018-02-23 12:26:24","2018-02-23 11:26:24","<p>Aivazovski is not the best painter in history but I think he was my work\'s major influence at some point.</p>
<p>I like it all, the colors, the shape, the movement, the historical frame,  the drama.</p>
<p>Here is a typical diorama inspired by his work. I still have a lot of work to reach the level of his small footnail though.</p>
<p>Yet it works, happy about the foam as well as transparency.</p>","Aivazovsky","","inherit","closed","closed","","95-revision-v1","","","2018-02-23 12:26:24","2018-02-23 11:26:24","","95","http://dswp.local/147/95-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("148","1","2018-02-23 12:27:13","2018-02-23 11:27:13","<p>One of the lesser of the series I suppose? I should work on it again. The colors are good and make it for a rather uneventful water scape. Something has to be done! Watch this space! </p>
","Top of  the lake","","inherit","closed","closed","","97-revision-v1","","","2018-02-23 12:27:13","2018-02-23 11:27:13","","97","http://dswp.local/148/97-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("149","1","2017-11-23 13:57:14","2017-11-23 12:57:14","An in progress picture dating from the making of <a href=\"http://dswp.local/66/white-shore/\">\"White Shore\"</a>","The Elements of the Sea","","publish","open","open","","the-elements-of-the-sea","","","2018-02-23 13:59:09","2018-02-23 12:59:09","","0","http://dswp.local/?p=149","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("150","1","2018-02-23 13:57:39","2018-02-23 12:57:39","Elements of the sea","_MG_0933","Elements of the sea","inherit","open","closed","","_mg_0933","","","2018-02-23 13:58:01","2018-02-23 12:58:01","","149","http://dswp.local/wp-content/uploads/2018/02/MG_0933.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("151","1","2018-02-23 13:59:09","2018-02-23 12:59:09","An in progress picture dating from the making of <a href=\"http://dswp.local/66/white-shore/\">\"White Shore\"</a>","The Elements of the Sea","","inherit","closed","closed","","149-revision-v1","","","2018-02-23 13:59:09","2018-02-23 12:59:09","","149","http://dswp.local/151/149-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("152","1","2017-12-23 14:08:37","2017-12-23 13:08:37","I sometimes fail miserably my dioramas -here is a fish I had been modeling that went buried under a layer of failed resin and therefore disappeared forever. it was not that great anyway","that Fish","","publish","open","open","","that-fish","","","2018-02-23 14:12:04","2018-02-23 13:12:04","","0","http://dswp.local/?p=152","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("153","1","2018-02-23 14:08:06","2018-02-23 13:08:06","","_MG_1007","","inherit","open","closed","","_mg_1007","","","2018-02-23 14:08:06","2018-02-23 13:08:06","","152","http://dswp.local/wp-content/uploads/2018/02/MG_1007.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("154","1","2018-02-23 14:08:14","2018-02-23 13:08:14","","_MG_1049","","inherit","open","closed","","_mg_1049","","","2018-02-23 14:08:14","2018-02-23 13:08:14","","152","http://dswp.local/wp-content/uploads/2018/02/MG_1049.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("155","1","2018-02-23 14:08:20","2018-02-23 13:08:20","","_MG_1012","","inherit","open","closed","","_mg_1012","","","2018-02-23 14:08:20","2018-02-23 13:08:20","","152","http://dswp.local/wp-content/uploads/2018/02/MG_1012.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("156","1","2018-02-23 14:08:37","2018-02-23 13:08:37","I sometimes fail miserably my dioramas -here is a fish I had been modeling that went buried under a layer of failed resin and therefore disappeared forever. it was not that great anyway","that Fish","","inherit","closed","closed","","152-revision-v1","","","2018-02-23 14:08:37","2018-02-23 13:08:37","","152","http://dswp.local/156/152-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("157","1","2018-02-15 14:10:33","2018-02-15 13:10:33","Another set of leaves that went down the drain after i failed the resin part, anyway I paint all of them individually , and here is a trick: always use twice the amount of material you originally thought was enough.","Painting laser cut leaves","","publish","open","open","","painting-laser-cut-leaves","","","2018-02-23 14:26:59","2018-02-23 13:26:59","","0","http://dswp.local/?p=157","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("158","1","2018-02-23 14:10:33","2018-02-23 13:10:33","Another set of leaves that went down the drain after i failed the resin part, anyway I paint all of them individually , and here is a trick: always use twice the amount of material you originally thought was enough.","painting laser cut leaves","","inherit","closed","closed","","157-revision-v1","","","2018-02-23 14:10:33","2018-02-23 13:10:33","","157","http://dswp.local/158/157-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("159","1","2018-02-23 14:10:53","2018-02-23 13:10:53","Another set of leaves that went down the drain after i failed the resin part, anyway I paint all of them individually , and here is a trick: always use twice the amount of material you originally thought was enough.","Painting laser cut leaves","","inherit","closed","closed","","157-revision-v1","","","2018-02-23 14:10:53","2018-02-23 13:10:53","","157","http://dswp.local/159/157-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("160","1","2018-02-23 15:29:44","2018-02-23 14:29:44","The Grey Sea 1/48 diorama","_MG_1044","","inherit","closed","closed","","_mg_1044","","","2018-02-23 15:30:17","2018-02-23 14:30:17","","103","http://dswp.local/wp-content/uploads/2018/02/MG_1044.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("161","1","2018-02-23 15:30:00","2018-02-23 14:30:00","The Grey Sea 1/48 diorama","_MG_1042","","inherit","closed","closed","","_mg_1042-2","","","2018-02-23 15:30:20","2018-02-23 14:30:20","","103","http://dswp.local/wp-content/uploads/2018/02/MG_1042.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("162","1","2018-02-23 15:30:05","2018-02-23 14:30:05","The Grey Sea 1/48 diorama","_MG_1036","","inherit","closed","closed","","_mg_1036-2","","","2018-02-23 15:30:25","2018-02-23 14:30:25","","103","http://dswp.local/wp-content/uploads/2018/02/MG_1036.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("163","1","2018-02-23 15:31:05","2018-02-23 14:31:05","The Grey sea is my best of the series so far.

It has it all. First it\'s done at a smaller scale than the usual 1/35 and then it\'s simple and falls together. The epitome of my technique of quite simply letting my hand thinking for myself. Thanks for watching. I will probably be doing a very close diorama with more transparency as well as using more pale blue tones.","The Grey Sea","","inherit","closed","closed","","103-revision-v1","","","2018-02-23 15:31:05","2018-02-23 14:31:05","","103","http://dswp.local/163/103-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("164","1","2018-02-23 15:43:45","2018-02-23 14:43:45","Ripples 1/35 diorama","_MG_1035","","inherit","closed","closed","","_mg_1035","","","2018-02-23 15:45:10","2018-02-23 14:45:10","","106","http://dswp.local/wp-content/uploads/2018/02/MG_1035.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("165","1","2018-02-23 15:43:53","2018-02-23 14:43:53","Ripples 1/35 diorama","_MG_1040","","inherit","closed","closed","","_mg_1040","","","2018-02-23 15:44:55","2018-02-23 14:44:55","","106","http://dswp.local/wp-content/uploads/2018/02/MG_1040.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("166","1","2018-02-23 15:44:00","2018-02-23 14:44:00","Ripples 1/35 diorama","_MG_1034","","inherit","closed","closed","","_mg_1034","","","2018-02-23 15:44:13","2018-02-23 14:44:13","","106","http://dswp.local/wp-content/uploads/2018/02/MG_1034.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("167","1","2018-02-23 15:44:27","2018-02-23 14:44:27","I always have the temptation of going a bit beyond those nature dioramas by including some human input at some point and then I say to myself heck no.. Not yet. Let\'s finish first at least 20 of those and then we\'ll see.

And every time this temptation occurs I feel the need of doing something quite abstract like that piece of shore which has just some sand and a bit of sea and basic lighting effect.
That\'s my most zen piece so far, I\'m quite fond of it even If I want to do it again with brighter colors","Ripples","","inherit","closed","closed","","106-revision-v1","","","2018-02-23 15:44:27","2018-02-23 14:44:27","","106","http://dswp.local/167/106-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("168","1","2018-02-23 15:52:51","2018-02-23 14:52:51","","_MG_0900","","inherit","closed","closed","","_mg_0900","","","2018-02-23 15:53:41","2018-02-23 14:53:41","","141","http://dswp.local/wp-content/uploads/2018/02/MG_0900.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("169","1","2018-02-23 15:52:56","2018-02-23 14:52:56","","_MG_0905","","inherit","closed","closed","","_mg_0905","","","2018-02-23 15:53:37","2018-02-23 14:53:37","","141","http://dswp.local/wp-content/uploads/2018/02/MG_0905.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("170","1","2018-02-23 15:53:05","2018-02-23 14:53:05","","_MG_0909","","inherit","closed","closed","","_mg_0909","","","2018-02-23 15:53:34","2018-02-23 14:53:34","","141","http://dswp.local/wp-content/uploads/2018/02/MG_0909.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("171","1","2018-02-23 15:53:10","2018-02-23 14:53:10","","_MG_0911","","inherit","closed","closed","","_mg_0911","","","2018-02-23 15:53:32","2018-02-23 14:53:32","","141","http://dswp.local/wp-content/uploads/2018/02/MG_0911.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("172","1","2018-02-23 15:54:00","2018-02-23 14:54:00","The second prototype! Long gone now, looks like blue flowers..","Just the Sea 1 #1","","inherit","closed","closed","","141-revision-v1","","","2018-02-23 15:54:00","2018-02-23 14:54:00","","141","http://dswp.local/172/141-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("173","1","2018-02-23 16:08:21","2018-02-23 15:08:21","One of the lesser of the series I suppose? I should work on it again. The colors are good and make it for a rather uneventful water scape. Something has to be done! Watch this space!","Top of  the Lake","","inherit","closed","closed","","97-revision-v1","","","2018-02-23 16:08:21","2018-02-23 15:08:21","","97","http://dswp.local/173/97-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("174","1","2018-02-23 16:08:55","2018-02-23 15:08:55","","_MG_1240","","inherit","closed","closed","","_mg_1240","","","2018-02-23 16:09:42","2018-02-23 15:09:42","","0","http://dswp.local/wp-content/uploads/2018/02/MG_1240.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("175","1","2018-02-23 16:09:01","2018-02-23 15:09:01","","_MG_1237","","inherit","closed","closed","","_mg_1237","","","2018-02-23 16:09:34","2018-02-23 15:09:34","","0","http://dswp.local/wp-content/uploads/2018/02/MG_1237.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("176","1","2018-02-23 16:09:09","2018-02-23 15:09:09","","_MG_1233","","inherit","closed","closed","","_mg_1233","","","2018-02-23 16:09:38","2018-02-23 15:09:38","","0","http://dswp.local/wp-content/uploads/2018/02/MG_1233.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("177","1","2018-02-23 16:09:15","2018-02-23 15:09:15","","_MG_1234","","inherit","closed","closed","","_mg_1234","","","2018-02-23 16:09:48","2018-02-23 15:09:48","","0","http://dswp.local/wp-content/uploads/2018/02/MG_1234.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("178","1","2018-02-23 16:33:03","1970-01-01 05:05:05","A new version of <a href=\"http://dswp.local/95/aivazovsky/\">Aivazovski! </a>

Plenty of work to do..","On my workbench..","","draft","closed","closed","","","","","2018-02-23 16:33:03","2018-02-23 15:33:03","","0","http://dswp.local/?p=178","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("180","1","2018-02-23 16:37:12","1970-01-01 05:05:05","","New diorama on the workbench","","draft","closed","closed","","","","","2018-02-23 16:37:12","2018-02-23 15:37:12","","0","http://dswp.local/?p=180","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("181","1","2018-02-23 17:15:26","2018-02-23 16:15:26","","_MG_1238","","inherit","closed","closed","","_mg_1238","","","2018-02-23 17:17:02","2018-02-23 16:17:02","","0","http://dswp.local/wp-content/uploads/2018/02/MG_1238.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("182","1","2018-02-23 17:15:31","2018-02-23 16:15:31","","_MG_1228","","inherit","closed","closed","","_mg_1228","","","2018-02-23 17:16:59","2018-02-23 16:16:59","","0","http://dswp.local/wp-content/uploads/2018/02/MG_1228.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("183","1","2018-02-23 17:15:36","2018-02-23 16:15:36","","_MG_1244","","inherit","closed","closed","","_mg_1244","","","2018-02-23 17:16:57","2018-02-23 16:16:57","","0","http://dswp.local/wp-content/uploads/2018/02/MG_1244.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("184","1","2018-02-23 17:33:58","2018-02-23 16:33:58","","_MG_1445","","inherit","closed","closed","","_mg_1445","","","2018-02-23 17:33:58","2018-02-23 16:33:58","","101","http://dswp.local/wp-content/uploads/2018/02/MG_1445.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("185","1","2018-02-23 17:34:04","2018-02-23 16:34:04","","_MG_1436","","inherit","closed","closed","","_mg_1436","","","2018-02-23 17:34:04","2018-02-23 16:34:04","","101","http://dswp.local/wp-content/uploads/2018/02/MG_1436.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("186","1","2018-02-23 17:34:10","2018-02-23 16:34:10","","_MG_1439","","inherit","closed","closed","","_mg_1439","","","2018-02-23 17:34:10","2018-02-23 16:34:10","","101","http://dswp.local/wp-content/uploads/2018/02/MG_1439.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("187","1","2018-02-23 17:34:59","2018-02-23 16:34:59","","_MG_1445","","inherit","closed","closed","","_mg_1445-2","","","2018-02-23 17:35:35","2018-02-23 16:35:35","","0","http://dswp.local/wp-content/uploads/2018/02/MG_1445-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("188","1","2018-02-23 17:35:05","2018-02-23 16:35:05","","_MG_1436","","inherit","closed","closed","","_mg_1436-2","","","2018-02-23 17:35:37","2018-02-23 16:35:37","","0","http://dswp.local/wp-content/uploads/2018/02/MG_1436-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("189","1","2018-02-23 17:35:12","2018-02-23 16:35:12","","_MG_1439","","inherit","closed","closed","","_mg_1439-2","","","2018-02-23 17:35:28","2018-02-23 16:35:28","","0","http://dswp.local/wp-content/uploads/2018/02/MG_1439-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("190","1","2018-02-23 17:36:17","2018-02-23 16:36:17","Another one I have mixed feelings about. In truth this is a sort of draft : I have a truck model that waits for me since about 2 years now. The plan was to put it near a icy torrent like that one. But then I was unsure of the icy effects and about how they would be rendered so I tried that small diorama.

Conclusion is I shouldn\'t have build the two sides of the river, the shape is alright and the weird kind of lighting is okay, but the small ripples are not a great work at all.
And can anyone notice the icy effects on the ledges? No you hardly can on my pictures.

I suppose it\'s another one I could spend a couple of hours on.","The Icy River","","inherit","closed","closed","","101-revision-v1","","","2018-02-23 17:36:17","2018-02-23 16:36:17","","101","http://dswp.local/190/101-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("191","1","2018-02-23 17:38:59","2018-02-23 16:38:59","","_MG_14392","","inherit","closed","closed","","_mg_14392","","","2018-02-23 17:38:59","2018-02-23 16:38:59","","0","http://dswp.local/wp-content/uploads/2018/02/MG_14392.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("192","1","2018-02-23 17:55:42","2018-02-23 16:55:42","The Grey sea is my best of the series so far.

It has it all. First it\'s done at a smaller scale than the usual 1/35 and then it\'s simple and falls together. The epitome of my technique of quite simply letting my hand thinking for myself. Thanks for watching. I will probably be doing a very close diorama with more transparency as well as using more pale blue tones.","The Grey Sea","","inherit","closed","closed","","103-revision-v1","","","2018-02-23 17:55:42","2018-02-23 16:55:42","","103","http://dswp.local/192/103-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("195","1","2018-02-24 10:32:51","2018-02-24 09:32:51","","_MG_1436","","inherit","closed","closed","","_mg_1436-3","","","2018-02-24 10:36:18","2018-02-24 09:36:18","","106","http://dswp.local/wp-content/uploads/2018/02/MG_1436.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("196","1","2018-02-24 10:33:02","2018-02-24 09:33:02","","_MG_1233","","inherit","closed","closed","","_mg_1233-2","","","2018-02-24 10:37:04","2018-02-24 09:37:04","","106","http://dswp.local/wp-content/uploads/2018/02/MG_1233-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("197","1","2018-02-24 10:33:13","2018-02-24 09:33:13","","_MG_1244","","inherit","closed","closed","","_mg_1244-2","","","2018-02-24 10:46:33","2018-02-24 09:46:33","","106","http://dswp.local/wp-content/uploads/2018/02/MG_1244-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("198","1","2018-02-24 10:33:22","2018-02-24 09:33:22","","_MG_0994","","inherit","closed","closed","","_mg_0994","","","2018-02-24 10:37:39","2018-02-24 09:37:39","","106","http://dswp.local/wp-content/uploads/2018/02/MG_0994.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("199","1","2018-02-24 10:33:30","2018-02-24 09:33:30","","_MG_1034","","inherit","closed","closed","","_mg_1034-2","","","2018-02-24 10:33:43","2018-02-24 09:33:43","","106","http://dswp.local/wp-content/uploads/2018/02/MG_1034-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("200","1","2018-02-24 10:35:28","2018-02-24 09:35:28","","_MG_0909","","inherit","closed","closed","","_mg_0909-2","","","2018-02-24 10:35:41","2018-02-24 09:35:41","","141","http://dswp.local/wp-content/uploads/2018/02/MG_0909.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("201","1","2018-02-24 10:39:23","2018-02-24 09:39:23","","_MG_1449","","inherit","closed","closed","","_mg_1449","","","2018-02-24 10:39:34","2018-02-24 09:39:34","","93","http://dswp.local/wp-content/uploads/2018/02/MG_1449.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("202","1","2018-02-24 10:41:51","2018-02-24 09:41:51","","_MG_1017","","inherit","closed","closed","","_mg_1017","","","2018-02-24 10:41:51","2018-02-24 09:41:51","","72","http://dswp.local/wp-content/uploads/2018/02/MG_1017.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("203","1","2018-02-24 10:44:37","2018-02-24 09:44:37","","_MG_09282","","inherit","closed","closed","","_mg_09282","","","2018-02-24 10:44:52","2018-02-24 09:44:52","","95","http://dswp.local/wp-content/uploads/2018/02/MG_09282.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("204","1","2018-02-24 10:45:34","2018-02-24 09:45:34","Aivazovski is not the best painter in history but I think he was my work\'s major influence at some point.

I like it all, the colors, the shape, the movement, the historical frame,  the drama.

Here is a typical diorama inspired by his work. I still have a lot of work to reach the level of his small footnail though.

Yet it works, happy about the foam as well as transparency.","Aivazovsky","","inherit","closed","closed","","95-revision-v1","","","2018-02-24 10:45:34","2018-02-24 09:45:34","","95","http://dswp.local/204/95-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("205","1","2018-02-24 11:01:58","2018-02-24 10:01:58","Really good compilation of the best diorama artists in the world","Atom Scales","","publish","closed","closed","","atom-scales","","","2018-02-24 11:01:58","2018-02-24 10:01:58","","0","http://dswp.local/?p=205","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("206","1","2018-02-24 11:01:58","2018-02-24 10:01:58","Really good compilation of the best diorama artists in the world","Atom Scales","","inherit","closed","closed","","205-revision-v1","","","2018-02-24 11:01:58","2018-02-24 10:01:58","","205","http://dswp.local/206/205-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("207","1","2018-02-25 18:36:16","2018-02-25 17:36:16","One of the *great* modelers around","Rick Lawler","","publish","closed","closed","","rick-lawler","","","2018-02-25 18:36:16","2018-02-25 17:36:16","","0","http://dswp.local/?p=207","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("208","1","2018-02-25 18:36:16","2018-02-25 17:36:16","One of the *great* modelers around","Rick Lawler","","inherit","closed","closed","","207-revision-v1","","","2018-02-25 18:36:16","2018-02-25 17:36:16","","207","http://dswp.local/208/207-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("209","1","2018-02-26 09:06:15","2018-02-26 08:06:15","This website shows the nature centered dioramas I have been building throughout the last part of 2017 and in 2018.

The rules of the game are pretty simple : I bought a series of 3d boxes and I fill them with little scenes that must not be more than 2cm high. I must build those pretty fast so as not to loose interest too.

I have a lot of experience concerning the creation of nature in scale as well as the sea coming from my not so science fiction not so highly historical dioramas, the point here is to focus on only the nature part of my work.

I also try to follow the seasons like for instance showing a pond with shriveled lilies in winter as well as decayed leaves.

I get some wonderful energies working on this stuff, it\'s quite a zen thing, really relaxing -indeed while building those I found out my work had some appeal to a much wider audience than I ever had

So the plan for 2018 is to have roughly 20 of those that I could show on an exhibition. But those tend to be quite successful indeed and I have been selling quite a few of them.

And that\'s the idea here: those things are easy to pack and to dispatch. They can be on your mantelpiece for not such a fortune, please contact me!

For the other stuff I do, please have a look on my other website <a href=\"http://www.jbadiorama.com\" target=\"_blank\" rel=\"noopener\">www.jbadiorama.com</a>","About/Contact/Links","","inherit","closed","closed","","9-revision-v1","","","2018-02-26 09:06:15","2018-02-26 08:06:15","","9","http://dswp.local/209/9-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("211","1","2018-02-06 18:25:42","2018-02-06 17:25:42","Metallic armature and then a lot of sculpting with Magic Sculpt for some whale bones, part of my new diorama called Yttygran.

You can see the general layout before painting (sory for the crap mobile picture!","Whale bones","","publish","closed","closed","","whale-bones","","","2018-03-06 18:27:38","2018-03-06 17:27:38","","0","http://dswp.local/?p=211","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("212","1","2018-03-06 18:24:24","2018-03-06 17:24:24","","IMG_20180301_211946","","inherit","closed","closed","","img_20180301_211946","","","2018-03-06 18:24:24","2018-03-06 17:24:24","","211","http://dswp.local/wp-content/uploads/2018/03/IMG_20180301_211946.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("213","1","2018-03-06 18:24:44","2018-03-06 17:24:44","","IMG_20180225_133902_HDR","","inherit","closed","closed","","img_20180225_133902_hdr","","","2018-03-06 18:24:44","2018-03-06 17:24:44","","211","http://dswp.local/wp-content/uploads/2018/03/IMG_20180225_133902_HDR.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("214","1","2018-03-06 18:25:42","2018-03-06 17:25:42","Metallic armature and then a lot of sculpting with Magic Sculpt for some whale bones, part of my new diorama called Yttygran.

You can see the general layout before painting (sory for the crap mobile picture!","Whale bones","","inherit","closed","closed","","211-revision-v1","","","2018-03-06 18:25:42","2018-03-06 17:25:42","","211","http://dswp.local/214/211-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("215","1","2018-03-06 18:26:46","2018-03-06 17:26:46","One of my new seas. The shape is ready, now all the foam has to be done (sorry again for the bad quality picture!=","Blk Sea","","publish","closed","closed","","blk-sea","","","2018-03-06 18:26:46","2018-03-06 17:26:46","","0","http://dswp.local/?p=215","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("216","1","2018-03-06 18:26:46","2018-03-06 17:26:46","One of my new seas. The shape is ready, now all the foam has to be done (sorry again for the bad quality picture!=","Blk Sea","","inherit","closed","closed","","215-revision-v1","","","2018-03-06 18:26:46","2018-03-06 17:26:46","","215","http://dswp.local/216/215-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("217","1","2018-03-08 15:57:49","2018-03-08 14:57:49","","IMG_20180307_211710","","inherit","closed","closed","","img_20180307_211710","","","2018-03-08 15:57:49","2018-03-08 14:57:49","","0","http://dswp.local/wp-content/uploads/2018/03/IMG_20180307_211710.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("218","1","2018-03-08 16:01:07","2018-03-08 15:01:07","","IMG_20180307_221148","","inherit","closed","closed","","img_20180307_221148","","","2018-03-08 16:01:07","2018-03-08 15:01:07","","0","http://dswp.local/wp-content/uploads/2018/03/IMG_20180307_221148.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("219","1","2018-03-08 16:04:48","2018-03-08 15:04:48","","IMG_20180307_222416","","inherit","closed","closed","","img_20180307_222416","","","2018-03-08 16:04:48","2018-03-08 15:04:48","","0","http://dswp.local/wp-content/uploads/2018/03/IMG_20180307_222416.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("220","1","2018-03-08 16:09:23","2018-03-08 15:09:23","Added some groundcover but the colors don\'t match, haha this is just terrible. The ground as I did it is pretty glossy and will have to be corrected.","Some Groundcover","","publish","closed","closed","","220","","","2018-03-08 16:14:30","2018-03-08 15:14:30","","0","http://dswp.local/?p=220","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("221","1","2018-03-08 16:09:23","2018-03-08 15:09:23","Added some groundcover but the colors don\'t match, haha this is just terrible. TThe ground as I did it is pretty glossy and will have to be corrected.","","","inherit","closed","closed","","220-revision-v1","","","2018-03-08 16:09:23","2018-03-08 15:09:23","","220","http://dswp.local/221/220-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("222","1","2018-03-08 16:14:22","2018-03-08 15:14:22","Added some groundcover but the colors don\'t match, haha this is just terrible. TThe ground as I did it is pretty glossy and will have to be corrected.","Some Groundcover","","inherit","closed","closed","","220-revision-v1","","","2018-03-08 16:14:22","2018-03-08 15:14:22","","220","http://dswp.local/222/220-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("223","1","2018-03-08 16:14:30","2018-03-08 15:14:30","Added some groundcover but the colors don\'t match, haha this is just terrible. The ground as I did it is pretty glossy and will have to be corrected.","Some Groundcover","","inherit","closed","closed","","220-revision-v1","","","2018-03-08 16:14:30","2018-03-08 15:14:30","","220","http://dswp.local/223/220-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("225","1","2018-03-08 16:50:05","2018-03-08 15:50:05","I finally found out the way of using this gravel glue. Just use it with an eyedropper dripping over the already placed gravel.","The glue","","publish","closed","closed","","the-glue","","","2018-03-08 16:50:05","2018-03-08 15:50:05","","0","http://dswp.local/?p=225","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("226","1","2018-03-08 16:50:05","2018-03-08 15:50:05","I finally found out the way of using this gravel glue. Just use it with an eyedropper dripping over the already placed gravel.","The glue","","inherit","closed","closed","","225-revision-v1","","","2018-03-08 16:50:05","2018-03-08 15:50:05","","225","http://dswp.local/226/225-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("227","1","2018-03-09 12:25:03","2018-03-09 11:25:03","","Dioramas","","publish","closed","closed","","dioramas","","","2018-04-23 09:14:21","2018-04-23 07:14:21","","0","http://dswp.local/?p=227","1","nav_menu_item","","0");
INSERT INTO `yucqn_posts` VALUES("228","1","2018-03-09 12:28:24","2018-03-09 11:28:24","This website shows the nature centered dioramas I have been building throughout the last part of 2017 and in 2018.

The rules of the game are pretty simple : I bought a series of 3d boxes and I fill them with little scenes that must not be more than 2cm high. I must build those pretty fast so as not to loose interest too.

I have a lot of experience concerning the creation of nature in scale as well as the sea coming from my not so science fiction not so highly historical dioramas, the point here is to focus on only the nature part of my work.

I also try to follow the seasons like for instance showing a pond with shriveled lilies in winter as well as decayed leaves.

I get some wonderful energies working on this stuff, it\'s quite a zen thing, really relaxing -indeed while building those I found out my work had some appeal to a much wider audience than I ever had

So the plan for 2018 is to have roughly 20 of those that I could show on an exhibition. But those tend to be quite successful indeed and I have been selling quite a few of them.

And that\'s the idea here: those things are easy to pack and to dispatch. They can be on your mantelpiece for not such a fortune, please contact me!

For the other stuff I do, please have a look on my other website <a href=\"http://www.jbadiorama.com\" target=\"_blank\" rel=\"noopener\">www.jbadiorama.com</a>","About/ Contact/ Links","","inherit","closed","closed","","9-revision-v1","","","2018-03-09 12:28:24","2018-03-09 11:28:24","","9","http://dswp.local/228/9-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("229","1","2018-03-09 17:54:42","2018-03-09 16:54:42","The second prototype! Long gone now, looks like blue flowers..","Just the Sea 1 #1","","inherit","closed","closed","","141-revision-v1","","","2018-03-09 17:54:42","2018-03-09 16:54:42","","141","http://dswp.local/229/141-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("230","1","2018-03-09 17:55:10","2018-03-09 16:55:10","I always have the temptation of going a bit beyond those nature dioramas by including some human input at some point and then I say to myself heck no.. Not yet. Let\'s finish first at least 20 of those and then we\'ll see.

And every time this temptation occurs I feel the need of doing something quite abstract like that piece of shore which has just some sand and a bit of sea and basic lighting effect.
That\'s my most zen piece so far, I\'m quite fond of it even If I want to do it again with brighter colors","Ripples","","inherit","closed","closed","","106-revision-v1","","","2018-03-09 17:55:10","2018-03-09 16:55:10","","106","http://dswp.local/230/106-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("231","1","2018-03-09 17:55:50","2018-03-09 16:55:50","The Grey sea is my best of the series so far.

It has it all. First it\'s done at a smaller scale than the usual 1/35 and then it\'s simple and falls together. The epitome of my technique of quite simply letting my hand thinking for myself. Thanks for watching. I will probably be doing a very close diorama with more transparency as well as using more pale blue tones.","The Grey Sea","","inherit","closed","closed","","103-revision-v1","","","2018-03-09 17:55:50","2018-03-09 16:55:50","","103","http://dswp.local/231/103-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("232","1","2018-03-09 17:56:42","2018-03-09 16:56:42","Another one I have mixed feelings about. In truth this is a sort of draft : I have a truck model that waits for me since about 2 years now. The plan was to put it near a icy torrent like that one. But then I was unsure of the icy effects and about how they would be rendered so I tried that small diorama.

Conclusion is I shouldn\'t have build the two sides of the river, the shape is alright and the weird kind of lighting is okay, but the small ripples are not a great work at all.
And can anyone notice the icy effects on the ledges? No you hardly can on my pictures.

I suppose it\'s another one I could spend a couple of hours on.","The Icy River","","inherit","closed","closed","","101-revision-v1","","","2018-03-09 17:56:42","2018-03-09 16:56:42","","101","http://dswp.local/232/101-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("233","1","2018-03-09 17:57:18","2018-03-09 16:57:18","Dreary humid, foggy autumn and then the yellow leaves fall in the river filled with pure water as renewed by the countless scattered showers. I feel both cold and happy when looking at that one.","Brook in autumn","","inherit","closed","closed","","99-revision-v1","","","2018-03-09 17:57:18","2018-03-09 16:57:18","","99","http://dswp.local/233/99-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("234","1","2018-03-09 17:58:03","2018-03-09 16:58:03","One of the lesser of the series I suppose? I should work on it again. The colors are good and make it for a rather uneventful water scape. Something has to be done! Watch this space!","Top of  the Lake","","inherit","closed","closed","","97-revision-v1","","","2018-03-09 17:58:03","2018-03-09 16:58:03","","97","http://dswp.local/234/97-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("235","1","2018-03-09 17:59:34","2018-03-09 16:59:34","Aivazovski is not the best painter in history but I think he was my work\'s major influence at some point.

I like it all, the colors, the shape, the movement, the historical frame,  the drama.

Here is a typical diorama inspired by his work. I still have a lot of work to reach the level of his small footnail though.

Yet it works, happy about the foam as well as transparency.","Aivazovsky","","inherit","closed","closed","","95-revision-v1","","","2018-03-09 17:59:34","2018-03-09 16:59:34","","95","http://dswp.local/235/95-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("236","1","2018-03-09 18:00:03","2018-03-09 17:00:03","","Saint Laurent","","inherit","closed","closed","","93-revision-v1","","","2018-03-09 18:00:03","2018-03-09 17:00:03","","93","http://dswp.local/236/93-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("237","1","2018-03-09 18:00:41","2018-03-09 17:00:41","<div dir=\"auto\">So it happens my mom lives close to the Bassin d\'Arcachon which is located on Western France.</div>
<div dir=\"auto\">When the tide is low the sea almost leaves the whole place and you can see a limitless area of ooze. It can be quite dangerous too: when you walk too far in, the mud sucks your leg in and the place can transform itself in sort of not so quick sands.</div>
<div dir=\"auto\">Worse even when you sort of scratch this mud with the tip of the foot, you get it covered by a black gooey substance.</div>
<div dir=\"auto\">This is this kind of treacherous muddy beaches I wanted to reproduce here.</div>
<div dir=\"auto\">Of course there are no rocks on the Bassin darcachon but I could use a bit of extra drama.</div>","Muddy shore","","inherit","closed","closed","","72-revision-v1","","","2018-03-09 18:00:41","2018-03-09 17:00:41","","72","http://dswp.local/237/72-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("238","1","2018-03-09 18:01:10","2018-03-09 17:01:10","\"Yeah it\'s rather nice, the primary lines are good, but you missed the secondary ones\".
The art teacher leaves the room, I suddenly feel slightly depressed..

The sea in winter. Lots of fog a white atmosphere you can\'t see much not a lot of colors. I walk on the beach in Aquitaine, some white pine driftwood lies around.
I give it a kick so that I don\'t freeze too quickly. Oh beneath the baked cooked boiled surface lies a red wood whose color shines In the morning.","White shore","","inherit","closed","closed","","66-revision-v1","","","2018-03-09 18:01:10","2018-03-09 17:01:10","","66","http://dswp.local/238/66-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("239","1","2018-03-09 18:06:47","2018-03-09 17:06:47","<div dir=\"auto\">Ever since I am a small kid I have been fascinated by marshes, ponds you name it.</div>
<div dir=\"auto\">I remember when I was a kid going in full winter near a small lake which had been emptied and the guys were picking up the fishes like they would have gather apples..</div>
<div dir=\"auto\">The whole place was shrouded in mystery and I loved that.</div>
<div dir=\"auto\">But this fascination had their limits.</div>
<div dir=\"auto\">For once I never seem to a have had the right shoes to get close enough so I got to catch a glimpse of the edge of the water through a gap between reeds.</div>
<div dir=\"auto\">Now I can enjoy a bird view of just that.</div>","Winter Marsh","","inherit","closed","closed","","48-revision-v1","","","2018-03-09 18:06:47","2018-03-09 17:06:47","","48","http://dswp.local/239/48-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("240","1","2018-03-09 18:07:17","2018-03-09 17:07:17","I gave out the first of that series to someone who is very dear to me and I was suddenly deprived of my first diorama, the only one with true saturated colors I did so far.

As I still had the form I used for it (silicon one, reusable), I decided to do a new one while saturating the colors even more and to get a more uniform color of the sea.

In order to create a nice hot-spot I also darkened the place where the two waves meet..

Well that one was sold pretty fast as well so I will be trying out a third version with yet different colors soon.","Just the Sea 1 #2","","inherit","closed","closed","","32-revision-v1","","","2018-03-09 18:07:17","2018-03-09 17:07:17","","32","http://dswp.local/240/32-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("241","1","2018-03-09 21:24:26","2018-03-09 20:24:26","","IMG_20180308_211734","","inherit","closed","closed","","img_20180308_211734","","","2018-03-09 21:24:26","2018-03-09 20:24:26","","0","http://dswp.local/wp-content/uploads/2018/03/IMG_20180308_211734.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("242","1","2018-03-09 21:25:10","2018-03-09 20:25:10","","IMG_20180308_211734","","inherit","closed","closed","","img_20180308_211734-2","","","2018-03-09 21:25:10","2018-03-09 20:25:10","","0","http://dswp.local/wp-content/uploads/2018/03/IMG_20180308_211734-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("245","1","2018-03-09 21:29:21","2018-03-09 20:29:21","I sprayed quantities of Mr Paint lacquers to correct the previous colors so that they match with the bones. Those aare inks in fact which means that they overlay without replacing the original colors.","Color correction","","publish","closed","closed","","color-correction","","","2018-03-09 21:29:21","2018-03-09 20:29:21","","0","http://dswp.local/?p=245","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("246","1","2018-03-09 21:29:21","2018-03-09 20:29:21","I sprayed quantities of Mr Paint lacquers to correct the previous colors so that they match with the bones. Those aare inks in fact which means that they overlay without replacing the original colors.","Color correction","","inherit","closed","closed","","245-revision-v1","","","2018-03-09 21:29:21","2018-03-09 20:29:21","","245","http://dswp.local/246/245-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("248","1","2018-03-10 16:39:26","2018-03-10 15:39:26","Pouring some resin inside, blue and transparent one","Resin pouring","","publish","closed","closed","","resin-pouring","","","2018-03-10 16:39:26","2018-03-10 15:39:26","","0","http://dswp.local/?p=248","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("249","1","2018-03-10 16:36:11","2018-03-10 15:36:11","","IMG_20180310_162510","","inherit","closed","closed","","img_20180310_162510","","","2018-03-10 16:36:11","2018-03-10 15:36:11","","248","http://dswp.local/wp-content/uploads/2018/03/IMG_20180310_162510.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("250","1","2018-03-10 16:36:54","2018-03-10 15:36:54","","IMG_20180310_163035","","inherit","closed","closed","","img_20180310_163035","","","2018-03-10 16:36:54","2018-03-10 15:36:54","","248","http://dswp.local/wp-content/uploads/2018/03/IMG_20180310_163035.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("251","1","2018-03-10 16:39:26","2018-03-10 15:39:26","Pouring some resin inside, blue and transparent one","Resin pouring","","inherit","closed","closed","","248-revision-v1","","","2018-03-10 16:39:26","2018-03-10 15:39:26","","248","http://dswp.local/251/248-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("252","1","2018-03-10 21:12:45","2018-03-10 20:12:45","","ytt1","","inherit","closed","closed","","ytt1","","","2018-03-10 21:12:45","2018-03-10 20:12:45","","0","http://dswp.local/wp-content/uploads/2018/03/ytt1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("253","1","2018-03-10 21:12:55","2018-03-10 20:12:55","","ytt2","","inherit","closed","closed","","ytt2","","","2018-03-10 21:12:55","2018-03-10 20:12:55","","0","http://dswp.local/wp-content/uploads/2018/03/ytt2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("254","1","2018-03-10 21:13:00","2018-03-10 20:13:00","","ytt3","","inherit","closed","closed","","ytt3","","","2018-03-10 21:13:00","2018-03-10 20:13:00","","0","http://dswp.local/wp-content/uploads/2018/03/ytt3.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("255","1","2018-03-10 21:13:06","2018-03-10 20:13:06","","ytt4","","inherit","closed","closed","","ytt4","","","2018-03-10 21:13:06","2018-03-10 20:13:06","","0","http://dswp.local/wp-content/uploads/2018/03/ytt4.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("256","1","2018-03-10 21:13:14","2018-03-10 20:13:14","","ytt5","","inherit","closed","closed","","ytt5","","","2018-03-10 21:13:14","2018-03-10 20:13:14","","0","http://dswp.local/wp-content/uploads/2018/03/ytt5.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("257","1","2018-03-10 21:54:44","2018-03-10 20:54:44","Yttygran is an island situated in the Bering sea.

Says <a href=\"https://en.wikipedia.org/wiki/Yttygran_Island\">Wikipedia</a> :  \"Situated on the northern shore of Yttygran island (from the Chukchi <i>Etgyran</i>, meaning \"midway dwellings\"), whale bone alley consists of a large number of carefully arranged whale skulls, whale bones and stones, along with a considerable number of meat storage pits\"

&nbsp;","Yttygran","","publish","closed","closed","","yttygran","","","2018-06-24 10:50:19","2018-06-24 08:50:19","","0","http://dswp.local/?p=257","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("260","1","2018-03-10 21:53:46","2018-03-10 20:53:46","","ytt5","","inherit","closed","closed","","ytt5-2","","","2018-03-10 21:53:46","2018-03-10 20:53:46","","257","http://dswp.local/wp-content/uploads/2018/03/ytt5-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("261","1","2018-03-10 21:54:44","2018-03-10 20:54:44","Yttygran is an island situated in the Bering sea.

Says Wikipedia :  \"Situated on the northern shore of Yttygran island (from the Chukchi <i>Etgyran</i>, meaning \"midway dwellings\"), whale bone alley consists of a large number of carefully arranged whale skulls, whale bones and stones, along with a considerable number of meat storage pits\"","Yttygran","","inherit","closed","closed","","257-revision-v1","","","2018-03-10 21:54:44","2018-03-10 20:54:44","","257","http://dswp.local/261/257-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("262","1","2018-03-12 13:52:24","2018-03-12 12:52:24","Yttygran is an island situated in the Bering sea.

Says <a href=\"https://en.wikipedia.org/wiki/Yttygran_Island\">Wikipedia</a> :  \"Situated on the northern shore of Yttygran island (from the Chukchi <i>Etgyran</i>, meaning \"midway dwellings\"), whale bone alley consists of a large number of carefully arranged whale skulls, whale bones and stones, along with a considerable number of meat storage pits\"

&nbsp;","Yttygran","","inherit","closed","closed","","257-autosave-v1","","","2018-03-12 13:52:24","2018-03-12 12:52:24","","257","http://dswp.local/262/257-autosave-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("263","1","2018-03-12 13:54:31","2018-03-12 12:54:31","Yttygran is an island situated in the Bering sea.

Says <a href=\"https://en.wikipedia.org/wiki/Yttygran_Island\">Wikipedia</a> :  \"Situated on the northern shore of Yttygran island (from the Chukchi <i>Etgyran</i>, meaning \"midway dwellings\"), whale bone alley consists of a large number of carefully arranged whale skulls, whale bones and stones, along with a considerable number of meat storage pits\"

&nbsp;","Yttygran","","inherit","closed","closed","","257-revision-v1","","","2018-03-12 13:54:31","2018-03-12 12:54:31","","257","http://dswp.local/263/257-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("264","1","2018-03-12 14:11:52","2018-03-12 13:11:52","The second prototype! Long gone now, looks like blue flowers..","Just the Sea 1 #1","","inherit","closed","closed","","141-revision-v1","","","2018-03-12 14:11:52","2018-03-12 13:11:52","","141","http://dswp.local/264/141-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("265","1","2018-03-12 14:16:26","2018-03-12 13:16:26","I always have the temptation of going a bit beyond those nature dioramas by including some human input at some point and then I say to myself heck no.. Not yet. Let\'s finish first at least 20 of those and then we\'ll see.

And every time this temptation occurs I feel the need of doing something quite abstract like that piece of shore called \"Ripples\" which has just some sand and a bit of sea and basic lighting effect.
That\'s my most zen piece so far, I\'m quite fond of it even If I want to do it again with brighter colors","Ripples","","inherit","closed","closed","","106-revision-v1","","","2018-03-12 14:16:26","2018-03-12 13:16:26","","106","http://dswp.local/265/106-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("267","1","2018-03-17 09:57:27","2018-03-17 08:57:27","The last SBS post for that specific diorama, here are the painted bones for the Yttygran diorama.  Painted exclusively with acrylics, those were done with Magic Sculp over a brass armature.

The cervical bones were built out of several different parts of course","Yttygran bones","","publish","closed","closed","","yttygran-bones","","","2018-03-17 09:58:34","2018-03-17 08:58:34","","0","http://dswp.local/?p=267","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("268","1","2018-03-17 09:55:33","2018-03-17 08:55:33","","bones","","inherit","closed","closed","","bones","","","2018-03-17 09:55:45","2018-03-17 08:55:45","","267","http://dswp.local/wp-content/uploads/2018/03/bones.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("269","1","2018-03-17 09:57:27","2018-03-17 08:57:27","The last SBS post for that specific diorama, here are the painted bones for the Yttygran diorama.  Painted exclusively with acrylics, those were done with Magic Sculp over a brass armature.","Yttygran bones","","inherit","closed","closed","","267-revision-v1","","","2018-03-17 09:57:27","2018-03-17 08:57:27","","267","http://dswp.local/269/267-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("270","1","2018-03-17 09:58:34","2018-03-17 08:58:34","The last SBS post for that specific diorama, here are the painted bones for the Yttygran diorama.  Painted exclusively with acrylics, those were done with Magic Sculp over a brass armature.

The cervical bones were built out of several different parts of course","Yttygran bones","","inherit","closed","closed","","267-revision-v1","","","2018-03-17 09:58:34","2018-03-17 08:58:34","","267","http://dswp.local/270/267-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("272","1","2018-03-26 12:46:21","2018-03-26 10:46:21","The Grey sea is my best of the series so far.

It has it all. First it\'s done at a smaller scale than the usual 1/35 and then it\'s simple and falls together. The epitome of my technique of quite simply letting my hand thinking for myself. Thanks for watching. I will probably be doing a very close diorama with more transparency as well as using more pale blue tones.","The Grey Sea","","inherit","closed","closed","","103-revision-v1","","","2018-03-26 12:46:21","2018-03-26 10:46:21","","103","http://dswp.local/272/103-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("275","1","2018-05-08 19:13:46","2018-05-08 17:13:46","","_MG_3297","","inherit","closed","closed","","_mg_3297","","","2018-05-08 19:15:14","2018-05-08 17:15:14","","0","http://dswp.local/wp-content/uploads/2018/05/MG_3297.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("276","1","2018-05-08 19:15:26","2018-05-08 17:15:26","Here is a bit of Ice I have been doing lately, for a regular diorama of the figures and vehicles kind. i will soonish create another one of this style in this very place","Ice ice baby","","publish","closed","closed","","ice-ice-baby","","","2018-05-08 19:15:26","2018-05-08 17:15:26","","0","http://dswp.local/?p=276","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("277","1","2018-05-08 19:15:26","2018-05-08 17:15:26","Here is a bit of Ice I have been doing lately, for a regular diorama of the figures and vehicles kind. i will soonish create another one of this style in this very place","Ice ice baby","","inherit","closed","closed","","276-revision-v1","","","2018-05-08 19:15:26","2018-05-08 17:15:26","","276","http://dswp.local/277/276-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("279","1","2018-05-23 16:28:21","2018-05-23 14:28:21","<div dir=\"auto\">This website is a side project -it shows the nature centered dioramas I have been building throughout the last part of 2017 and in 2018.</div>
<div dir=\"auto\">The rules of the game are pretty simple : I bought a series of 3d boxes and I fill them with little scenes that must not be more than 2cm high. I must build those pretty fast so as not to loose interest too. I focus on nature and sea shores..</div>
<div dir=\"auto\"></div>","Distant Shores","","inherit","closed","closed","","34-revision-v1","","","2018-05-23 16:28:21","2018-05-23 14:28:21","","34","http://dswp.local/279/34-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("282","1","2018-06-24 10:44:54","2018-06-24 08:44:54","I sort of want to follow the seasons with my dioramas, so after that new one in 4 months i thought i could do something about the scorching heat of those past few days. Hence this diorama which makes me want to dive, but not too close from the Rocks.

&nbsp;","On the rocks","","publish","closed","closed","","on-the-rocks","","","2018-06-24 18:22:41","2018-06-24 16:22:41","","0","http://dswp.local/?p=282","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("283","1","2018-06-24 10:41:51","2018-06-24 08:41:51","","_MG_4289","","inherit","closed","closed","","_mg_4289","","","2018-06-24 10:41:51","2018-06-24 08:41:51","","282","http://dswp.local/wp-content/uploads/2018/06/MG_4289.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("284","1","2018-06-24 10:42:14","2018-06-24 08:42:14","","_MG_4292","","inherit","closed","closed","","_mg_4292","","","2018-06-24 10:42:14","2018-06-24 08:42:14","","282","http://dswp.local/wp-content/uploads/2018/06/MG_4292.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("285","1","2018-06-24 10:42:29","2018-06-24 08:42:29","","_MG_4295","","inherit","closed","closed","","_mg_4295","","","2018-06-24 10:42:29","2018-06-24 08:42:29","","282","http://dswp.local/wp-content/uploads/2018/06/MG_4295.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("286","1","2018-06-24 10:42:45","2018-06-24 08:42:45","","_MG_42922","","inherit","closed","closed","","_mg_42922","","","2018-06-24 10:42:45","2018-06-24 08:42:45","","282","http://dswp.local/wp-content/uploads/2018/06/MG_42922.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("287","1","2018-06-24 10:44:54","2018-06-24 08:44:54","","On the rocks","","inherit","closed","closed","","282-revision-v1","","","2018-06-24 10:44:54","2018-06-24 08:44:54","","282","http://dswp.local/287/282-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("288","1","2018-06-24 10:50:19","2018-06-24 08:50:19","Yttygran is an island situated in the Bering sea.

Says <a href=\"https://en.wikipedia.org/wiki/Yttygran_Island\">Wikipedia</a> :  \"Situated on the northern shore of Yttygran island (from the Chukchi <i>Etgyran</i>, meaning \"midway dwellings\"), whale bone alley consists of a large number of carefully arranged whale skulls, whale bones and stones, along with a considerable number of meat storage pits\"

&nbsp;","Yttygran","","inherit","closed","closed","","257-revision-v1","","","2018-06-24 10:50:19","2018-06-24 08:50:19","","257","http://dswp.local/288/257-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("292","1","2018-06-24 10:54:41","2018-06-24 08:54:41","","On the rocks","","inherit","closed","closed","","282-revision-v1","","","2018-06-24 10:54:41","2018-06-24 08:54:41","","282","http://dswp.local/292/282-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("293","1","2018-06-24 18:21:29","2018-06-24 16:21:29","I sort of want to follow the seasons with my dioramas, so after that new one in 4 months i thought i could do something about the scorching g","On the rocks","","inherit","closed","closed","","282-autosave-v1","","","2018-06-24 18:21:29","2018-06-24 16:21:29","","282","http://dswp.local/293/282-autosave-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("295","1","2018-06-24 18:22:41","2018-06-24 16:22:41","I sort of want to follow the seasons with my dioramas, so after that new one in 4 months i thought i could do something about the scorching heat of those past few days. Hence this diorama which makes me want to dive, but not too close from the Rocks.

&nbsp;","On the rocks","","inherit","closed","closed","","282-revision-v1","","","2018-06-24 18:22:41","2018-06-24 16:22:41","","282","http://dswp.local/295/282-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("300","1","2018-06-24 19:17:04","2018-06-24 17:17:04","Yes.. But it lacks of focus.

&nbsp;","First try for the On the Rocks diorama","","publish","closed","closed","","first-try-for-the-on-the-rocks-diorama","","","2018-06-24 19:17:04","2018-06-24 17:17:04","","0","http://dswp.local/?p=300","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("301","1","2018-06-24 19:15:49","2018-06-24 17:15:49","","IMG_20180620_200341","","inherit","closed","closed","","img_20180620_200341","","","2018-06-24 19:15:49","2018-06-24 17:15:49","","300","http://dswp.local/wp-content/uploads/2018/06/IMG_20180620_200341.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("303","1","2018-06-24 19:17:04","2018-06-24 17:17:04","Yes.. But it lacks of focus.

&nbsp;","First try for the On the Rocks diorama","","inherit","closed","closed","","300-revision-v1","","","2018-06-24 19:17:04","2018-06-24 17:17:04","","300","http://dswp.local/303/300-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("305","1","2018-09-27 19:10:13","2018-09-27 17:10:13","\"In economics, diminishing returns is the decrease in the marginal (incremental) output of a production process as the amount of a single factor of production is incrementally increased, while the amounts of all other factors of production stay constant\" states Wikipedia.

In other words, If i keep on doing seascapes over and over, people will get bored.","The Law of Diminishing Returns","","publish","closed","closed","","the-law-of-diminishing-returns","","","2018-10-27 11:35:40","2018-10-27 09:35:40","","0","http://dswp.local/?p=305","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("306","1","2018-09-27 19:09:22","2018-09-27 17:09:22","","tghumb","","inherit","closed","closed","","tghumb","","","2018-09-27 19:09:22","2018-09-27 17:09:22","","305","http://dswp.local/wp-content/uploads/2018/09/tghumb-1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("307","1","2018-09-27 19:09:38","2018-09-27 17:09:38","","_MG_5459","","inherit","closed","closed","","_mg_5459","","","2018-09-27 19:09:38","2018-09-27 17:09:38","","305","http://dswp.local/wp-content/uploads/2018/09/MG_5459-1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("308","1","2018-09-27 19:09:55","2018-09-27 17:09:55","","_MG_5467","","inherit","closed","closed","","_mg_5467","","","2018-09-27 19:09:55","2018-09-27 17:09:55","","305","http://dswp.local/wp-content/uploads/2018/09/MG_5467-1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("309","1","2018-09-27 19:10:13","2018-09-27 17:10:13","","The law of Diminishing Returns","","inherit","closed","closed","","305-revision-v1","","","2018-09-27 19:10:13","2018-09-27 17:10:13","","305","http://dswp.local/309/305-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("310","1","2018-09-27 19:10:22","2018-09-27 17:10:22","","The Law of Diminishing Returns","","inherit","closed","closed","","305-revision-v1","","","2018-09-27 19:10:22","2018-09-27 17:10:22","","305","http://dswp.local/310/305-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("311","1","2018-09-27 19:15:44","2018-09-27 17:15:44","It all started when a friend of mine told \"I want to go to Iceland because the sand on the beaches is BLACK\". So in my mind I started playing with a game of contrasts, the white of the ice, the blue of the stranded Ice.. you guys should follow me on Instagram because i did a full SBS as stories for that one.

&nbsp;","Black Ice","","publish","closed","closed","","black-ice","","","2018-10-27 11:07:29","2018-10-27 09:07:29","","0","http://dswp.local/?p=311","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("312","1","2018-09-27 19:11:19","2018-09-27 17:11:19","","_MG_5617","","inherit","closed","closed","","_mg_5617","","","2018-09-27 19:11:19","2018-09-27 17:11:19","","311","http://dswp.local/wp-content/uploads/2018/09/MG_5617-1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("313","1","2018-09-27 19:11:36","2018-09-27 17:11:36","","_MG_5621","","inherit","closed","closed","","_mg_5621","","","2018-09-27 19:11:36","2018-09-27 17:11:36","","311","http://dswp.local/wp-content/uploads/2018/09/MG_5621-1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("314","1","2018-09-27 19:11:52","2018-09-27 17:11:52","","_MG_5625","","inherit","closed","closed","","_mg_5625","","","2018-09-27 19:11:52","2018-09-27 17:11:52","","311","http://dswp.local/wp-content/uploads/2018/09/MG_5625-1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("315","1","2018-09-27 19:12:09","2018-09-27 17:12:09","","_MG_5626","","inherit","closed","closed","","_mg_5626","","","2018-09-27 19:12:09","2018-09-27 17:12:09","","311","http://dswp.local/wp-content/uploads/2018/09/MG_5626-1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("316","1","2018-09-27 19:12:24","2018-09-27 17:12:24","","_MG_5628","","inherit","closed","closed","","_mg_5628","","","2018-09-27 19:12:24","2018-09-27 17:12:24","","311","http://dswp.local/wp-content/uploads/2018/09/MG_5628-1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("317","1","2018-09-27 19:12:37","2018-09-27 17:12:37","","s_MG_5617","","inherit","closed","closed","","s_mg_5617","","","2018-09-27 19:12:37","2018-09-27 17:12:37","","311","http://dswp.local/wp-content/uploads/2018/09/s_MG_5617-1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("318","1","2018-09-27 19:15:44","2018-09-27 17:15:44","","Black Ice","","inherit","closed","closed","","311-revision-v1","","","2018-09-27 19:15:44","2018-09-27 17:15:44","","311","http://dswp.local/318/311-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("320","1","2018-10-06 11:11:56","2018-10-06 09:11:56","This diorama is an echo of Medusa 1  to 3 that you can see on the <a href=\"http://www.jbadiorama.com\" target=\"_blank\" rel=\"noopener\">JbaDiorama</a> website. It\'s part of an ongoing fictionnal story about trouble waters. The orange cat that was on Medusa 3 is now resting on trimmed pine trunks, I kept the garish colours of the 2 and nobody is throwing up anymore in the water like in the 1 yet some bottles are still there. Yet everything is more relaxed and optimistic.

In a way that\'s the way I consider real nature and lanscape to be, always altered by human presence wherever you are. I usually trim my scenes short so that I can\'t be tempted to show the usual devastation.","Medusa VII","","publish","closed","closed","","medusa-vii","","","2018-10-27 11:19:18","2018-10-27 09:19:18","","0","http://dswp.local/?p=320","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("321","1","2018-10-06 11:10:42","2018-10-06 09:10:42","","_MG_5633","","inherit","closed","closed","","_mg_5633","","","2018-10-06 11:10:42","2018-10-06 09:10:42","","320","http://dswp.local/wp-content/uploads/2018/10/MG_5633.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("322","1","2018-10-06 11:11:05","2018-10-06 09:11:05","","_MG_5635","","inherit","closed","closed","","_mg_5635","","","2018-10-06 11:11:05","2018-10-06 09:11:05","","320","http://dswp.local/wp-content/uploads/2018/10/MG_5635.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("323","1","2018-10-06 11:11:26","2018-10-06 09:11:26","","_MG_5641","","inherit","closed","closed","","_mg_5641","","","2018-10-06 11:11:26","2018-10-06 09:11:26","","320","http://dswp.local/wp-content/uploads/2018/10/MG_5641.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("324","1","2018-10-06 11:11:41","2018-10-06 09:11:41","","site","","inherit","closed","closed","","site","","","2018-10-06 11:11:41","2018-10-06 09:11:41","","320","http://dswp.local/wp-content/uploads/2018/10/site.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("325","1","2018-10-06 11:11:56","2018-10-06 09:11:56","","Medusa VII","","inherit","closed","closed","","320-revision-v1","","","2018-10-06 11:11:56","2018-10-06 09:11:56","","320","http://dswp.local/325/320-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("326","1","2018-10-06 11:38:03","2018-10-06 09:38:03","That\'s  my own version of Millais\' Ophelia. I always planned to use that portrait I sculpted a few years back in one way or another and then last spring I saw pollen gently drifing on a lake, and here we go.. That pollen shape was probably my greatest moment in modeling that year so far.","Pollen (Medusa V)","","publish","closed","closed","","medusa-v","","","2018-10-27 11:29:46","2018-10-27 09:29:46","","0","http://dswp.local/?p=326","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("327","1","2018-10-06 11:14:33","2018-10-06 09:14:33","","_MG_434","","inherit","closed","closed","","_mg_434","","","2018-10-06 11:14:33","2018-10-06 09:14:33","","326","http://dswp.local/wp-content/uploads/2018/10/MG_434.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("328","1","2018-10-06 11:14:43","2018-10-06 09:14:43","","_MG_4327","","inherit","closed","closed","","_mg_4327","","","2018-10-06 11:14:43","2018-10-06 09:14:43","","326","http://dswp.local/wp-content/uploads/2018/10/MG_4327.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("329","1","2018-10-06 11:14:53","2018-10-06 09:14:53","","_MG_4325","","inherit","closed","closed","","_mg_4325","","","2018-10-06 11:14:53","2018-10-06 09:14:53","","326","http://dswp.local/wp-content/uploads/2018/10/MG_4325.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("330","1","2018-10-06 11:15:08","2018-10-06 09:15:08","","_MG_4324","","inherit","closed","closed","","_mg_4324","","","2018-10-06 11:15:08","2018-10-06 09:15:08","","326","http://dswp.local/wp-content/uploads/2018/10/MG_4324.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("331","1","2018-10-06 11:37:17","2018-10-06 09:37:17","","_MG_4325","","inherit","closed","closed","","_mg_4325-2","","","2018-10-06 11:37:17","2018-10-06 09:37:17","","326","http://dswp.local/wp-content/uploads/2018/10/MG_4325-1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("332","1","2018-10-06 11:38:03","2018-10-06 09:38:03","","Medusa V","","inherit","closed","closed","","326-revision-v1","","","2018-10-06 11:38:03","2018-10-06 09:38:03","","326","http://dswp.local/332/326-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("334","1","2018-10-27 11:28:32","2018-10-27 09:28:32","That\'s  my own version of Millais\' Ophelia. I always planned to use that portrait in one way or another and then last spring I saw pollen","Medusa V (Pollen)","","inherit","closed","closed","","326-autosave-v1","","","2018-10-27 11:28:32","2018-10-27 09:28:32","","326","http://dswp.local/334/326-autosave-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("335","1","2018-10-12 19:12:38","2018-10-12 17:12:38","","Medusa V","","inherit","closed","closed","","326-revision-v1","","","2018-10-12 19:12:38","2018-10-12 17:12:38","","326","http://dswp.local/335/326-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("336","1","2018-10-12 19:13:42","2018-10-12 17:13:42","","Medusa VII","","inherit","closed","closed","","320-revision-v1","","","2018-10-12 19:13:42","2018-10-12 17:13:42","","320","http://dswp.local/336/320-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("337","1","2018-10-12 19:14:39","2018-10-12 17:14:39","","Black Ice","","inherit","closed","closed","","311-revision-v1","","","2018-10-12 19:14:39","2018-10-12 17:14:39","","311","http://dswp.local/337/311-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("338","1","2018-10-12 19:15:05","2018-10-12 17:15:05","","Black Ice","","inherit","closed","closed","","311-revision-v1","","","2018-10-12 19:15:05","2018-10-12 17:15:05","","311","http://dswp.local/338/311-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("339","1","2018-10-12 20:04:04","2018-10-12 18:04:04","","The Law of Diminishing Returns","","inherit","closed","closed","","305-revision-v1","","","2018-10-12 20:04:04","2018-10-12 18:04:04","","305","http://dswp.local/339/305-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("342","1","2018-10-14 18:53:20","2018-10-14 16:53:20","","_MG_5686","","inherit","closed","closed","","_mg_5686","","","2018-10-14 18:53:20","2018-10-14 16:53:20","","0","http://dswp.local/wp-content/uploads/2018/10/MG_5686.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("343","1","2018-10-14 18:53:36","2018-10-14 16:53:36","","_MG_5689","","inherit","closed","closed","","_mg_5689","","","2018-10-14 18:53:36","2018-10-14 16:53:36","","0","http://dswp.local/wp-content/uploads/2018/10/MG_5689.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("344","1","2018-10-14 18:53:54","2018-10-14 16:53:54","","_MG_5691","","inherit","closed","closed","","_mg_5691","","","2018-10-14 18:53:54","2018-10-14 16:53:54","","0","http://dswp.local/wp-content/uploads/2018/10/MG_5691.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("345","1","2018-10-14 18:54:12","2018-10-14 16:54:12","","_MG_5696","","inherit","closed","closed","","_mg_5696","","","2018-10-14 18:54:12","2018-10-14 16:54:12","","0","http://dswp.local/wp-content/uploads/2018/10/MG_5696.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("346","1","2018-10-14 18:54:29","2018-10-14 16:54:29","","_MG_5698","","inherit","closed","closed","","_mg_5698","","","2018-10-14 18:54:29","2018-10-14 16:54:29","","0","http://dswp.local/wp-content/uploads/2018/10/MG_5698.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("347","1","2018-10-14 18:54:58","2018-10-14 16:54:58","","care2","","inherit","closed","closed","","care2","","","2018-10-14 18:54:58","2018-10-14 16:54:58","","0","http://dswp.local/wp-content/uploads/2018/10/care2.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("348","1","2018-10-14 19:28:32","2018-10-14 17:28:32","Visited place yeah right :) That diorama changed a bit since I first planned it, but the point was also to use those great <a href=\"http://www.model-scene.com/\">Model Scene</a> ferns in a more artistic fashion than what i see here and there. Hope you like the texture and colouring.

&nbsp;","Visited Place #1","","publish","closed","closed","","visited-place-1","","","2018-10-27 11:22:30","2018-10-27 09:22:30","","0","http://dswp.local/?p=348","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("349","1","2018-10-14 19:28:32","2018-10-14 17:28:32","","Visited Place #1","","inherit","closed","closed","","348-revision-v1","","","2018-10-14 19:28:32","2018-10-14 17:28:32","","348","http://dswp.local/349/348-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("350","1","2018-10-15 22:27:10","2018-10-15 20:27:10","","Visited Place #1","","inherit","closed","closed","","348-revision-v1","","","2018-10-15 22:27:10","2018-10-15 20:27:10","","348","http://dswp.local/350/348-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("352","1","2018-10-27 11:06:16","2018-10-27 09:06:16","It all started when a friend of mine told \"I want to go to Iceland because the sand on the beaches is BLACK\"","Black Ice","","inherit","closed","closed","","311-autosave-v1","","","2018-10-27 11:06:16","2018-10-27 09:06:16","","311","http://dswp.local/352/311-autosave-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("353","1","2018-10-27 11:07:29","2018-10-27 09:07:29","It all started when a friend of mine told \"I want to go to Iceland because the sand on the beaches is BLACK\". So in my mind I started playing with a game of contrasts, the white of the ice, the blue of the stranded Ice.. you guys should follow me on Instagram because i did a full SBS as stories for that one.

&nbsp;","Black Ice","","inherit","closed","closed","","311-revision-v1","","","2018-10-27 11:07:29","2018-10-27 09:07:29","","311","http://dswp.local/353/311-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("354","1","2018-10-27 11:18:10","2018-10-27 09:18:10","This diorama is an echo of Medusa 1  to 3 that you can see on the <a href=\"http://www.jbadiorama.com\" target=\"_blank\" rel=\"noopener\">JbaDiorama</a> website. It\'s part of an ongoing fictionnal story about trouble waters. The orange cat that was on Medusa 3 is now resting on trimmed pine trunks, I kept the garish colours of the 2 and nobody is throwing up anymore in the water like in the 1 yet some bottles are still there.

In a way that\'s the way I consider real nature and lanscape to be, always altered by human presence wherever you are. I usually trim","Medusa VII","","inherit","closed","closed","","320-autosave-v1","","","2018-10-27 11:18:10","2018-10-27 09:18:10","","320","http://dswp.local/354/320-autosave-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("355","1","2018-10-27 11:19:18","2018-10-27 09:19:18","This diorama is an echo of Medusa 1  to 3 that you can see on the <a href=\"http://www.jbadiorama.com\" target=\"_blank\" rel=\"noopener\">JbaDiorama</a> website. It\'s part of an ongoing fictionnal story about trouble waters. The orange cat that was on Medusa 3 is now resting on trimmed pine trunks, I kept the garish colours of the 2 and nobody is throwing up anymore in the water like in the 1 yet some bottles are still there. Yet everything is more relaxed and optimistic.

In a way that\'s the way I consider real nature and lanscape to be, always altered by human presence wherever you are. I usually trim my scenes short so that I can\'t be tempted to show the usual devastation.","Medusa VII","","inherit","closed","closed","","320-revision-v1","","","2018-10-27 11:19:18","2018-10-27 09:19:18","","320","http://dswp.local/355/320-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("356","1","2018-10-27 11:20:45","2018-10-27 09:20:45","Visited place yeah right :) That diorama changed a bit since I first planned it, but the point was also to use those great Model Scene ferns

&nbsp;","Visited Place #1","","inherit","closed","closed","","348-autosave-v1","","","2018-10-27 11:20:45","2018-10-27 09:20:45","","348","http://dswp.local/356/348-autosave-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("357","1","2018-10-27 11:22:09","2018-10-27 09:22:09","Visited place yeah right :) That diorama changed a bit since I first planned it, but the point was also to use those great <a href=\"http://www.model-scene.com/\">Model Scene</a> ferns in a more artistic fashion than what i see here and there. Hope you like the texture and colouring.

&nbsp;","Visited Place #1","","inherit","closed","closed","","348-revision-v1","","","2018-10-27 11:22:09","2018-10-27 09:22:09","","348","http://dswp.local/357/348-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("358","1","2018-10-27 11:22:30","2018-10-27 09:22:30","Visited place yeah right :) That diorama changed a bit since I first planned it, but the point was also to use those great <a href=\"http://www.model-scene.com/\">Model Scene</a> ferns in a more artistic fashion than what i see here and there. Hope you like the texture and colouring.

&nbsp;","Visited Place #1","","inherit","closed","closed","","348-revision-v1","","","2018-10-27 11:22:30","2018-10-27 09:22:30","","348","http://dswp.local/358/348-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("360","1","2018-10-27 11:29:46","2018-10-27 09:29:46","That\'s  my own version of Millais\' Ophelia. I always planned to use that portrait I sculpted a few years back in one way or another and then last spring I saw pollen gently drifing on a lake, and here we go.. That pollen shape was probably my greatest moment in modeling that year so far.","Pollen (Medusa V)","","inherit","closed","closed","","326-revision-v1","","","2018-10-27 11:29:46","2018-10-27 09:29:46","","326","http://dswp.local/360/326-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("361","1","2018-10-27 11:35:40","2018-10-27 09:35:40","\"In economics, diminishing returns is the decrease in the marginal (incremental) output of a production process as the amount of a single factor of production is incrementally increased, while the amounts of all other factors of production stay constant\" states Wikipedia.

In other words, If i keep on doing seascapes over and over, people will get bored.","The Law of Diminishing Returns","","inherit","closed","closed","","305-revision-v1","","","2018-10-27 11:35:40","2018-10-27 09:35:40","","305","http://dswp.local/361/305-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("362","1","2018-10-27 11:44:36","2018-10-27 09:44:36","My only purveyor of ground making solution","Model Scene","","publish","closed","closed","","model-scene-2","","","2018-10-27 11:44:45","2018-10-27 09:44:45","","0","http://dswp.local/?p=362","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("363","1","2018-10-27 11:44:36","2018-10-27 09:44:36","My only purveyor of ground making solution","Model Scene","","inherit","closed","closed","","362-revision-v1","","","2018-10-27 11:44:36","2018-10-27 09:44:36","","362","http://dswp.local/363/362-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("364","1","2018-10-27 11:44:45","2018-10-27 09:44:45","My only purveyor of ground making solution","Model Scene","","inherit","closed","closed","","362-revision-v1","","","2018-10-27 11:44:45","2018-10-27 09:44:45","","362","http://dswp.local/364/362-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("366","1","2018-11-18 12:30:17","2018-11-18 11:30:17","That one is completely based on a picture a friend sent me on a forum, so much for my creativity. The only difference was that there was a woman sleeping over one of the cubic wavebreakers. I removed something that I would have considered as a cliché on one of my dioramas, putting the emphasis on the contrast between the roughness of the cubes and the magic of the waves. I really like the abstraction of this one.","Wavebreaker","","publish","closed","closed","","wavebreaker","","","2018-11-19 18:57:48","2018-11-19 17:57:48","","0","http://dswp.local/?p=366","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("367","1","2018-11-18 12:25:29","2018-11-18 11:25:29","","carre","","inherit","closed","closed","","carre","","","2018-11-18 12:25:29","2018-11-18 11:25:29","","366","http://dswp.local/wp-content/uploads/2018/11/carre.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("368","1","2018-11-18 12:25:33","2018-11-18 11:25:33","","wavebreaker_2","","inherit","closed","closed","","wavebreaker_2","","","2018-11-18 12:25:33","2018-11-18 11:25:33","","366","http://dswp.local/wp-content/uploads/2018/11/wavebreaker_2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("370","1","2018-11-18 12:25:46","2018-11-18 11:25:46","","wavebreaker_1","","inherit","closed","closed","","wavebreaker_1","","","2018-11-18 12:25:46","2018-11-18 11:25:46","","366","http://dswp.local/wp-content/uploads/2018/11/wavebreaker_1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("371","1","2018-11-18 12:30:17","2018-11-18 11:30:17","That one is completely based on a picture a friend sent me on a forum, so much for my creativity. The only difference was that there was a woman sleeping over one of the cubic wavebreakers. I removed something that I would have considered as a cliché on one of my dioramas, putting the emphasis on the contrast between the roughness of the cubes and the magic of the waves. I really like the absctraction of this one.","Wavebreaker","","inherit","closed","closed","","366-revision-v1","","","2018-11-18 12:30:17","2018-11-18 11:30:17","","366","http://dswp.local/371/366-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("373","1","2018-11-18 12:34:45","2018-11-18 11:34:45","","wavebreaker_3","","inherit","closed","closed","","wavebreaker_3","","","2018-11-18 12:34:45","2018-11-18 11:34:45","","0","http://dswp.local/wp-content/uploads/2018/11/wavebreaker_3.jpg","0","attachment","image/jpeg","0");
INSERT INTO `yucqn_posts` VALUES("374","1","2018-11-18 12:34:57","2018-11-18 11:34:57","That one is completely based on a picture a friend sent me on a forum, so much for my creativity. The only difference was that there was a woman sleeping over one of the cubic wavebreakers. I removed something that I would have considered as a cliché on one of my dioramas, putting the emphasis on the contrast between the roughness of the cubes and the magic of the waves. I really like the absctraction of this one.","Wavebreaker","","inherit","closed","closed","","366-revision-v1","","","2018-11-18 12:34:57","2018-11-18 11:34:57","","366","http://dswp.local/374/366-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("375","1","2018-11-18 12:35:04","2018-11-18 11:35:04","That one is completely based on a picture a friend sent me on a forum, so much for my creativity. The only difference was that there was a woman sleeping over one of the cubic wavebreakers. I removed something that I would have considered as a cliché on one of my dioramas, putting the emphasis on the contrast between the roughness of the cubes and the magic of the waves. I really like the absctraction of this one.","Wavebreaker","","inherit","closed","closed","","366-revision-v1","","","2018-11-18 12:35:04","2018-11-18 11:35:04","","366","http://dswp.local/375/366-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("376","1","2018-11-18 13:09:47","2018-11-18 12:09:47","That one is completely based on a picture a friend sent me on a forum, so much for my creativity. The only difference was that there was a woman sleeping over one of the cubic wavebreakers. I removed something that I would have considered as a cliché on one of my dioramas, putting the emphasis on the contrast between the roughness of the cubes and the magic of the waves. I really like the abstraction of this one.","Wavebreaker","","inherit","closed","closed","","366-revision-v1","","","2018-11-18 13:09:47","2018-11-18 12:09:47","","366","http://dswp.local/376/366-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("377","1","2018-11-19 18:57:48","2018-11-19 17:57:48","That one is completely based on a picture a friend sent me on a forum, so much for my creativity. The only difference was that there was a woman sleeping over one of the cubic wavebreakers. I removed something that I would have considered as a cliché on one of my dioramas, putting the emphasis on the contrast between the roughness of the cubes and the magic of the waves. I really like the abstraction of this one.","Wavebreaker","","inherit","closed","closed","","366-revision-v1","","","2018-11-19 18:57:48","2018-11-19 17:57:48","","366","http://dswp.local/377/366-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("378","1","2019-01-26 20:36:06","1970-01-01 05:05:05","","Brouillon auto","","auto-draft","closed","closed","","","","","2019-01-26 20:36:06","1970-01-01 05:05:05","","0","http://dswp.local/?p=378","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("379","1","2019-01-26 20:43:29","2019-01-26 19:43:29","It took me more than 6 weeks to complete that dog. I can\'t believe it for such a small scene. The kit is Meng\'s BMW E-21 in 1/35, it\'s reasonably good. I still wonder what made me think of this idea, perhaps a bit of influence from Simon Stalenhag, perhaps also the fact I, being a rather bad driver, crashed my car last July. I also think it comes from the fact I saw plenty of good car dioramas lately and thought I could add my 2 cents to the trend.","E-21","","publish","closed","closed","","e-21","","","2019-01-26 20:43:29","2019-01-26 19:43:29","","0","http://dswp.local/?p=379","0","post","","0");
INSERT INTO `yucqn_posts` VALUES("380","1","2019-01-26 20:36:47","2019-01-26 19:36:47","","bmwe21-1","","inherit","closed","closed","","bmwe21-1","","","2019-01-26 20:36:47","2019-01-26 19:36:47","","379","http://dswp.local/wp-content/uploads/2019/01/bmwe21-1.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("381","1","2019-01-26 20:37:04","2019-01-26 19:37:04","","bmwe21-2","","inherit","closed","closed","","bmwe21-2","","","2019-01-26 20:37:04","2019-01-26 19:37:04","","379","http://dswp.local/wp-content/uploads/2019/01/bmwe21-2.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("382","1","2019-01-26 20:37:23","2019-01-26 19:37:23","","bmwe21-3","","inherit","closed","closed","","bmwe21-3","","","2019-01-26 20:37:23","2019-01-26 19:37:23","","379","http://dswp.local/wp-content/uploads/2019/01/bmwe21-3.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("383","1","2019-01-26 20:37:44","2019-01-26 19:37:44","","bmwe21-4","","inherit","closed","closed","","bmwe21-4","","","2019-01-26 20:37:44","2019-01-26 19:37:44","","379","http://dswp.local/wp-content/uploads/2019/01/bmwe21-4.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("384","1","2019-01-26 20:37:57","2019-01-26 19:37:57","","BMW E21 1/35","","inherit","closed","closed","","square","","","2019-01-26 20:38:43","2019-01-26 19:38:43","","379","http://dswp.local/wp-content/uploads/2019/01/square.png","0","attachment","image/png","0");
INSERT INTO `yucqn_posts` VALUES("385","1","2019-01-26 20:43:29","2019-01-26 19:43:29","It took me more than 6 weeks to complete that dog. I can\'t believe it for such a small scene. The kit is Meng\'s BMW E-21 in 1/35, it\'s reasonably good. I still wonder what made me think of this idea, perhaps a bit of influence from Simon Stalenhag, perhaps also the fact I, being a rather bad driver, crashed my car last July. I also think it comes from the fact I saw plenty of good car dioramas lately and thought I could add my 2 cents to the trend.","E-21","","inherit","closed","closed","","379-revision-v1","","","2019-01-26 20:43:29","2019-01-26 19:43:29","","379","http://dswp.local/385/379-revision-v1/","0","revision","","0");
INSERT INTO `yucqn_posts` VALUES("386","1","2019-01-28 10:01:05","2019-01-28 09:01:05","a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"post_category\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"6\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:8:\"seamless\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:4:{i:0;s:8:\"comments\";i:1;s:9:\"revisions\";i:2;s:6:\"author\";i:3;s:6:\"format\";}s:11:\"description\";s:0:\"\";}","Blog","blog","publish","closed","closed","","group_5c4ec4d127dab","","","2019-01-28 10:01:05","2019-01-28 09:01:05","","0","http://dswp.local/?post_type=acf-field-group&p=386","0","acf-field-group","","0");
INSERT INTO `yucqn_posts` VALUES("387","1","2019-01-28 10:01:05","2019-01-28 09:01:05","a:17:{s:4:\"type\";s:7:\"gallery\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:3:\"min\";i:0;s:3:\"max\";i:0;s:9:\"min_width\";i:0;s:10:\"min_height\";i:0;s:8:\"min_size\";i:0;s:9:\"max_width\";i:0;s:10:\"max_height\";i:0;s:8:\"max_size\";i:0;s:10:\"mime_types\";s:0:\"\";s:6:\"insert\";s:6:\"append\";}","gallery","gallery","publish","closed","closed","","field_5a8eb974430f5","","","2019-01-28 10:01:05","2019-01-28 09:01:05","","386","http://dswp.local/?post_type=acf-field&p=387","0","acf-field","","0");
INSERT INTO `yucqn_posts` VALUES("388","1","2019-01-28 10:01:05","2019-01-28 09:01:05","a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"post_category\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"2\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:8:\"seamless\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:5:{i:0;s:10:\"discussion\";i:1;s:8:\"comments\";i:2;s:6:\"author\";i:3;s:6:\"format\";i:4;s:15:\"send-trackbacks\";}s:11:\"description\";s:0:\"\";}","Diorama","diorama","publish","closed","closed","","group_5c4ec4d1387f7","","","2019-01-28 10:01:05","2019-01-28 09:01:05","","0","http://dswp.local/?post_type=acf-field-group&p=388","0","acf-field-group","","0");
INSERT INTO `yucqn_posts` VALUES("389","1","2019-01-28 10:01:05","2019-01-28 09:01:05","a:17:{s:4:\"type\";s:7:\"gallery\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:3:\"min\";i:0;s:3:\"max\";i:0;s:9:\"min_width\";i:0;s:10:\"min_height\";i:0;s:8:\"min_size\";i:0;s:9:\"max_width\";i:0;s:10:\"max_height\";i:0;s:8:\"max_size\";i:0;s:10:\"mime_types\";s:0:\"\";s:6:\"insert\";s:6:\"append\";}","galerie","galerie","publish","closed","closed","","field_5a8c46f182839","","","2019-01-28 10:01:05","2019-01-28 09:01:05","","388","http://dswp.local/?post_type=acf-field&p=389","0","acf-field","","0");
INSERT INTO `yucqn_posts` VALUES("390","1","2019-01-28 10:01:05","2019-01-28 09:01:05","a:10:{s:4:\"type\";s:10:\"true_false\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"message\";s:0:\"\";s:13:\"default_value\";i:0;s:2:\"ui\";i:0;s:10:\"ui_on_text\";s:0:\"\";s:11:\"ui_off_text\";s:0:\"\";}","Vendu","vendu","publish","closed","closed","","field_5a8c47958283a","","","2019-01-28 10:01:05","2019-01-28 09:01:05","","388","http://dswp.local/?post_type=acf-field&p=390","1","acf-field","","0");
INSERT INTO `yucqn_posts` VALUES("391","1","2019-01-28 10:01:05","2019-01-28 09:01:05","a:9:{s:4:\"type\";s:11:\"date_picker\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:14:\"display_format\";s:5:\"m/d/Y\";s:9:\"first_day\";i:1;s:13:\"return_format\";s:5:\"d/m/Y\";s:11:\"save_format\";s:6:\"yymmdd\";}","Completed On","completed_on","publish","closed","closed","","field_5a8c47b38283b","","","2019-01-28 10:01:05","2019-01-28 09:01:05","","388","http://dswp.local/?post_type=acf-field&p=391","2","acf-field","","0");
INSERT INTO `yucqn_posts` VALUES("392","1","2019-01-28 10:01:05","2019-01-28 09:01:05","a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:10:\"formatting\";s:4:\"html\";s:9:\"maxlength\";s:0:\"\";}","Size of the scene","size_of_the_scene","publish","closed","closed","","field_5a8c47da8283c","","","2019-01-28 10:01:05","2019-01-28 09:01:05","","388","http://dswp.local/?post_type=acf-field&p=392","3","acf-field","","0");
INSERT INTO `yucqn_posts` VALUES("393","1","2019-01-28 10:01:05","2019-01-28 09:01:05","a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:10:\"formatting\";s:4:\"html\";s:9:\"maxlength\";s:0:\"\";}","Size of the frame","size_of_the_frame","publish","closed","closed","","field_5a8c47ee8283d","","","2019-01-28 10:01:05","2019-01-28 09:01:05","","388","http://dswp.local/?post_type=acf-field&p=393","4","acf-field","","0");
INSERT INTO `yucqn_posts` VALUES("394","1","2019-01-28 10:01:05","2019-01-28 09:01:05","a:9:{s:4:\"type\";s:10:\"google_map\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:10:\"center_lat\";s:0:\"\";s:10:\"center_lng\";s:0:\"\";s:4:\"zoom\";s:0:\"\";s:6:\"height\";s:0:\"\";}","Location","gmapes","publish","closed","closed","","field_5aa2bbaaef6f0","","","2019-01-28 10:01:05","2019-01-28 09:01:05","","388","http://dswp.local/?post_type=acf-field&p=394","5","acf-field","","0");
INSERT INTO `yucqn_posts` VALUES("395","1","2019-01-28 10:01:05","2019-01-28 09:01:05","a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"34\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:8:\"seamless\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:0:{}s:11:\"description\";s:0:\"\";}","Homepage","homepage","publish","closed","closed","","group_5c4ec4d162ae7","","","2019-01-28 10:01:05","2019-01-28 09:01:05","","0","http://dswp.local/?post_type=acf-field-group&p=395","0","acf-field-group","","0");
INSERT INTO `yucqn_posts` VALUES("396","1","2019-01-28 10:01:05","2019-01-28 09:01:05","a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:10:\"formatting\";s:4:\"html\";s:9:\"maxlength\";s:0:\"\";}","Marquee","marquee","publish","closed","closed","","field_5a8c520821ff9","","","2019-01-28 10:01:05","2019-01-28 09:01:05","","395","http://dswp.local/?post_type=acf-field&p=396","0","acf-field","","0");
INSERT INTO `yucqn_posts` VALUES("397","1","2019-01-28 10:01:05","2019-01-28 09:01:05","a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:10:\"formatting\";s:4:\"html\";s:9:\"maxlength\";s:0:\"\";}","url de la vidéo","url_de_la_video","publish","closed","closed","","field_5a8c522321ffa","","","2019-01-28 10:01:05","2019-01-28 09:01:05","","395","http://dswp.local/?post_type=acf-field&p=397","1","acf-field","","0");
INSERT INTO `yucqn_posts` VALUES("398","1","2019-01-28 10:01:05","2019-01-28 09:01:05","a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:13:\"return_format\";s:3:\"url\";s:9:\"min_width\";i:0;s:10:\"min_height\";i:0;s:8:\"min_size\";i:0;s:9:\"max_width\";i:0;s:10:\"max_height\";i:0;s:8:\"max_size\";i:0;s:10:\"mime_types\";s:0:\"\";}","masque video","masque_video","publish","closed","closed","","field_5a8c523321ffb","","","2019-01-28 10:01:05","2019-01-28 09:01:05","","395","http://dswp.local/?post_type=acf-field&p=398","3","acf-field","","0");
INSERT INTO `yucqn_posts` VALUES("399","1","2019-01-28 10:01:05","2019-01-28 09:01:05","a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:10:\"formatting\";s:4:\"html\";s:9:\"maxlength\";s:0:\"\";}","video url react","video_url_react","publish","closed","closed","","field_5b057a3313c72","","","2019-01-28 10:01:05","2019-01-28 09:01:05","","395","http://dswp.local/?post_type=acf-field&p=399","2","acf-field","","0");
INSERT INTO `yucqn_posts` VALUES("400","1","2019-01-28 10:01:05","2019-01-28 09:01:05","a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"post_category\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"3\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:8:\"seamless\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:7:{i:0;s:7:\"excerpt\";i:1;s:10:\"discussion\";i:2;s:8:\"comments\";i:3;s:9:\"revisions\";i:4;s:6:\"author\";i:5;s:6:\"format\";i:6;s:15:\"send-trackbacks\";}s:11:\"description\";s:0:\"\";}","Link","link","publish","closed","closed","","group_5c4ec4d182b5f","","","2019-01-28 10:01:05","2019-01-28 09:01:05","","0","http://dswp.local/?post_type=acf-field-group&p=400","0","acf-field-group","","0");
INSERT INTO `yucqn_posts` VALUES("401","1","2019-01-28 10:01:05","2019-01-28 09:01:05","a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:14:\"Entrer un lien\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:10:\"formatting\";s:4:\"html\";s:9:\"maxlength\";s:0:\"\";}","link","link","publish","closed","closed","","field_5a8c42d32b5a2","","","2019-01-28 10:01:05","2019-01-28 09:01:05","","400","http://dswp.local/?post_type=acf-field&p=401","0","acf-field","","0");


DROP TABLE IF EXISTS `yucqn_term_relationships`;

CREATE TABLE `yucqn_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `yucqn_term_relationships` VALUES("6","3","0");
INSERT INTO `yucqn_term_relationships` VALUES("32","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("32","29","0");
INSERT INTO `yucqn_term_relationships` VALUES("48","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("48","29","0");
INSERT INTO `yucqn_term_relationships` VALUES("57","5","0");
INSERT INTO `yucqn_term_relationships` VALUES("59","3","0");
INSERT INTO `yucqn_term_relationships` VALUES("61","3","0");
INSERT INTO `yucqn_term_relationships` VALUES("66","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("66","29","0");
INSERT INTO `yucqn_term_relationships` VALUES("72","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("72","29","0");
INSERT INTO `yucqn_term_relationships` VALUES("93","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("93","29","0");
INSERT INTO `yucqn_term_relationships` VALUES("95","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("95","29","0");
INSERT INTO `yucqn_term_relationships` VALUES("97","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("97","29","0");
INSERT INTO `yucqn_term_relationships` VALUES("99","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("99","19","0");
INSERT INTO `yucqn_term_relationships` VALUES("99","26","0");
INSERT INTO `yucqn_term_relationships` VALUES("99","27","0");
INSERT INTO `yucqn_term_relationships` VALUES("99","28","0");
INSERT INTO `yucqn_term_relationships` VALUES("101","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("101","21","0");
INSERT INTO `yucqn_term_relationships` VALUES("101","22","0");
INSERT INTO `yucqn_term_relationships` VALUES("101","23","0");
INSERT INTO `yucqn_term_relationships` VALUES("101","24","0");
INSERT INTO `yucqn_term_relationships` VALUES("103","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("103","13","0");
INSERT INTO `yucqn_term_relationships` VALUES("103","17","0");
INSERT INTO `yucqn_term_relationships` VALUES("103","20","0");
INSERT INTO `yucqn_term_relationships` VALUES("103","21","0");
INSERT INTO `yucqn_term_relationships` VALUES("106","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("106","29","0");
INSERT INTO `yucqn_term_relationships` VALUES("125","5","0");
INSERT INTO `yucqn_term_relationships` VALUES("141","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("141","13","0");
INSERT INTO `yucqn_term_relationships` VALUES("141","14","0");
INSERT INTO `yucqn_term_relationships` VALUES("141","15","0");
INSERT INTO `yucqn_term_relationships` VALUES("141","16","0");
INSERT INTO `yucqn_term_relationships` VALUES("141","17","0");
INSERT INTO `yucqn_term_relationships` VALUES("149","6","0");
INSERT INTO `yucqn_term_relationships` VALUES("152","6","0");
INSERT INTO `yucqn_term_relationships` VALUES("157","6","0");
INSERT INTO `yucqn_term_relationships` VALUES("178","6","0");
INSERT INTO `yucqn_term_relationships` VALUES("180","1","0");
INSERT INTO `yucqn_term_relationships` VALUES("205","3","0");
INSERT INTO `yucqn_term_relationships` VALUES("207","3","0");
INSERT INTO `yucqn_term_relationships` VALUES("211","6","0");
INSERT INTO `yucqn_term_relationships` VALUES("215","6","0");
INSERT INTO `yucqn_term_relationships` VALUES("220","6","0");
INSERT INTO `yucqn_term_relationships` VALUES("225","6","0");
INSERT INTO `yucqn_term_relationships` VALUES("227","5","0");
INSERT INTO `yucqn_term_relationships` VALUES("245","6","0");
INSERT INTO `yucqn_term_relationships` VALUES("248","6","0");
INSERT INTO `yucqn_term_relationships` VALUES("248","7","0");
INSERT INTO `yucqn_term_relationships` VALUES("248","8","0");
INSERT INTO `yucqn_term_relationships` VALUES("248","9","0");
INSERT INTO `yucqn_term_relationships` VALUES("257","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("257","8","0");
INSERT INTO `yucqn_term_relationships` VALUES("257","10","0");
INSERT INTO `yucqn_term_relationships` VALUES("257","11","0");
INSERT INTO `yucqn_term_relationships` VALUES("257","12","0");
INSERT INTO `yucqn_term_relationships` VALUES("257","29","0");
INSERT INTO `yucqn_term_relationships` VALUES("267","6","0");
INSERT INTO `yucqn_term_relationships` VALUES("276","6","0");
INSERT INTO `yucqn_term_relationships` VALUES("282","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("282","13","0");
INSERT INTO `yucqn_term_relationships` VALUES("282","17","0");
INSERT INTO `yucqn_term_relationships` VALUES("282","30","0");
INSERT INTO `yucqn_term_relationships` VALUES("300","6","0");
INSERT INTO `yucqn_term_relationships` VALUES("305","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("311","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("320","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("326","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("348","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("362","3","0");
INSERT INTO `yucqn_term_relationships` VALUES("366","2","0");
INSERT INTO `yucqn_term_relationships` VALUES("379","2","0");


DROP TABLE IF EXISTS `yucqn_term_taxonomy`;

CREATE TABLE `yucqn_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `yucqn_term_taxonomy` VALUES("1","1","category","","0","0");
INSERT INTO `yucqn_term_taxonomy` VALUES("2","2","category","","0","21");
INSERT INTO `yucqn_term_taxonomy` VALUES("3","3","category","","0","6");
INSERT INTO `yucqn_term_taxonomy` VALUES("4","4","category","","0","0");
INSERT INTO `yucqn_term_taxonomy` VALUES("5","5","nav_menu","","0","3");
INSERT INTO `yucqn_term_taxonomy` VALUES("6","6","category","","0","12");
INSERT INTO `yucqn_term_taxonomy` VALUES("7","7","post_tag","","0","1");
INSERT INTO `yucqn_term_taxonomy` VALUES("8","8","post_tag","","0","2");
INSERT INTO `yucqn_term_taxonomy` VALUES("9","9","post_tag","","0","1");
INSERT INTO `yucqn_term_taxonomy` VALUES("10","10","post_tag","","0","1");
INSERT INTO `yucqn_term_taxonomy` VALUES("11","11","post_tag","","0","1");
INSERT INTO `yucqn_term_taxonomy` VALUES("12","12","post_tag","","0","1");
INSERT INTO `yucqn_term_taxonomy` VALUES("13","13","post_tag","","0","3");
INSERT INTO `yucqn_term_taxonomy` VALUES("14","14","post_tag","","0","1");
INSERT INTO `yucqn_term_taxonomy` VALUES("15","15","post_tag","","0","1");
INSERT INTO `yucqn_term_taxonomy` VALUES("16","16","post_tag","","0","1");
INSERT INTO `yucqn_term_taxonomy` VALUES("17","17","post_tag","","0","3");
INSERT INTO `yucqn_term_taxonomy` VALUES("18","18","post_tag","","0","0");
INSERT INTO `yucqn_term_taxonomy` VALUES("19","19","post_tag","","0","1");
INSERT INTO `yucqn_term_taxonomy` VALUES("20","20","post_tag","","0","1");
INSERT INTO `yucqn_term_taxonomy` VALUES("21","21","post_tag","","0","2");
INSERT INTO `yucqn_term_taxonomy` VALUES("22","22","post_tag","","0","1");
INSERT INTO `yucqn_term_taxonomy` VALUES("23","23","post_tag","","0","1");
INSERT INTO `yucqn_term_taxonomy` VALUES("24","24","post_tag","","0","1");
INSERT INTO `yucqn_term_taxonomy` VALUES("25","25","post_tag","","0","0");
INSERT INTO `yucqn_term_taxonomy` VALUES("26","26","post_tag","","0","1");
INSERT INTO `yucqn_term_taxonomy` VALUES("27","27","post_tag","","0","1");
INSERT INTO `yucqn_term_taxonomy` VALUES("28","28","post_tag","","0","1");
INSERT INTO `yucqn_term_taxonomy` VALUES("29","29","post_tag","","0","9");
INSERT INTO `yucqn_term_taxonomy` VALUES("30","30","post_tag","","0","1");


DROP TABLE IF EXISTS `yucqn_termmeta`;

CREATE TABLE `yucqn_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



DROP TABLE IF EXISTS `yucqn_terms`;

CREATE TABLE `yucqn_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `yucqn_terms` VALUES("1","Non classé","non-classe","0");
INSERT INTO `yucqn_terms` VALUES("2","Diorama","diorama","0");
INSERT INTO `yucqn_terms` VALUES("3","Link","link","0");
INSERT INTO `yucqn_terms` VALUES("4","News","news","0");
INSERT INTO `yucqn_terms` VALUES("5","seadiorama","seadiorama","0");
INSERT INTO `yucqn_terms` VALUES("6","Blog","blog","0");
INSERT INTO `yucqn_terms` VALUES("7","Resin","resin","0");
INSERT INTO `yucqn_terms` VALUES("8","Yttygran","yttygran","0");
INSERT INTO `yucqn_terms` VALUES("9","Vegetation","vegetation","0");
INSERT INTO `yucqn_terms` VALUES("10","Tundra","tundra","0");
INSERT INTO `yucqn_terms` VALUES("11","bones","bones","0");
INSERT INTO `yucqn_terms` VALUES("12","whale","whale","0");
INSERT INTO `yucqn_terms` VALUES("13","sea","sea","0");
INSERT INTO `yucqn_terms` VALUES("14","shore","shore","0");
INSERT INTO `yucqn_terms` VALUES("15","sand","sand","0");
INSERT INTO `yucqn_terms` VALUES("16","foam","foam","0");
INSERT INTO `yucqn_terms` VALUES("17","waves","waves","0");
INSERT INTO `yucqn_terms` VALUES("18","Water","water","0");
INSERT INTO `yucqn_terms` VALUES("19","Brook","brook","0");
INSERT INTO `yucqn_terms` VALUES("20","ripples","ripples","0");
INSERT INTO `yucqn_terms` VALUES("21","grey","grey","0");
INSERT INTO `yucqn_terms` VALUES("22","Ice","ice","0");
INSERT INTO `yucqn_terms` VALUES("23","Icechunks","icechunks","0");
INSERT INTO `yucqn_terms` VALUES("24","broken","broken","0");
INSERT INTO `yucqn_terms` VALUES("25","leaves","leaves","0");
INSERT INTO `yucqn_terms` VALUES("26","stream","stream","0");
INSERT INTO `yucqn_terms` VALUES("27","torrent","torrent","0");
INSERT INTO `yucqn_terms` VALUES("28","stones","stones","0");
INSERT INTO `yucqn_terms` VALUES("29","diorama","diorama","0");
INSERT INTO `yucqn_terms` VALUES("30","rocks","rocks","0");


DROP TABLE IF EXISTS `yucqn_usermeta`;

CREATE TABLE `yucqn_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `yucqn_usermeta` VALUES("1","1","nickname","admin");
INSERT INTO `yucqn_usermeta` VALUES("2","1","first_name","");
INSERT INTO `yucqn_usermeta` VALUES("3","1","last_name","");
INSERT INTO `yucqn_usermeta` VALUES("4","1","description","");
INSERT INTO `yucqn_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `yucqn_usermeta` VALUES("6","1","syntax_highlighting","true");
INSERT INTO `yucqn_usermeta` VALUES("7","1","comment_shortcuts","false");
INSERT INTO `yucqn_usermeta` VALUES("8","1","admin_color","fresh");
INSERT INTO `yucqn_usermeta` VALUES("9","1","use_ssl","0");
INSERT INTO `yucqn_usermeta` VALUES("10","1","show_admin_bar_front","true");
INSERT INTO `yucqn_usermeta` VALUES("11","1","locale","");
INSERT INTO `yucqn_usermeta` VALUES("12","1","yucqn_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `yucqn_usermeta` VALUES("13","1","yucqn_user_level","10");
INSERT INTO `yucqn_usermeta` VALUES("14","1","dismissed_wp_pointers","wp496_privacy");
INSERT INTO `yucqn_usermeta` VALUES("15","1","show_welcome_panel","1");
INSERT INTO `yucqn_usermeta` VALUES("16","1","session_tokens","a:2:{s:64:\"b1f4fa4a8e2c5bc1b09aa94e01e3b8029d9c371861c35bde7120eba91e34e0f7\";a:4:{s:10:\"expiration\";i:1548704160;s:2:\"ip\";s:12:\"82.235.21.22\";s:2:\"ua\";s:78:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0\";s:5:\"login\";i:1548531360;}s:64:\"4d05259c162e34746d440c27623a843362d7ff7cbb71abf2a7d546c2c7037742\";a:4:{s:10:\"expiration\";i:1549875544;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:131:\"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) snap Chromium/71.0.3578.98 Chrome/71.0.3578.98 Safari/537.36\";s:5:\"login\";i:1548665944;}}");
INSERT INTO `yucqn_usermeta` VALUES("17","1","yucqn_dashboard_quick_press_last_post_id","378");
INSERT INTO `yucqn_usermeta` VALUES("18","1","community-events-location","a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}");
INSERT INTO `yucqn_usermeta` VALUES("19","1","yucqn_user-settings","libraryContent=browse&editor=tinymce&hidetb=0&uploader=1");
INSERT INTO `yucqn_usermeta` VALUES("20","1","yucqn_user-settings-time","1529860608");
INSERT INTO `yucqn_usermeta` VALUES("21","1","meta-box-order_post","a:4:{s:15:\"acf_after_title\";s:0:\"\";s:4:\"side\";s:51:\"submitdiv,categorydiv,postimagediv,tagsdiv-post_tag\";s:6:\"normal\";s:110:\"acf_126,acf_11,acf_44,acf_5,postexcerpt,trackbacksdiv,postcustom,wpseo_meta,commentstatusdiv,slugdiv,authordiv\";s:8:\"advanced\";s:0:\"\";}");
INSERT INTO `yucqn_usermeta` VALUES("22","1","screen_layout_post","2");
INSERT INTO `yucqn_usermeta` VALUES("23","1","managenav-menuscolumnshidden","a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}");
INSERT INTO `yucqn_usermeta` VALUES("24","1","metaboxhidden_nav-menus","a:1:{i:0;s:12:\"add-post_tag\";}");
INSERT INTO `yucqn_usermeta` VALUES("25","1","nav_menu_recently_edited","5");
INSERT INTO `yucqn_usermeta` VALUES("26","1","last_login_time","2019-01-28 09:59:04");
INSERT INTO `yucqn_usermeta` VALUES("28","1","closedpostboxes_post","a:1:{i:0;s:10:\"wpseo_meta\";}");
INSERT INTO `yucqn_usermeta` VALUES("29","1","metaboxhidden_post","a:10:{i:0;s:7:\"acf_126\";i:1;s:6:\"acf_11\";i:2;s:6:\"acf_44\";i:3;s:5:\"acf_5\";i:4;s:11:\"postexcerpt\";i:5;s:13:\"trackbacksdiv\";i:6;s:10:\"postcustom\";i:7;s:16:\"commentstatusdiv\";i:8;s:7:\"slugdiv\";i:9;s:9:\"authordiv\";}");
INSERT INTO `yucqn_usermeta` VALUES("30","2","wp_capabilities","a:1:{s:13:\"administrator\";s:1:\"1\";}");
INSERT INTO `yucqn_usermeta` VALUES("31","2","wp_user_level","10");
INSERT INTO `yucqn_usermeta` VALUES("32","1","_yoast_wpseo_profile_updated","1528009859");
INSERT INTO `yucqn_usermeta` VALUES("33","1","rt_gzip_success_ignore","true");


DROP TABLE IF EXISTS `yucqn_users`;

CREATE TABLE `yucqn_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `yucqn_users` VALUES("1","jbandre","$P$BW8WyI7UhUle5THUmhhiv6H40WybWn.","admin","jbadiorama@gmail.com","","2018-02-20 15:14:46","","0","admin");
INSERT INTO `yucqn_users` VALUES("2","wp.service.controller.rTjTS","$P$B2/48Jh./2IP9DjvDqD4sTWcx0qjta/","Service","","","1970-01-01 05:05:05","","0","Service");


DROP TABLE IF EXISTS `yucqn_yoast_seo_links`;

CREATE TABLE `yucqn_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `yucqn_yoast_seo_links` VALUES("4","http://dswp.local/66/white-shore/","149","66","internal");
INSERT INTO `yucqn_yoast_seo_links` VALUES("5","http://dswp.local/95/aivazovsky/","178","95","internal");
INSERT INTO `yucqn_yoast_seo_links` VALUES("7","http://www.jbadiorama.com","9","0","external");
INSERT INTO `yucqn_yoast_seo_links` VALUES("11","https://en.wikipedia.org/wiki/Yttygran_Island","257","0","external");
INSERT INTO `yucqn_yoast_seo_links` VALUES("12","http://www.jbadiorama.com","320","0","external");
INSERT INTO `yucqn_yoast_seo_links` VALUES("14","http://www.model-scene.com/","348","0","external");


DROP TABLE IF EXISTS `yucqn_yoast_seo_meta`;

CREATE TABLE `yucqn_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `yucqn_yoast_seo_meta` VALUES("1","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("2","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("3","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("4","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("8","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("9","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("19","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("20","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("21","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("22","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("27","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("28","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("32","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("34","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("38","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("40","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("41","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("42","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("43","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("47","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("48","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("51","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("55","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("56","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("58","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("66","0","1");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("72","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("93","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("95","0","1");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("97","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("99","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("101","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("103","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("106","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("117","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("118","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("120","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("121","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("122","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("123","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("141","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("142","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("143","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("144","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("145","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("149","1","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("152","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("157","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("178","1","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("179","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("180","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("193","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("194","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("205","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("207","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("210","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("211","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("215","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("220","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("224","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("225","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("243","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("244","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("245","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("247","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("248","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("257","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("258","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("259","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("266","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("267","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("271","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("273","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("274","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("276","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("278","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("280","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("281","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("282","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("289","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("290","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("291","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("294","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("296","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("297","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("298","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("299","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("300","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("302","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("304","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("305","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("311","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("319","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("320","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("326","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("333","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("340","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("341","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("348","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("351","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("359","0","0");
INSERT INTO `yucqn_yoast_seo_meta` VALUES("362","0","0");


